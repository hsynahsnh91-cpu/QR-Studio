import { useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { AppProvider, useApp } from "./context";
import { useDraft } from "./useDraft";
import { useQR } from "./hooks";
import { BottomNav, TopBar } from "./components/Shell";
import { CreateView } from "./views/CreateView";
import { ScanView } from "./views/ScanView";
import { LibraryView } from "./views/LibraryView";
import { ToolsView } from "./views/ToolsView";
import { CustomizeModal } from "./components/CustomizeModal";
import { ExportModal } from "./components/ExportModal";
import { SaveModal } from "./components/SaveModal";
import { SettingsModal } from "./components/SettingsModal";
import { OnboardingModal } from "./components/Permissions";
import type { Detected } from "./lib/scan";
import type { Project, View } from "./lib/types";

function Studio() {
  const { dir } = useApp();
  const api = useDraft();
  const [view, setView] = useState<View>("create");
  const [customizeOpen, setCustomizeOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const qr = useQR(api.typeId, api.values, api.style);
  const heroId = `hero-${api.draft.editingId ?? "qr"}`;

  const openProject = (p: Project) => {
    api.loadProject(p);
    setView("create");
  };
  const fromScan = (d: Detected) => {
    api.loadValues(d.typeId, d.values);
    setView("create");
  };

  return (
    <div dir={dir} className="mx-auto flex h-dvh max-w-[1400px] flex-col">
      <TopBar onSettings={() => setSettingsOpen(true)} />
      <main className="relative min-h-0 flex-1">
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={view}
            className="h-full w-full"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
          >
            {view === "create" && (
              <CreateView
                api={api}
                qr={qr}
                heroId={heroId}
                heroHidden={customizeOpen || exportOpen}
                onCustomize={() => setCustomizeOpen(true)}
                onExport={() => setExportOpen(true)}
                onSave={() => setSaveOpen(true)}
              />
            )}
            {view === "scan" && <ScanView onCreate={fromScan} />}
            {view === "library" && <LibraryView onOpen={openProject} onCreate={fromScan} openedId={api.draft.editingId} />}
            {view === "tools" && <ToolsView style={api.style} onDataChanged={() => undefined} />}
          </motion.div>
        </AnimatePresence>
      </main>
      <BottomNav view={view} onChange={setView} />

      <CustomizeModal open={customizeOpen} onClose={() => setCustomizeOpen(false)} api={api} qr={qr} heroId={heroId} />
      <ExportModal open={exportOpen} onClose={() => setExportOpen(false)} qr={qr} style={api.style} heroId={heroId} name={api.draft.name} />
      <SaveModal open={saveOpen} onClose={() => setSaveOpen(false)} api={api} qr={qr} onSaved={api.loadProject} />
      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <OnboardingModal />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MotionConfig reducedMotion="user">
        <Studio />
      </MotionConfig>
    </AppProvider>
  );
}
