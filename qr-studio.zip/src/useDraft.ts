import { useCallback, useEffect, useMemo, useState } from "react";
import { defaultValues } from "./lib/qrTypes";
import { emptyDraft, loadDraft, saveDraft, type Draft } from "./lib/storage";
import { DEFAULT_STYLE, type Project, type QRStyle, type Values } from "./lib/types";

export interface DraftApi {
  draft: Draft;
  typeId: string;
  values: Values;
  style: QRStyle;
  setType: (id: string) => void;
  setField: (key: string, value: string) => void;
  patchStyle: (p: Partial<QRStyle>) => void;
  setStyle: (s: QRStyle) => void;
  loadProject: (p: Project) => void;
  loadValues: (typeId: string, values: Values) => void;
  resetStyle: () => void;
  detach: () => void;
}

export function useDraft(): DraftApi {
  const [draft, setDraft] = useState<Draft>(loadDraft);

  useEffect(() => {
    const t = setTimeout(() => saveDraft(draft), 400);
    return () => clearTimeout(t);
  }, [draft]);

  const values = useMemo(
    () => ({ ...defaultValues(draft.typeId), ...(draft.valuesByType[draft.typeId] ?? {}) }),
    [draft.typeId, draft.valuesByType],
  );

  const setType = useCallback((id: string) => setDraft((d) => ({ ...d, typeId: id, editingId: d.typeId === id ? d.editingId : null })), []);
  const setField = useCallback(
    (key: string, value: string) =>
      setDraft((d) => ({
        ...d,
        valuesByType: { ...d.valuesByType, [d.typeId]: { ...defaultValues(d.typeId), ...(d.valuesByType[d.typeId] ?? {}), [key]: value } },
      })),
    [],
  );
  const patchStyle = useCallback((p: Partial<QRStyle>) => setDraft((d) => ({ ...d, style: { ...d.style, ...p } })), []);
  const setStyle = useCallback((style: QRStyle) => setDraft((d) => ({ ...d, style })), []);
  const loadProject = useCallback(
    (p: Project) =>
      setDraft((d) => ({
        ...d,
        typeId: p.typeId,
        valuesByType: { ...d.valuesByType, [p.typeId]: { ...p.values } },
        style: { ...DEFAULT_STYLE, ...p.style },
        editingId: p.id,
        name: p.name,
      })),
    [],
  );
  const loadValues = useCallback(
    (typeId: string, vals: Values) =>
      setDraft((d) => ({ ...d, typeId, valuesByType: { ...d.valuesByType, [typeId]: { ...defaultValues(typeId), ...vals } }, editingId: null, name: "" })),
    [],
  );
  const resetStyle = useCallback(() => setDraft((d) => ({ ...d, style: { ...DEFAULT_STYLE } })), []);
  const detach = useCallback(() => setDraft((d) => ({ ...emptyDraft(), ...d, editingId: null, name: "" })), []);

  return { draft, typeId: draft.typeId, values, style: draft.style, setType, setField, patchStyle, setStyle, loadProject, loadValues, resetStyle, detach };
}
