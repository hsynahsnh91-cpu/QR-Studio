import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ExternalLink, Copy, QrCode, ScanLine, ShieldAlert, ShieldCheck, TriangleAlert, Wifi } from "lucide-react";
import { useApp } from "../context";
import { analyzeLink, detectContent, type Detected } from "../lib/scan";
import { copyText } from "../lib/exporter";
import { Btn, Modal, cx } from "./ui";

export function LinkPreviewModal({ text, onClose }: { text: string | null; onClose: () => void }) {
  const { tr, bi, toast } = useApp();
  const info = useMemo(() => (text ? analyzeLink(text) : null), [text]);
  const open = !!text && !!info;

  const openIt = () => {
    if (!info || !info.openable) return;
    if (info.protocol === "http" || info.protocol === "https") window.open(info.href, "_blank", "noopener,noreferrer");
    else window.location.href = info.href;
    onClose();
  };

  const level = info?.level ?? "safe";
  const tone = level === "danger" ? "border-red-500/40 bg-red-500/10 text-red-500" : level === "warn" ? "border-amber-500/40 bg-amber-500/10 text-amber-600 dark:text-amber-400" : "border-emerald-500/40 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400";

  return (
    <Modal open={open} onClose={onClose} title={tr("معاينة الرابط قبل الفتح", "Link preview")}>
      {info && (
        <div className="space-y-3">
          <div className={cx("flex items-center gap-2 rounded-2xl border p-3 text-sm font-semibold", tone)}>
            {level === "safe" ? <ShieldCheck size={20} /> : level === "warn" ? <TriangleAlert size={20} /> : <ShieldAlert size={20} />}
            {level === "safe" ? tr("لم تُكتشف مؤشرات خطر واضحة", "No obvious risk indicators") : level === "warn" ? tr("تحقق جيداً قبل المتابعة", "Be careful before continuing") : tr("مخاطر مرتفعة", "High risk")}
          </div>
          {info.host && (
            <div>
              <div className="text-xs text-muted">{tr("النطاق", "Domain")}</div>
              <div className="break-all text-lg font-bold" dir="ltr">
                {info.host}
              </div>
            </div>
          )}
          <div>
            <div className="text-xs text-muted">{tr("الرابط الكامل", "Full link")}</div>
            <div className="thin-scroll max-h-24 overflow-y-auto break-all rounded-xl bg-card2 p-2 font-mono text-xs" dir="ltr">
              {info.href}
            </div>
          </div>
          {info.warnings.length > 0 && (
            <ul className="space-y-1 text-xs">
              {info.warnings.map((w, i) => (
                <li key={i} className="flex gap-1.5 text-amber-600 dark:text-amber-400">
                  <TriangleAlert size={13} className="mt-0.5 shrink-0" />
                  {bi(w)}
                </li>
              ))}
            </ul>
          )}
          <div className="flex gap-2 pt-1">
            <Btn
              className="flex-1"
              onClick={() => {
                copyText(info.href).then(() => toast(tr("تم النسخ", "Copied")));
              }}
            >
              <Copy size={15} />
              {tr("نسخ", "Copy")}
            </Btn>
            <Btn variant={level === "safe" ? "primary" : "danger"} className="flex-1" disabled={!info.openable} onClick={openIt}>
              <ExternalLink size={15} />
              {info.openable ? tr("فتح الرابط", "Open link") : tr("محظور", "Blocked")}
            </Btn>
          </div>
        </div>
      )}
    </Modal>
  );
}

export function ScanResultCard({ text, snapshot, onAgain, onCreate }: { text: string; snapshot?: string; onAgain: () => void; onCreate: (d: Detected) => void }) {
  const { tr, bi, toast } = useApp();
  const det = useMemo(() => detectContent(text), [text]);
  const link = useMemo(() => analyzeLink(text), [text]);
  const [preview, setPreview] = useState<string | null>(null);
  const isWifi = det.typeId === "wifi";
  const canOpen = link.isUrl && link.openable;

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      <div className="flex shrink-0 items-center gap-3">
        <motion.div layoutId="scan-hero" className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-2xl bg-primary/10 text-primary ring-1 ring-line">
          {snapshot ? <img src={snapshot} alt="" className="h-full w-full object-cover" /> : <QrCode size={28} />}
        </motion.div>
        <div className="min-w-0">
          <div className="text-xs text-muted">{tr("تمت القراءة", "Scanned")}</div>
          <div className="flex items-center gap-1.5 text-lg font-bold">
            {isWifi && <Wifi size={18} />}
            {bi(det.label)}
          </div>
          {canOpen && link.level !== "safe" && (
            <div className="flex items-center gap-1 text-xs font-semibold text-amber-600 dark:text-amber-400">
              <TriangleAlert size={12} />
              {tr("يحتاج تحققاً", "Needs a check")}
            </div>
          )}
        </div>
      </div>

      <div className="thin-scroll min-h-0 flex-1 overflow-y-auto whitespace-pre-wrap break-words rounded-2xl border border-line bg-card2 p-3 text-sm" dir="auto">
        {text}
      </div>

      <div className="grid shrink-0 grid-cols-2 gap-2">
        <Btn
          onClick={() =>
            copyText(isWifi && det.values.password ? det.values.password : text).then(
              () => toast(isWifi && det.values.password ? tr("تم نسخ كلمة المرور", "Password copied") : tr("تم النسخ", "Copied")),
              () => toast(tr("تعذّر النسخ", "Copy failed"), "err"),
            )
          }
        >
          <Copy size={15} />
          {isWifi ? tr("نسخ كلمة المرور", "Copy password") : tr("نسخ المحتوى", "Copy")}
        </Btn>
        {link.isUrl ? (
          <Btn variant="primary" onClick={() => setPreview(text)}>
            <ExternalLink size={15} />
            {tr("معاينة وفتح", "Preview & open")}
          </Btn>
        ) : (
          <Btn variant="primary" onClick={() => onCreate(det)}>
            <QrCode size={15} />
            {tr("إنشاء رمز منه", "Make QR from it")}
          </Btn>
        )}
        {link.isUrl && (
          <Btn onClick={() => onCreate(det)}>
            <QrCode size={15} />
            {tr("إنشاء رمز منه", "Make QR from it")}
          </Btn>
        )}
        <Btn onClick={onAgain} className={link.isUrl ? "" : ""}>
          <ScanLine size={15} />
          {tr("مسح جديد", "Scan again")}
        </Btn>
      </div>
      <LinkPreviewModal text={preview} onClose={() => setPreview(null)} />
    </div>
  );
}
