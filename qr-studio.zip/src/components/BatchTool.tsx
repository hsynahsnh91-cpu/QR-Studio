import { useEffect, useMemo, useRef, useState } from "react";
import { Archive, FileUp, Play, Save, Square, Trash2, Wand2 } from "lucide-react";
import { useApp } from "../context";
import { Btn, Segmented, Slider, cx } from "./ui";
import { TYPES, defaultValues, getType } from "../lib/qrTypes";
import { parseCSV } from "../lib/csv";
import { EXT, FORMATS, downloadBlob, exportBlob, thumbnail, uniqueName, zipFiles, type ExportFormat } from "../lib/exporter";
import { buildMatrix } from "../lib/projects";
import { dbPutMany } from "../lib/storage";
import { uid, type Project, type QRStyle, type Values } from "../lib/types";

interface OkItem {
  file: string;
  blob: Blob;
  values: Values;
  name: string;
}
interface ErrItem {
  row: number;
  msg: string;
}

const tick = () => new Promise<void>((r) => setTimeout(r, 0));
const norm = (s: string) => s.toLowerCase().replace(/[\s_\-‑]/g, "");
const EXAMPLE = "name,url\nGoogle,https://google.com\nGitHub,https://github.com\nWikipedia,https://wikipedia.org\nBad row,not a valid url";

export function BatchTool({ style }: { style: QRStyle }) {
  const { tr, bi, toast } = useApp();
  const [text, setText] = useState("");
  const [hasHeader, setHasHeader] = useState(false);
  const [typeId, setTypeId] = useState("url");
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [nameCol, setNameCol] = useState("");
  const [format, setFormat] = useState<ExportFormat>("png");
  const [size, setSize] = useState(512);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<[number, number]>([0, 0]);
  const [ok, setOk] = useState<OkItem[]>([]);
  const [errors, setErrors] = useState<ErrItem[]>([]);
  const [busy, setBusy] = useState(false);
  const stopRef = useRef(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const rows = useMemo(() => parseCSV(text), [text]);
  const cols = rows.reduce((m, r) => Math.max(m, r.length), 0);
  const headers = useMemo(
    () => Array.from({ length: cols }, (_, i) => (hasHeader && rows[0]?.[i] ? rows[0][i] : `${tr("عمود", "Col")} ${i + 1}`)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [rows, cols, hasHeader],
  );
  const dataRows = hasHeader ? rows.slice(1) : rows;
  const def = getType(typeId);
  const headersKey = headers.join("|");

  // auto-map columns by header name
  useEffect(() => {
    const m: Record<string, string> = {};
    let any = false;
    def.fields.forEach((f) => {
      const idx = headers.findIndex((h) => norm(h) === norm(f.key) || norm(h) === norm(f.label[0]) || norm(h) === norm(f.label[1]));
      if (idx >= 0) {
        m[f.key] = `c:${idx}`;
        any = true;
      }
    });
    if (!any && cols > 0) m[def.fields[0].key] = hasHeader && cols > 1 ? `c:${Math.min(1, cols - 1)}` : "c:0";
    setMapping(m);
    const ni = headers.findIndex((h) => /^(name|file|filename|title|اسم|الاسم)$/i.test(h.trim()));
    setNameCol(ni >= 0 && hasHeader ? String(ni) : "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [typeId, headersKey]);

  const importFile = async (f?: File) => {
    if (!f) return;
    const t = await f.text();
    setText(t);
    setHasHeader(true);
    setOk([]);
    setErrors([]);
  };

  const run = async () => {
    stopRef.current = false;
    setRunning(true);
    setOk([]);
    setErrors([]);
    const used = new Set<string>();
    const oks: OkItem[] = [];
    const errs: ErrItem[] = [];
    const pad = String(dataRows.length).length;
    setProgress([0, dataRows.length]);
    for (let i = 0; i < dataRows.length; i++) {
      if (stopRef.current) break;
      const row = dataRows[i];
      const values: Values = { ...defaultValues(typeId) };
      for (const f of def.fields) {
        const spec = mapping[f.key] ?? "";
        if (spec.startsWith("c:")) values[f.key] = row[Number(spec.slice(2))] ?? "";
        else if (spec.startsWith("v:")) values[f.key] = spec.slice(2);
      }
      const rowNo = i + 1 + (hasHeader ? 1 : 0);
      const b = def.build(values);
      if (!b.ok) {
        errs.push({ row: rowNo, msg: bi(Object.values(b.errors)[0]) });
      } else {
        const m = buildMatrix(typeId, values, style);
        if (!m) errs.push({ row: rowNo, msg: tr("البيانات أطول من سعة الرمز", "Data exceeds QR capacity") });
        else {
          try {
            const blob = await exportBlob(m, style, { format, size, margin: style.margin, transparent: style.bgMode === "transparent", dpi: 300 });
            const label = nameCol !== "" ? (row[Number(nameCol)] ?? "") : "";
            const base = `${String(i + 1).padStart(pad, "0")}${label ? "_" + label : ""}`;
            oks.push({ file: uniqueName(base, EXT[format], used), blob, values, name: label || `QR ${i + 1}` });
          } catch {
            errs.push({ row: rowNo, msg: tr("فشل الرسم", "Render failed") });
          }
        }
      }
      if (i % 5 === 0 || i === dataRows.length - 1) {
        setProgress([i + 1, dataRows.length]);
        setOk([...oks]);
        setErrors([...errs]);
        await tick();
      }
    }
    setOk(oks);
    setErrors(errs);
    setRunning(false);
    if (stopRef.current) toast(tr(`أُوقفت العملية — تم الاحتفاظ بـ ${oks.length} رمزاً صحيحاً`, `Stopped — kept ${oks.length} valid codes`), "info");
  };

  const downloadZip = async () => {
    setBusy(true);
    try {
      const blob = await zipFiles(ok.map((o) => ({ name: o.file, blob: o.blob })));
      downloadBlob(blob, `qr-batch-${new Date().toISOString().slice(0, 10)}.zip`);
    } finally {
      setBusy(false);
    }
  };

  const saveAll = async () => {
    setBusy(true);
    try {
      const list: Project[] = [];
      for (const o of ok) {
        const m = buildMatrix(typeId, o.values, style);
        if (!m) continue;
        list.push({ id: uid(), name: o.name, typeId, values: o.values, style: { ...style }, favorite: false, folderId: null, createdAt: Date.now(), updatedAt: Date.now(), thumb: await thumbnail(m, style) });
        if (list.length % 10 === 0) await tick();
      }
      await dbPutMany("projects", list);
      toast(tr(`تم حفظ ${list.length} مشروعاً في المحفوظات`, `Saved ${list.length} projects to library`));
    } catch {
      toast(tr("تعذّر الحفظ", "Save failed"), "err");
    } finally {
      setBusy(false);
    }
  };

  const colOptions = headers.map((h, i) => (
    <option key={i} value={`c:${i}`}>
      {h}
    </option>
  ));

  return (
    <div className="grid gap-3 md:grid-cols-2">
      {/* data source */}
      <div className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="text-xs font-bold text-muted">{tr("البيانات (سطر لكل رمز أو CSV)", "Data (one line per code, or CSV)")}</div>
          <div className="flex gap-1.5">
            <input ref={fileRef} type="file" accept=".csv,.txt,text/csv,text/plain" className="hidden" onChange={(e) => { importFile(e.target.files?.[0]); e.target.value = ""; }} />
            <Btn size="sm" onClick={() => fileRef.current?.click()}>
              <FileUp size={14} />
              CSV
            </Btn>
            <Btn
              size="sm"
              variant="ghost"
              onClick={() => {
                setTypeId("url");
                setText(EXAMPLE);
                setHasHeader(true);
              }}
            >
              <Wand2 size={14} />
              {tr("مثال", "Example")}
            </Btn>
          </div>
        </div>
        <textarea className="inp h-36 resize-none font-mono text-xs md:h-48" dir="auto" value={text} onChange={(e) => { setText(e.target.value); setOk([]); setErrors([]); }} placeholder={"https://a.com\nhttps://b.com"} />
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" className="h-4 w-4 accent-[var(--primary)]" checked={hasHeader} onChange={(e) => setHasHeader(e.target.checked)} />
          {tr("الصف الأول عناوين أعمدة", "First row is a header")}
        </label>
        <div className="text-xs text-muted">
          {tr(`${dataRows.length} سجل · ${cols} عمود`, `${dataRows.length} records · ${cols} columns`)}
        </div>
      </div>

      {/* settings */}
      <div className="space-y-2.5">
        <div className="grid grid-cols-2 gap-2">
          <div>
            <div className="mb-1 text-xs text-muted">{tr("نوع الرمز", "QR type")}</div>
            <select className="inp" value={typeId} onChange={(e) => setTypeId(e.target.value)}>
              {TYPES.map((t) => (
                <option key={t.id} value={t.id}>
                  {bi(t.label)}
                </option>
              ))}
            </select>
          </div>
          <div>
            <div className="mb-1 text-xs text-muted">{tr("اسم الملف من", "File name from")}</div>
            <select className="inp" value={nameCol} onChange={(e) => setNameCol(e.target.value)}>
              <option value="">{tr("رقم تسلسلي", "Sequence")}</option>
              {headers.map((h, i) => (
                <option key={i} value={String(i)}>
                  {h}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="rounded-2xl border border-line bg-card2 p-2.5">
          <div className="mb-1.5 text-xs font-bold text-muted">{tr("ربط الأعمدة بالحقول", "Map columns to fields")}</div>
          <div className="thin-scroll max-h-40 space-y-1.5 overflow-y-auto pe-1">
            {def.fields.map((f) => {
              const spec = mapping[f.key] ?? "";
              const fixed = spec.startsWith("v:");
              return (
                <div key={f.key} className="grid grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)] items-center gap-2">
                  <span className="truncate text-xs">{bi(f.label)}</span>
                  <div className="flex gap-1">
                    <select
                      className="inp !py-1 text-xs"
                      value={fixed ? "v:" : spec}
                      onChange={(e) => setMapping((m) => ({ ...m, [f.key]: e.target.value === "v:" ? "v:" + (defaultValues(typeId)[f.key] ?? "") : e.target.value }))}
                    >
                      <option value="">—</option>
                      {colOptions}
                      <option value="v:">✎ {tr("قيمة ثابتة", "Fixed value")}</option>
                    </select>
                    {fixed && <input className="inp !py-1 text-xs" value={spec.slice(2)} onChange={(e) => setMapping((m) => ({ ...m, [f.key]: "v:" + e.target.value }))} />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <Segmented<ExportFormat> id="bfmt" value={format} onChange={setFormat} options={FORMATS.map((f) => ({ value: f, label: f.toUpperCase() }))} />
        {format !== "svg" && <Slider label={tr("الحجم", "Size")} value={size} min={128} max={2048} step={64} unit=" px" onChange={setSize} />}
        <p className="text-[11px] text-muted">{tr("يُستخدم التصميم الحالي من شاشة الإنشاء.", "The current design from the Create screen is used.")}</p>

        <div className="flex gap-2">
          {!running ? (
            <Btn variant="primary" className="flex-1" onClick={run} disabled={!dataRows.length}>
              <Play size={16} />
              {tr("إنشاء الدفعة", "Generate batch")}
            </Btn>
          ) : (
            <Btn variant="danger" className="flex-1" onClick={() => (stopRef.current = true)}>
              <Square size={15} />
              {tr("إيقاف (مع حفظ الصحيح)", "Stop (keep valid)")}
            </Btn>
          )}
        </div>
      </div>

      {/* results */}
      {(running || ok.length > 0 || errors.length > 0) && (
        <div className="space-y-2 rounded-2xl border border-line bg-card2 p-3 md:col-span-2">
          <div className="h-2 overflow-hidden rounded-full bg-line">
            <div className="h-full bg-primary transition-all" style={{ width: `${progress[1] ? (progress[0] / progress[1]) * 100 : 0}%` }} />
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span dir="ltr" className="font-mono text-muted">
              {progress[0]} / {progress[1]}
            </span>
            <span className="font-semibold text-emerald-600 dark:text-emerald-400">✓ {ok.length}</span>
            <span className={cx("font-semibold", errors.length ? "text-red-500" : "text-muted")}>✗ {errors.length}</span>
            <div className="ms-auto flex gap-1.5">
              <Btn size="sm" variant="primary" onClick={downloadZip} disabled={!ok.length || running || busy}>
                <Archive size={14} />
                ZIP
              </Btn>
              <Btn size="sm" onClick={saveAll} disabled={!ok.length || running || busy}>
                <Save size={14} />
                {tr("حفظ بالمحفوظات", "Save to library")}
              </Btn>
              <Btn
                size="sm"
                variant="ghost"
                disabled={running}
                onClick={() => {
                  setOk([]);
                  setErrors([]);
                  setProgress([0, 0]);
                }}
              >
                <Trash2 size={14} />
              </Btn>
            </div>
          </div>
          {errors.length > 0 && (
            <ul className="thin-scroll max-h-24 space-y-0.5 overflow-y-auto rounded-xl bg-red-500/8 p-2 text-[11px] text-red-500">
              {errors.map((e, i) => (
                <li key={i}>
                  {tr("السطر", "Row")} {e.row}: {e.msg}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
