import { useEffect, useState } from "react";
import { Download, Monitor, Moon, Sun, Wifi, WifiOff } from "lucide-react";
import { useApp } from "../context";
import { PermissionsPanel } from "./Permissions";
import { Btn, Modal, Segmented, SectionTitle } from "./ui";
import type { Lang, Theme } from "../lib/types";

interface InstallEvent extends Event {
  prompt: () => Promise<void>;
}

export function SettingsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { tr, lang, setLang, theme, setTheme } = useApp();
  const [online, setOnline] = useState(navigator.onLine);
  const [installEv, setInstallEv] = useState<InstallEvent | null>(null);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    const inst = (e: Event) => {
      e.preventDefault();
      setInstallEv(e as InstallEvent);
    };
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    window.addEventListener("beforeinstallprompt", inst);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      window.removeEventListener("beforeinstallprompt", inst);
    };
  }, []);

  return (
    <Modal open={open} onClose={onClose} title={tr("الإعدادات", "Settings")}>
      <div className="space-y-4">
        <div>
          <SectionTitle>{tr("اللغة", "Language")}</SectionTitle>
          <Segmented<Lang>
            id="lang"
            value={lang}
            onChange={setLang}
            options={[
              { value: "ar", label: "العربية" },
              { value: "en", label: "English" },
            ]}
          />
        </div>
        <div>
          <SectionTitle>{tr("المظهر", "Appearance")}</SectionTitle>
          <Segmented<Theme>
            id="theme"
            value={theme}
            onChange={setTheme}
            options={[
              { value: "light", label: <><Sun size={14} />{tr("فاتح", "Light")}</> },
              { value: "dark", label: <><Moon size={14} />{tr("داكن", "Dark")}</> },
              { value: "system", label: <><Monitor size={14} />{tr("النظام", "System")}</> },
            ]}
          />
        </div>
        <div>
          <SectionTitle>{tr("الأذونات", "Permissions")}</SectionTitle>
          <PermissionsPanel />
        </div>
        <div className="flex items-center justify-between gap-2 rounded-2xl border border-line bg-card2 p-3 text-sm">
          <span className="flex items-center gap-2">
            {online ? <Wifi size={16} className="text-emerald-500" /> : <WifiOff size={16} className="text-amber-500" />}
            {online ? tr("متصل — التطبيق يعمل أيضاً دون إنترنت", "Online — also works offline") : tr("وضع عدم الاتصال", "Offline mode")}
          </span>
          {installEv && (
            <Btn
              size="sm"
              variant="primary"
              onClick={async () => {
                await installEv.prompt();
                setInstallEv(null);
              }}
            >
              <Download size={14} />
              {tr("تثبيت", "Install")}
            </Btn>
          )}
        </div>
        <p className="text-center text-[11px] text-muted">{tr("QR Studio — يعمل محلياً بالكامل. لا خوادم ولا حسابات.", "QR Studio — fully local. No servers, no accounts.")}</p>
      </div>
    </Modal>
  );
}
