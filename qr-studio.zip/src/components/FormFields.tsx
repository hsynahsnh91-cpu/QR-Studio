import { Dices, LocateFixed } from "lucide-react";
import { useState } from "react";
import { useApp } from "../context";
import type { FieldDef, TypeDef } from "../lib/qrTypes";
import type { Bi, Values } from "../lib/types";
import { Btn, cx } from "./ui";

interface Props {
  def: TypeDef;
  values: Values;
  errors: Record<string, Bi>;
  touched: Record<string, boolean>;
  onChange: (key: string, value: string) => void;
  onTouch: (key: string) => void;
}

const INPUT_TYPE: Partial<Record<FieldDef["kind"], string>> = {
  text: "text",
  url: "url",
  email: "email",
  tel: "tel",
  password: "text",
  datetime: "datetime-local",
  date: "date",
};

export function FormFields({ def, values, errors, touched, onChange, onTouch }: Props) {
  const { bi, tr, toast } = useApp();
  const [locating, setLocating] = useState(false);

  const locate = () => {
    if (!navigator.geolocation) return toast(tr("الموقع غير مدعوم", "Geolocation unsupported"), "err");
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        onChange("lat", p.coords.latitude.toFixed(6));
        onChange("lng", p.coords.longitude.toFixed(6));
        setLocating(false);
      },
      () => {
        setLocating(false);
        toast(tr("تعذّر الحصول على الموقع — تحقق من الإذن", "Couldn't get location — check permission"), "err");
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  return (
    <div className="grid grid-cols-2 gap-x-2.5 gap-y-2.5">
      {def.fields
        .filter((f) => !f.showIf || f.showIf(values))
        .map((f) => {
          const err = touched[f.key] ? errors[f.key] : undefined;
          const common = {
            id: `f-${f.key}`,
            value: values[f.key] ?? "",
            onBlur: () => onTouch(f.key),
            dir: f.ltr ? ("ltr" as const) : undefined,
            className: cx("inp", err && "err", f.ltr && "text-start"),
            placeholder: f.placeholder,
          };
          return (
            <div key={f.key} className={cx(f.span === 2 || f.kind === "textarea" ? "col-span-2" : "col-span-2 sm:col-span-1")}>
              {f.kind !== "checkbox" && (
                <label htmlFor={`f-${f.key}`} className="mb-1 block text-xs font-medium text-muted">
                  {bi(f.label)}
                  {Object.prototype.hasOwnProperty.call(errors, f.key) && <span className="text-red-500"> *</span>}
                </label>
              )}
              {f.kind === "textarea" ? (
                <textarea {...common} rows={3} onChange={(e) => onChange(f.key, e.target.value)} className={cx(common.className, "min-h-[4.5rem] resize-none")} />
              ) : f.kind === "select" ? (
                <select {...common} onChange={(e) => onChange(f.key, e.target.value)}>
                  {f.options!.map((o) => (
                    <option key={o.value} value={o.value}>
                      {bi(o.label)}
                    </option>
                  ))}
                </select>
              ) : f.kind === "checkbox" ? (
                <label className="flex cursor-pointer items-center gap-2 py-2 text-sm">
                  <input type="checkbox" className="h-4 w-4 accent-[var(--primary)]" checked={values[f.key] === "true"} onChange={(e) => onChange(f.key, e.target.checked ? "true" : "")} />
                  {bi(f.label)}
                </label>
              ) : (
                <div className="flex gap-1.5">
                  <input
                    {...common}
                    type={f.kind === "password" ? "text" : (INPUT_TYPE[f.kind] ?? "text")}
                    inputMode={f.kind === "number" ? "decimal" : undefined}
                    autoComplete="off"
                    onChange={(e) => onChange(f.key, e.target.value)}
                  />
                  {f.action === "ticketId" && (
                    <Btn
                      size="sm"
                      className="shrink-0"
                      onClick={() => onChange("ticketId", "TK-" + Math.random().toString(36).slice(2, 6).toUpperCase() + "-" + Date.now().toString(36).toUpperCase().slice(-5))}
                      title={tr("توليد رقم", "Generate")}
                    >
                      <Dices size={14} />
                    </Btn>
                  )}
                </div>
              )}
              {f.action === "geo" && (
                <Btn size="sm" variant="ghost" className="mt-1.5 !px-2" onClick={locate} disabled={locating}>
                  <LocateFixed size={14} />
                  {locating ? tr("جارٍ التحديد…", "Locating…") : tr("استخدام موقعي الحالي", "Use my location")}
                </Btn>
              )}
              {err && <p className="mt-1 text-[11px] text-red-500">{bi(err)}</p>}
            </div>
          );
        })}
    </div>
  );
}
