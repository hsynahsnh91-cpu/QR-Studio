import { useEffect, useState } from "react";
import { Save, Star } from "lucide-react";
import { useApp } from "../context";
import type { QRState } from "../hooks";
import type { DraftApi } from "../useDraft";
import { getType } from "../lib/qrTypes";
import { thumbnail } from "../lib/exporter";
import { dbPut, getFolders, getProjects } from "../lib/storage";
import { uid, type Folder, type Project } from "../lib/types";
import { Btn, Modal } from "./ui";
import { cx } from "./ui";

export function SaveModal({ open, onClose, api, qr, onSaved }: { open: boolean; onClose: () => void; api: DraftApi; qr: QRState; onSaved: (p: Project) => void }) {
  const { tr, bi, toast } = useApp();
  const [name, setName] = useState("");
  const [folderId, setFolderId] = useState("");
  const [fav, setFav] = useState(false);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [existing, setExisting] = useState<Project | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    const def = getType(api.typeId);
    const hint = api.typeId === "wifi" ? (api.values.ssid ?? "") : qr.build.data.replace(/\s+/g, " ").slice(0, 24);
    const auto = api.draft.name || `${bi(def.label)} · ${hint}`;
    setName(auto);
    Promise.all([getFolders(), getProjects()]).then(([f, p]) => {
      setFolders(f);
      const ex = api.draft.editingId ? (p.find((x) => x.id === api.draft.editingId) ?? null) : null;
      setExisting(ex);
      setFolderId(ex?.folderId ?? "");
      setFav(ex?.favorite ?? false);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const save = async (asNew: boolean) => {
    if (!qr.matrix || !name.trim()) return;
    setBusy(true);
    try {
      const now = Date.now();
      const thumb = await thumbnail(qr.matrix, api.style);
      const base = existing && !asNew ? existing : null;
      const p: Project = {
        id: base?.id ?? uid(),
        name: name.trim(),
        typeId: api.typeId,
        values: { ...api.values },
        style: { ...api.style },
        favorite: fav,
        folderId: folderId || null,
        createdAt: base?.createdAt ?? now,
        updatedAt: now,
        thumb,
      };
      await dbPut("projects", p);
      onSaved(p);
      toast(base ? tr("تم تحديث المشروع", "Project updated") : tr("تم الحفظ في المحفوظات", "Saved to library"));
      onClose();
    } catch {
      toast(tr("تعذّر الحفظ — تحقق من مساحة التخزين", "Couldn't save — check storage"), "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={existing ? tr("تحديث المشروع", "Update project") : tr("حفظ المشروع", "Save project")}>
      <div className="space-y-3">
        <div>
          <label className="mb-1 block text-xs text-muted">{tr("الاسم", "Name")}</label>
          <input className="inp" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted">{tr("المجلد", "Folder")}</label>
          <select className="inp" value={folderId} onChange={(e) => setFolderId(e.target.value)}>
            <option value="">{tr("بدون مجلد", "No folder")}</option>
            {folders.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </div>
        <button onClick={() => setFav(!fav)} className="flex items-center gap-2 text-sm">
          <Star size={18} className={cx(fav ? "fill-amber-400 text-amber-400" : "text-muted")} />
          {tr("إضافة إلى المفضلة", "Add to favorites")}
        </button>
        <div className="flex gap-2 pt-1">
          <Btn variant="primary" className="flex-1" onClick={() => save(false)} disabled={busy || !name.trim()}>
            <Save size={16} />
            {existing ? tr("تحديث", "Update") : tr("حفظ", "Save")}
          </Btn>
          {existing && (
            <Btn className="flex-1" onClick={() => save(true)} disabled={busy || !name.trim()}>
              {tr("حفظ كنسخة", "Save as copy")}
            </Btn>
          )}
        </div>
      </div>
    </Modal>
  );
}
