import { useEffect, useMemo, useRef, useState } from "react";
import { Frame, ImagePlus, LayoutTemplate, Palette, RotateCcw, Settings2, Shapes, Trash2 } from "lucide-react";
import { useApp } from "../context";
import type { DraftApi } from "../useDraft";
import { useReadability, useSample, type QRState } from "../hooks";
import { makeMatrix, renderSVG, styleWarnings, svgDataUrl, contrast } from "../lib/qrRender";
import { dbDelete, dbPut, fileToLogo, getImages } from "../lib/storage";
import { uid, type DotShape, type Ecc, type EyeShape, type FrameKind, type LogoImage, type QRStyle } from "../lib/types";
import { QRImage, ReadBadge, Warnings } from "./QRParts";
import { Btn, ColorField, Modal, Segmented, SectionTitle, Slider, Toggle, cx } from "./ui";

type Tab = "templates" | "colors" | "shapes" | "logo" | "frame" | "advanced";

const BASE_VISUAL: Partial<QRStyle> = {
  fg: "#111827",
  fg2: "#6d5efc",
  gradient: "none",
  angle: 45,
  bg: "#ffffff",
  bg2: "#e0e7ff",
  bgMode: "solid",
  dot: "square",
  eyeFrame: "square",
  eyeBall: "square",
  eyeCustom: false,
};

const TEMPLATES: { id: string; name: [string, string]; style: Partial<QRStyle> }[] = [
  { id: "classic", name: ["كلاسيكي", "Classic"], style: {} },
  { id: "ocean", name: ["محيط", "Ocean"], style: { fg: "#0369a1", fg2: "#6366f1", gradient: "linear", dot: "rounded", eyeFrame: "rounded", eyeBall: "circle" } },
  { id: "sunset", name: ["غروب", "Sunset"], style: { fg: "#ea580c", fg2: "#be185d", gradient: "linear", angle: 135, dot: "dot", eyeFrame: "circle", eyeBall: "circle" } },
  { id: "forest", name: ["غابة", "Forest"], style: { fg: "#064e3b", fg2: "#059669", gradient: "linear", dot: "classy", eyeFrame: "leaf", eyeBall: "leaf", bg: "#f0fdf4" } },
  { id: "violet", name: ["بنفسجي", "Violet"], style: { fg: "#4c1d95", fg2: "#7c3aed", gradient: "radial", dot: "rounded", eyeFrame: "rounded", eyeBall: "rounded", bgMode: "gradient", bg: "#f5f3ff", bg2: "#ffffff" } },
  { id: "candy", name: ["حلوى", "Candy"], style: { fg: "#be185d", bg: "#fdf2f8", dot: "diamond", eyeFrame: "rounded", eyeBall: "circle" } },
  { id: "gold", name: ["ذهبي", "Gold"], style: { fg: "#78350f", fg2: "#d97706", gradient: "linear", bg: "#fffbeb", dot: "classy", eyeFrame: "leaf", eyeBall: "leaf" } },
  { id: "lines", name: ["خطوط", "Lines"], style: { fg: "#0f172a", dot: "lines", eyeFrame: "rounded", eyeBall: "rounded" } },
  { id: "pop", name: ["إطار", "Framed"], style: { fg: "#111827", dot: "rounded", eyeFrame: "rounded", eyeBall: "circle", frame: "bottom", frameColor: "#6d5efc", frameTextColor: "#ffffff" } },
  { id: "clear", name: ["شفاف", "Clear"], style: { bgMode: "transparent", fg: "#111827", dot: "dot", eyeFrame: "circle", eyeBall: "circle" } },
];

const DOTS: { v: DotShape; l: [string, string] }[] = [
  { v: "square", l: ["مربع", "Square"] },
  { v: "rounded", l: ["مدوّر", "Rounded"] },
  { v: "dot", l: ["دوائر", "Dots"] },
  { v: "diamond", l: ["معيّن", "Diamond"] },
  { v: "classy", l: ["أنيق", "Classy"] },
  { v: "lines", l: ["خطوط", "Lines"] },
];
const EYES: { v: EyeShape; l: [string, string] }[] = [
  { v: "square", l: ["مربع", "Square"] },
  { v: "rounded", l: ["مدوّر", "Rounded"] },
  { v: "circle", l: ["دائري", "Circle"] },
  { v: "leaf", l: ["ورقة", "Leaf"] },
];
const FRAMES: { v: FrameKind; l: [string, string] }[] = [
  { v: "none", l: ["بدون", "None"] },
  { v: "border", l: ["حدود", "Border"] },
  { v: "bottom", l: ["نص أسفل", "Bottom"] },
  { v: "top", l: ["نص أعلى", "Top"] },
  { v: "bubble", l: ["فقاعة", "Bubble"] },
  { v: "text", l: ["نص فقط", "Text only"] },
];
const FRAME_TEXTS = ["Scan Me", "امسحني", "امسح للدفع", "Scan to pay", "تابعنا", "Follow us", "امسح للاتصال", "Menu", "قائمة الطعام"];

const mkLogo = (path: string, color: string) =>
  "data:image/svg+xml;charset=utf-8," +
  encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect width="24" height="24" fill="${color}"/><path fill="#fff" d="${path}"/></svg>`);
const BUILTIN_LOGOS = [
  { id: "star", src: mkLogo("M12 4l2.3 4.8 5.2.7-3.8 3.7.9 5.2L12 15.8 7.4 18.4l.9-5.2L4.5 9.5l5.2-.7z", "#f59e0b") },
  { id: "heart", src: mkLogo("M12 19s-6.5-4-6.5-8.3A3.5 3.5 0 0 1 12 9a3.5 3.5 0 0 1 6.5 1.7C18.5 15 12 19 12 19z", "#e11d48") },
  { id: "bolt", src: mkLogo("M13 3L6 13h5l-1 8 7-10h-5z", "#6d5efc") },
  { id: "pin", src: mkLogo("M12 4a5.5 5.5 0 0 0-5.5 5.5C6.5 14 12 20 12 20s5.5-6 5.5-10.5A5.5 5.5 0 0 0 12 4zm0 7.5a2 2 0 1 1 0-4 2 2 0 0 1 0 4z", "#0891b2") },
  { id: "check", src: mkLogo("M9.5 16.2L6 12.7l-1.4 1.4 4.9 4.9L19.4 9l-1.4-1.4z", "#059669") },
];

function Thumb({ style, matrix }: { style: QRStyle; matrix: ReturnType<typeof makeMatrix> }) {
  const src = useMemo(() => svgDataUrl(renderSVG(matrix, { ...style, logo: null }).svg), [style, matrix]);
  return <img src={src} alt="" className="h-full w-full rounded-md bg-white object-contain" draggable={false} />;
}

interface Props {
  open: boolean;
  onClose: () => void;
  api: DraftApi;
  qr: QRState;
  heroId: string;
}

export function CustomizeModal({ open, onClose, api, qr, heroId }: Props) {
  const { tr, bi, toast } = useApp();
  const st = api.style;
  const [tab, setTab] = useState<Tab>("templates");
  const [library, setLibrary] = useState<LogoImage[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const sample = useSample(st);
  const sampleMatrix = useMemo(() => makeMatrix("QR", "M"), []);
  const read = useReadability(qr.matrix, st, qr.build.data);
  const warnings = useMemo(() => styleWarnings(st), [st]);
  const set = api.patchStyle;

  useEffect(() => {
    if (open) getImages().then((l) => setLibrary(l.sort((a, b) => b.createdAt - a.createdAt))).catch(() => undefined);
  }, [open]);

  const setLogo = (src: string) => {
    const keep = st.logo;
    set({
      logo: { src, size: keep?.size ?? 0.2, x: keep?.x ?? 0, y: keep?.y ?? 0, shape: keep?.shape ?? "square", plate: keep?.plate ?? true, clear: keep?.clear ?? true },
      ecc: "H",
    });
  };

  const upload = async (file?: File) => {
    if (!file) return;
    try {
      const src = await fileToLogo(file);
      const img: LogoImage = { id: uid(), name: file.name, src, createdAt: Date.now() };
      await dbPut("images", img);
      setLibrary((l) => [img, ...l]);
      setLogo(src);
    } catch {
      toast(tr("تعذّر قراءة الصورة", "Couldn't read the image"), "err");
    }
  };

  const contrastVal = contrast(st.fg, st.bgMode === "transparent" ? "#ffffff" : st.bg);

  const tabs: { v: Tab; icon: typeof Palette; l: string }[] = [
    { v: "templates", icon: LayoutTemplate, l: tr("قوالب", "Presets") },
    { v: "colors", icon: Palette, l: tr("ألوان", "Colors") },
    { v: "shapes", icon: Shapes, l: tr("أشكال", "Shapes") },
    { v: "logo", icon: ImagePlus, l: tr("شعار", "Logo") },
    { v: "frame", icon: Frame, l: tr("إطار", "Frame") },
    { v: "advanced", icon: Settings2, l: tr("متقدم", "More") },
  ];

  return (
    <Modal open={open} onClose={onClose} title={tr("تخصيص التصميم", "Customize design")} wide>
      <div className="mb-3 flex items-center gap-3">
        <QRImage heroId={heroId} src={qr.matrix ? qr.src : sample} dim={!qr.matrix} transparent={st.bgMode === "transparent"} className="h-28 w-28 shrink-0" />
        <div className="min-w-0 flex-1 space-y-2">
          {qr.matrix ? <ReadBadge state={read} /> : <span className="text-xs text-muted">{tr("معاينة بيانات تجريبية", "Sample data preview")}</span>}
          <Warnings list={warnings} max={3} />
        </div>
      </div>

      <div className="mb-3 grid grid-cols-6 gap-1 rounded-2xl border border-line bg-card2 p-1">
        {tabs.map((t) => (
          <button
            key={t.v}
            onClick={() => setTab(t.v)}
            className={cx("flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[10px] font-semibold transition", tab === t.v ? "bg-primary text-primary-fg shadow" : "text-muted hover:text-fg")}
          >
            <t.icon size={16} />
            {t.l}
          </button>
        ))}
      </div>

      {tab === "templates" && (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
          {TEMPLATES.map((t) => {
            const preview = { ...st, ...BASE_VISUAL, ...t.style, frame: t.style.frame ?? "none" } as QRStyle;
            return (
              <button
                key={t.id}
                onClick={() => set({ ...BASE_VISUAL, ...t.style })}
                className="group rounded-2xl border border-line bg-card2 p-1.5 text-center transition hover:border-primary active:scale-95"
              >
                <div className="aspect-square">
                  <Thumb style={preview} matrix={sampleMatrix} />
                </div>
                <div className="mt-1 text-[11px] font-semibold">{bi(t.name)}</div>
              </button>
            );
          })}
        </div>
      )}

      {tab === "colors" && (
        <div className="space-y-3">
          <SectionTitle>{tr("لون الرمز", "Foreground")}</SectionTitle>
          <Segmented
            id="grad"
            value={st.gradient}
            onChange={(v) => set({ gradient: v })}
            options={[
              { value: "none", label: tr("لون واحد", "Solid") },
              { value: "linear", label: tr("خطي", "Linear") },
              { value: "radial", label: tr("دائري", "Radial") },
            ]}
          />
          <div className="grid grid-cols-2 gap-3">
            <ColorField label={tr("اللون", "Color")} value={st.fg} onChange={(v) => set({ fg: v })} />
            {st.gradient !== "none" && <ColorField label={tr("اللون الثاني", "Second color")} value={st.fg2} onChange={(v) => set({ fg2: v })} />}
          </div>
          {st.gradient === "linear" && <Slider label={tr("زاوية التدرج", "Angle")} value={st.angle} min={0} max={360} step={5} unit="°" onChange={(v) => set({ angle: v })} />}

          <SectionTitle>{tr("الخلفية", "Background")}</SectionTitle>
          <Segmented
            id="bgm"
            value={st.bgMode}
            onChange={(v) => set({ bgMode: v })}
            options={[
              { value: "solid", label: tr("لون", "Solid") },
              { value: "gradient", label: tr("تدرج", "Gradient") },
              { value: "transparent", label: tr("شفافة", "Transparent") },
            ]}
          />
          {st.bgMode !== "transparent" && (
            <div className="grid grid-cols-2 gap-3">
              <ColorField label={tr("لون الخلفية", "Background")} value={st.bg} onChange={(v) => set({ bg: v })} />
              {st.bgMode === "gradient" && <ColorField label={tr("اللون الثاني", "Second color")} value={st.bg2} onChange={(v) => set({ bg2: v })} />}
            </div>
          )}

          <SectionTitle>{tr("ألوان الزوايا", "Corner colors")}</SectionTitle>
          <Toggle checked={st.eyeCustom} onChange={(v) => set({ eyeCustom: v })} label={tr("ألوان مخصصة للزوايا", "Custom corner colors")} />
          {st.eyeCustom && (
            <div className="grid grid-cols-2 gap-3">
              <ColorField label={tr("إطار الزاوية", "Frame")} value={st.eyeFrameColor} onChange={(v) => set({ eyeFrameColor: v })} />
              <ColorField label={tr("مركز الزاوية", "Center")} value={st.eyeBallColor} onChange={(v) => set({ eyeBallColor: v })} />
            </div>
          )}
          <p className="text-xs text-muted" dir="ltr">
            {tr("نسبة التباين", "Contrast")}: {contrastVal.toFixed(1)}:1
          </p>
        </div>
      )}

      {tab === "shapes" && (
        <div className="space-y-3">
          <SectionTitle>{tr("شكل النقاط", "Dots")}</SectionTitle>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
            {DOTS.map((d) => (
              <ShapeBtn key={d.v} on={st.dot === d.v} label={bi(d.l)} onClick={() => set({ dot: d.v })}>
                <Thumb style={{ ...st, dot: d.v, frame: "none", gradient: "none", bgMode: "solid", bg: "#fff", fg: "#111827", eyeCustom: false }} matrix={sampleMatrix} />
              </ShapeBtn>
            ))}
          </div>
          <SectionTitle>{tr("إطار الزاوية", "Corner frame")}</SectionTitle>
          <div className="grid grid-cols-4 gap-2">
            {EYES.map((d) => (
              <ShapeBtn key={d.v} on={st.eyeFrame === d.v} label={bi(d.l)} onClick={() => set({ eyeFrame: d.v })}>
                <Thumb style={{ ...st, eyeFrame: d.v, frame: "none", gradient: "none", bgMode: "solid", bg: "#fff", fg: "#111827", eyeCustom: false }} matrix={sampleMatrix} />
              </ShapeBtn>
            ))}
          </div>
          <SectionTitle>{tr("مركز الزاوية", "Corner center")}</SectionTitle>
          <div className="grid grid-cols-4 gap-2">
            {EYES.map((d) => (
              <ShapeBtn key={d.v} on={st.eyeBall === d.v} label={bi(d.l)} onClick={() => set({ eyeBall: d.v })}>
                <Thumb style={{ ...st, eyeBall: d.v, frame: "none", gradient: "none", bgMode: "solid", bg: "#fff", fg: "#111827", eyeCustom: false }} matrix={sampleMatrix} />
              </ShapeBtn>
            ))}
          </div>
        </div>
      )}

      {tab === "logo" && (
        <div className="space-y-3">
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ""; }} />
          <div className="flex gap-2">
            <Btn variant="primary" onClick={() => fileRef.current?.click()} className="flex-1">
              <ImagePlus size={16} />
              {tr("رفع صورة من الجهاز", "Upload from device")}
            </Btn>
            {st.logo && (
              <Btn variant="danger" onClick={() => set({ logo: null })}>
                <Trash2 size={16} />
                {tr("إزالة", "Remove")}
              </Btn>
            )}
          </div>
          <SectionTitle>{tr("شعارات جاهزة", "Built-in")}</SectionTitle>
          <div className="flex flex-wrap gap-2">
            {BUILTIN_LOGOS.map((l) => (
              <button key={l.id} onClick={() => setLogo(l.src)} className={cx("h-12 w-12 overflow-hidden rounded-xl border-2 transition active:scale-95", st.logo?.src === l.src ? "border-primary" : "border-line")}>
                <img src={l.src} alt={l.id} className="h-full w-full" />
              </button>
            ))}
          </div>
          {library.length > 0 && (
            <>
              <SectionTitle>{tr("صوري المحفوظة", "My images")}</SectionTitle>
              <div className="flex flex-wrap gap-2">
                {library.map((l) => (
                  <div key={l.id} className="group relative">
                    <button onClick={() => setLogo(l.src)} className={cx("h-12 w-12 overflow-hidden rounded-xl border-2 bg-white transition active:scale-95", st.logo?.src === l.src ? "border-primary" : "border-line")}>
                      <img src={l.src} alt={l.name} className="h-full w-full object-cover" />
                    </button>
                    <button
                      aria-label={tr("حذف", "Delete")}
                      onClick={async () => {
                        await dbDelete("images", l.id);
                        setLibrary((x) => x.filter((i) => i.id !== l.id));
                      }}
                      className="absolute -end-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-red-500 text-white shadow"
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}
          {st.logo && (
            <div className="space-y-3 rounded-2xl border border-line bg-card2 p-3">
              <Slider label={tr("الحجم", "Size")} value={Math.round(st.logo.size * 100)} min={10} max={35} unit="%" onChange={(v) => set({ logo: { ...st.logo!, size: v / 100 } })} />
              <div className="grid grid-cols-2 gap-3">
                <Slider label={tr("أفقي", "Horizontal")} value={st.logo.x} min={-30} max={30} unit="%" onChange={(v) => set({ logo: { ...st.logo!, x: v } })} />
                <Slider label={tr("رأسي", "Vertical")} value={st.logo.y} min={-30} max={30} unit="%" onChange={(v) => set({ logo: { ...st.logo!, y: v } })} />
              </div>
              <Segmented
                id="lshape"
                value={st.logo.shape}
                onChange={(v) => set({ logo: { ...st.logo!, shape: v } })}
                options={[
                  { value: "square", label: tr("مربع", "Square") },
                  { value: "circle", label: tr("دائري", "Circle") },
                ]}
              />
              <Toggle checked={st.logo.plate} onChange={(v) => set({ logo: { ...st.logo!, plate: v } })} label={tr("خلفية خلف الشعار", "Backing plate")} />
              <Toggle checked={st.logo.clear} onChange={(v) => set({ logo: { ...st.logo!, clear: v } })} label={tr("إخفاء النقاط خلف الشعار", "Clear dots behind logo")} />
            </div>
          )}
        </div>
      )}

      {tab === "frame" && (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            {FRAMES.map((f) => (
              <ShapeBtn key={f.v} on={st.frame === f.v} label={bi(f.l)} onClick={() => set({ frame: f.v })}>
                <Thumb style={{ ...st, frame: f.v, logo: null, frameText: st.frameText || "Scan" }} matrix={sampleMatrix} />
              </ShapeBtn>
            ))}
          </div>
          {st.frame !== "none" && st.frame !== "border" && (
            <>
              <div>
                <div className="mb-1 text-xs text-muted">{tr("نص الإطار", "Frame text")}</div>
                <input className="inp" value={st.frameText} maxLength={32} onChange={(e) => set({ frameText: e.target.value })} />
              </div>
              <div className="flex flex-wrap gap-1.5">
                {FRAME_TEXTS.map((t) => (
                  <button key={t} onClick={() => set({ frameText: t })} className={cx("rounded-full border px-2.5 py-1 text-xs font-medium transition", st.frameText === t ? "border-primary bg-primary/10 text-primary" : "border-line bg-card2 text-muted hover:text-fg")}>
                    {t}
                  </button>
                ))}
              </div>
            </>
          )}
          {st.frame !== "none" && (
            <div className="grid grid-cols-2 gap-3">
              <ColorField label={st.frame === "text" ? tr("لون النص", "Text color") : tr("لون الإطار", "Frame color")} value={st.frameColor} onChange={(v) => set({ frameColor: v })} />
              {st.frame !== "text" && st.frame !== "border" && <ColorField label={tr("لون النص", "Text color")} value={st.frameTextColor} onChange={(v) => set({ frameTextColor: v })} />}
            </div>
          )}
        </div>
      )}

      {tab === "advanced" && (
        <div className="space-y-3">
          <SectionTitle>{tr("تصحيح الأخطاء", "Error correction")}</SectionTitle>
          <Segmented<Ecc>
            id="ecc"
            value={st.ecc}
            onChange={(v) => set({ ecc: v })}
            options={[
              { value: "L", label: "L 7%" },
              { value: "M", label: "M 15%" },
              { value: "Q", label: "Q 25%" },
              { value: "H", label: "H 30%" },
            ]}
          />
          <p className="text-xs text-muted">{tr("مستوى أعلى يتحمل تلفاً/شعاراً أكبر لكنه يزيد كثافة الرمز.", "Higher levels survive damage/larger logos but make the code denser.")}</p>
          <Slider label={tr("الهامش (وحدات)", "Quiet zone (modules)")} value={st.margin} min={0} max={10} onChange={(v) => set({ margin: v })} />
          <Btn onClick={api.resetStyle} className="w-full">
            <RotateCcw size={15} />
            {tr("إعادة ضبط التصميم", "Reset design")}
          </Btn>
        </div>
      )}
    </Modal>
  );
}

function ShapeBtn({ on, label, onClick, children }: { on: boolean; label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={cx("rounded-2xl border-2 p-1.5 text-center transition active:scale-95", on ? "border-primary bg-primary/10" : "border-line bg-card2 hover:border-primary/50")}>
      <div className="mx-auto aspect-square w-full max-w-[84px]">{children}</div>
      <div className="mt-1 text-[11px] font-semibold">{label}</div>
    </button>
  );
}
