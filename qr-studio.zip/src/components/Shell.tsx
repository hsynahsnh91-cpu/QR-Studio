import { motion } from "framer-motion";
import { FolderOpen, Languages, Moon, QrCode, ScanLine, Settings, Sun, Wrench } from "lucide-react";
import { useApp } from "../context";
import type { View } from "../lib/types";
import { IconBtn, cx } from "./ui";

export function TopBar({ onSettings }: { onSettings: () => void }) {
  const { tr, lang, setLang, dark, setTheme } = useApp();
  return (
    <header className="flex h-12 shrink-0 items-center justify-between gap-2 px-3 pt-[env(safe-area-inset-top)]">
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-primary text-primary-fg shadow-md shadow-primary/30">
          <QrCode size={18} />
        </span>
        <span className="text-base font-extrabold tracking-tight">
          QR <span className="text-primary">Studio</span>
        </span>
      </div>
      <div className="flex items-center gap-0.5">
        <IconBtn label={tr("English", "العربية")} onClick={() => setLang(lang === "ar" ? "en" : "ar")}>
          <Languages size={18} />
        </IconBtn>
        <IconBtn label={tr("تبديل المظهر", "Toggle theme")} onClick={() => setTheme(dark ? "light" : "dark")}>
          {dark ? <Sun size={18} /> : <Moon size={18} />}
        </IconBtn>
        <IconBtn label={tr("الإعدادات", "Settings")} onClick={onSettings}>
          <Settings size={18} />
        </IconBtn>
      </div>
    </header>
  );
}

export function BottomNav({ view, onChange }: { view: View; onChange: (v: View) => void }) {
  const { tr } = useApp();
  const items: { v: View; icon: typeof QrCode; label: string }[] = [
    { v: "create", icon: QrCode, label: tr("إنشاء", "Create") },
    { v: "scan", icon: ScanLine, label: tr("قراءة", "Scan") },
    { v: "library", icon: FolderOpen, label: tr("المحفوظات", "Library") },
    { v: "tools", icon: Wrench, label: tr("أدوات", "Tools") },
  ];
  return (
    <nav className="shrink-0 px-3 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1">
      <div className="mx-auto flex max-w-md gap-1 rounded-3xl border border-line bg-card p-1 shadow-lg shadow-black/5">
        {items.map((it) => {
          const on = view === it.v;
          return (
            <button key={it.v} onClick={() => onChange(it.v)} aria-label={it.label} aria-current={on ? "page" : undefined} className={cx("relative flex flex-1 items-center justify-center gap-1.5 rounded-2xl py-2 text-xs font-bold transition-colors", on ? "text-primary-fg" : "text-muted hover:text-fg")}>
              {on && <motion.span layoutId="nav-pill" className="absolute inset-0 rounded-2xl bg-primary shadow-md shadow-primary/30" transition={{ type: "spring", damping: 28, stiffness: 380 }} />}
              <it.icon size={18} className="relative z-10" />
              <span className={cx("relative z-10", !on && "hidden sm:inline")}>{it.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
