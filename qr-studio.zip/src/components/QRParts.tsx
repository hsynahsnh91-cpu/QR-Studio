import { motion } from "framer-motion";
import { CheckCircle2, Loader2, ShieldAlert, TriangleAlert } from "lucide-react";
import { useApp } from "../context";
import type { Readability } from "../lib/scan";
import type { StyleWarning } from "../lib/qrRender";
import { cx } from "./ui";

/** The QR image with a shared "hero" layout id so it morphs between screens. */
export function QRImage({ heroId, src, className, dim, transparent }: { heroId: string; src: string; className?: string; dim?: boolean; transparent?: boolean }) {
  return (
    <motion.div
      layoutId={heroId}
      transition={{ type: "spring", damping: 30, stiffness: 260 }}
      className={cx("overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-line", transparent && "checker", className)}
    >
      <img src={src} alt="QR code" draggable={false} className={cx("block h-full w-full select-none", dim && "opacity-25 blur-[1px]")} />
    </motion.div>
  );
}

export function ReadBadge({ state, onRetest, compact }: { state: Readability | "idle"; onRetest?: () => void; compact?: boolean }) {
  const { tr } = useApp();
  const map = {
    idle: { icon: <Loader2 size={14} className="animate-spin" />, text: tr("جارٍ الاختبار…", "Testing…"), cls: "bg-card2 text-muted" },
    ok: { icon: <CheckCircle2 size={14} />, text: tr("يُقرأ بنجاح", "Scans OK"), cls: "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400" },
    differs: { icon: <TriangleAlert size={14} />, text: tr("قراءة مختلفة", "Reads differently"), cls: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
    fail: { icon: <ShieldAlert size={14} />, text: tr("لا يُقرأ!", "Not readable!"), cls: "bg-red-500/12 text-red-500" },
  }[state];
  return (
    <button
      onClick={onRetest}
      title={tr("اختبار القراءة الفعلي — اضغط لإعادة الاختبار", "Real scan test — tap to retest")}
      className={cx("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold", map.cls)}
    >
      {map.icon}
      {!compact && map.text}
      {compact && <span className="sr-only">{map.text}</span>}
    </button>
  );
}

export function Warnings({ list, max }: { list: StyleWarning[]; max?: number }) {
  const { bi } = useApp();
  if (!list.length) return null;
  return (
    <ul className="space-y-1">
      {list.slice(0, max ?? list.length).map((w) => (
        <li key={w.id} className={cx("flex items-start gap-1.5 rounded-lg px-2 py-1 text-[11px] leading-snug", w.level === "error" ? "bg-red-500/10 text-red-500" : "bg-amber-500/10 text-amber-600 dark:text-amber-400")}>
          <TriangleAlert size={12} className="mt-0.5 shrink-0" />
          <span>{bi(w.text)}</span>
        </li>
      ))}
    </ul>
  );
}
