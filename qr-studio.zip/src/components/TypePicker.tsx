import { motion } from "framer-motion";
import { useApp } from "../context";
import { GROUPS, TYPES } from "../lib/qrTypes";
import { Modal, cx } from "./ui";

export function TypePicker({ open, onClose, current, onPick }: { open: boolean; onClose: () => void; current: string; onPick: (id: string) => void }) {
  const { tr, bi } = useApp();
  return (
    <Modal open={open} onClose={onClose} title={tr("اختر نوع الرمز", "Choose QR type")} wide>
      <div className="space-y-4">
        {GROUPS.map((g) => (
          <section key={g.id}>
            <div className="mb-1.5 text-xs font-bold text-muted">{bi(g.label)}</div>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {TYPES.filter((t) => t.group === g.id).map((t) => {
                const Icon = t.icon;
                const on = t.id === current;
                return (
                  <button
                    key={t.id}
                    onClick={() => {
                      onPick(t.id);
                      onClose();
                    }}
                    className={cx("flex flex-col items-center gap-1.5 rounded-2xl border p-2.5 text-center text-xs font-semibold transition hover:border-primary/60 active:scale-95", on ? "border-primary bg-primary/10" : "border-line bg-card2")}
                  >
                    <motion.span layoutId={`type-${t.id}`} className={cx("grid h-9 w-9 place-items-center rounded-xl", on ? "bg-primary text-primary-fg" : "bg-card text-primary")}>
                      <Icon size={18} />
                    </motion.span>
                    <span className="leading-tight">{bi(t.label)}</span>
                  </button>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </Modal>
  );
}
