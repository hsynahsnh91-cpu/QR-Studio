import { useCallback, useEffect, useRef, useState } from "react";
import { Camera, CheckCircle2, HardDrive, Image as ImageIcon, ShieldCheck } from "lucide-react";
import { useApp } from "../context";
import { flag, setFlag } from "../lib/storage";
import { Btn, Modal, cx } from "./ui";

type Status = "granted" | "denied" | "prompt" | "unsupported";

const fmtBytes = (n: number) => (n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB");

export function PermissionsPanel() {
  const { tr, toast } = useApp();
  const [cam, setCam] = useState<Status>("prompt");
  const [storage, setStorage] = useState<boolean | null>(null);
  const [usage, setUsage] = useState("");
  const [photos, setPhotos] = useState(() => flag("photos"));
  const fileRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(async () => {
    try {
      const p = await navigator.permissions.query({ name: "camera" as PermissionName });
      setCam(p.state as Status);
      p.onchange = () => setCam(p.state as Status);
    } catch {
      if (!navigator.mediaDevices?.getUserMedia) setCam("unsupported");
    }
    try {
      if (navigator.storage?.persisted) setStorage(await navigator.storage.persisted());
      if (navigator.storage?.estimate) {
        const e = await navigator.storage.estimate();
        setUsage(`${fmtBytes(e.usage ?? 0)} / ${fmtBytes(e.quota ?? 0)}`);
      }
    } catch {
      /* ignore */
    }
  }, []);
  useEffect(() => {
    refresh();
  }, [refresh]);

  const askCamera = async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setCam("unsupported");
      toast(tr("الكاميرا غير مدعومة (يتطلب HTTPS)", "Camera unsupported (needs HTTPS)"), "err");
      return;
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      s.getTracks().forEach((t) => t.stop());
      setCam("granted");
    } catch {
      setCam("denied");
      toast(tr("تم رفض إذن الكاميرا — فعّله من إعدادات المتصفح", "Camera denied — enable it in browser settings"), "err");
    }
  };
  const askStorage = async () => {
    try {
      const ok = (await navigator.storage?.persist?.()) ?? false;
      setStorage(ok);
      if (!ok) toast(tr("لم يمنح المتصفح التخزين الدائم (قد يمنحه عند التثبيت)", "Browser didn't grant persistent storage (may after install)"), "info");
      refresh();
    } catch {
      setStorage(false);
    }
  };
  const askPhotos = () => fileRef.current?.click();

  const rows = [
    {
      icon: Camera,
      title: tr("الكاميرا", "Camera"),
      desc: tr("لمسح رموز QR مباشرة", "To scan QR codes live"),
      ok: cam === "granted",
      label: cam === "granted" ? tr("مسموح", "Allowed") : cam === "denied" ? tr("مرفوض", "Denied") : cam === "unsupported" ? tr("غير مدعوم", "Unsupported") : tr("غير مفعّل", "Not allowed"),
      action: askCamera,
      btn: cam === "denied" ? tr("إعادة المحاولة", "Retry") : tr("السماح", "Allow"),
    },
    {
      icon: ImageIcon,
      title: tr("الصور", "Photos"),
      desc: tr("لقراءة QR من الصور وإضافة الشعارات", "Read QR from photos & add logos"),
      ok: photos,
      label: photos ? tr("مسموح", "Allowed") : tr("عند الطلب", "On demand"),
      action: askPhotos,
      btn: tr("اختيار صورة", "Pick a photo"),
    },
    {
      icon: HardDrive,
      title: tr("التخزين", "Storage"),
      desc: usage ? `${tr("المحفوظات والنسخ المحلية", "Library & local data")} · ${usage}` : tr("المحفوظات والنسخ المحلية", "Library & local data"),
      ok: storage === true,
      label: storage ? tr("دائم", "Persistent") : tr("مؤقت", "Best effort"),
      action: askStorage,
      btn: tr("السماح", "Allow"),
    },
  ];

  return (
    <div className="space-y-2">
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) {
            setFlag("photos");
            setPhotos(true);
            toast(tr("تم السماح بالوصول إلى الصور", "Photo access granted"));
          }
          e.target.value = "";
        }}
      />
      {rows.map((r) => (
        <div key={r.title} className="flex items-center gap-3 rounded-2xl border border-line bg-card2 p-2.5">
          <span className={cx("grid h-10 w-10 shrink-0 place-items-center rounded-xl", r.ok ? "bg-emerald-500/15 text-emerald-500" : "bg-primary/10 text-primary")}>
            <r.icon size={19} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-sm font-bold">
              {r.title}
              <span className={cx("rounded-full px-2 py-0.5 text-[10px] font-semibold", r.ok ? "bg-emerald-500/15 text-emerald-500" : "bg-line text-muted")}>{r.label}</span>
            </div>
            <div className="truncate text-[11px] text-muted">{r.desc}</div>
          </div>
          <Btn size="sm" variant={r.ok ? "soft" : "primary"} onClick={r.action}>
            {r.ok ? <CheckCircle2 size={14} /> : null}
            {r.btn}
          </Btn>
        </div>
      ))}
    </div>
  );
}

export function OnboardingModal() {
  const { tr } = useApp();
  const [open, setOpen] = useState(() => !flag("onboarded"));
  const close = () => {
    setFlag("onboarded");
    setOpen(false);
  };
  return (
    <Modal open={open} onClose={close} title={tr("مرحباً بك في QR Studio", "Welcome to QR Studio")}>
      <div className="mb-3 flex items-start gap-3 text-sm text-muted">
        <ShieldCheck className="mt-0.5 shrink-0 text-accent" size={20} />
        <p>{tr("كل شيء يعمل على جهازك فقط. لا حسابات ولا خوادم. امنح الأذونات التالية لتجربة كاملة:", "Everything runs on your device only. No accounts, no servers. Grant these permissions for the full experience:")}</p>
      </div>
      <PermissionsPanel />
      <Btn variant="primary" className="mt-4 w-full" onClick={close}>
        {tr("ابدأ", "Get started")}
      </Btn>
    </Modal>
  );
}
