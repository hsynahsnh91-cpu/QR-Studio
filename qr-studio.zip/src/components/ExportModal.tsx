import { useEffect, useState } from "react";
import { Copy, Download, Share2 } from "lucide-react";
import { useApp } from "../context";
import type { QRState } from "../hooks";
import type { QRStyle } from "../lib/types";
import { EXT, FORMATS, copyImage, downloadBlob, exportBlob, safeName, shareBlob, supportsAlpha, type ExportFormat } from "../lib/exporter";
import { QRImage } from "./QRParts";
import { Btn, Modal, Segmented, SectionTitle, Slider, Toggle, cx } from "./ui";

const SIZES = [256, 512, 1024, 2048, 4096];

export function ExportModal({ open, onClose, qr, style, heroId, name }: { open: boolean; onClose: () => void; qr: QRState; style: QRStyle; heroId: string; name: string }) {
  const { tr, toast } = useApp();
  const [format, setFormat] = useState<ExportFormat>("png");
  const [size, setSize] = useState(1024);
  const [margin, setMargin] = useState(style.margin);
  const [transparent, setTransparent] = useState(false);
  const [dpi, setDpi] = useState(300);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setMargin(style.margin);
      setTransparent(style.bgMode === "transparent");
    }
  }, [open, style.margin, style.bgMode]);

  const alpha = supportsAlpha(format);
  const opts = { format, size, margin, transparent: transparent && alpha, dpi };
  const fileName = `${safeName(name || "qr-code")}.${EXT[format]}`;
  const cm = ((size / dpi) * 2.54).toFixed(1);

  const run = async (kind: "download" | "copy" | "share") => {
    if (!qr.matrix) return;
    setBusy(true);
    try {
      if (kind === "copy") {
        await copyImage(qr.matrix, { ...style, margin }, size);
        toast(tr("تم نسخ الصورة", "Image copied"));
      } else {
        const blob = await exportBlob(qr.matrix, style, opts);
        if (kind === "download") {
          downloadBlob(blob, fileName);
          toast(tr("تم التصدير", "Exported"));
        } else if (!(await shareBlob(blob, fileName, "QR Studio"))) {
          downloadBlob(blob, fileName);
          toast(tr("المشاركة غير مدعومة — تم التنزيل", "Sharing unsupported — downloaded instead"), "info");
        }
      }
    } catch {
      toast(tr("فشلت العملية", "Operation failed"), "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={tr("تصدير", "Export")}>
      <div className="mb-3 flex items-center gap-3">
        <QRImage heroId={heroId} src={qr.src} transparent={style.bgMode === "transparent" || (transparent && alpha)} className="h-28 w-28 shrink-0" />
        <div className="min-w-0 text-xs text-muted">
          <div className="truncate font-mono text-fg" dir="ltr">
            {fileName}
          </div>
          <div dir="ltr">
            {format === "svg" ? "vector" : `${size} px`} · {cm} cm @ {dpi} dpi
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <Segmented<ExportFormat> id="fmt" value={format} onChange={setFormat} options={FORMATS.map((f) => ({ value: f, label: f.toUpperCase() }))} />
        <div className={cx(format === "svg" && "pointer-events-none opacity-40")}>
          <SectionTitle>{tr("الحجم (بكسل)", "Size (px)")}</SectionTitle>
          <div className="mb-2 flex flex-wrap gap-1.5">
            {SIZES.map((s) => (
              <button key={s} onClick={() => setSize(s)} className={cx("rounded-full border px-3 py-1 text-xs font-semibold transition", size === s ? "border-primary bg-primary/10 text-primary" : "border-line bg-card2 text-muted")}>
                {s}
              </button>
            ))}
          </div>
          <Slider label={tr("مخصص", "Custom")} value={size} min={128} max={4096} step={64} unit=" px" onChange={setSize} />
          <div className="mt-3 flex items-center justify-between gap-3 text-xs text-muted">
            <span>{tr("الدقة (للطباعة)", "Resolution (print)")}</span>
            <select className="inp !w-auto" value={dpi} onChange={(e) => setDpi(Number(e.target.value))}>
              {[72, 150, 300, 600].map((d) => (
                <option key={d} value={d}>
                  {d} dpi
                </option>
              ))}
            </select>
          </div>
        </div>
        <Slider label={tr("الهامش (وحدات)", "Margin (modules)")} value={margin} min={0} max={10} onChange={setMargin} />
        <div className={cx(!alpha && "opacity-50")}>
          <Toggle checked={transparent && alpha} onChange={setTransparent} label={alpha ? tr("خلفية شفافة", "Transparent background") : tr("الشفافية غير مدعومة في هذه الصيغة", "No transparency in this format")} />
        </div>
      </div>

      <div className="mt-4 grid grid-cols-[1fr_auto_auto] gap-2">
        <Btn variant="primary" onClick={() => run("download")} disabled={busy}>
          <Download size={16} />
          {busy ? tr("جارٍ التجهيز…", "Preparing…") : tr("تنزيل", "Download")}
        </Btn>
        <Btn onClick={() => run("copy")} disabled={busy} aria-label={tr("نسخ", "Copy")} title={tr("نسخ الصورة", "Copy image")}>
          <Copy size={16} />
        </Btn>
        <Btn onClick={() => run("share")} disabled={busy} aria-label={tr("مشاركة", "Share")} title={tr("مشاركة", "Share")}>
          <Share2 size={16} />
        </Btn>
      </div>
    </Modal>
  );
}
