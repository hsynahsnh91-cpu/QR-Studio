import { useEffect, useRef, useState } from "react";
import { DatabaseBackup, Download, Trash2, Upload } from "lucide-react";
import { useApp } from "../context";
import { Btn, ConfirmModal, Segmented } from "./ui";
import { clearAllData, createBackup, getFolders, getHistory, getImages, getProjects, restoreBackup } from "../lib/storage";
import { downloadBlob } from "../lib/exporter";

export function BackupTool({ onChanged }: { onChanged: () => void }) {
  const { tr, toast, lang, theme } = useApp();
  const [stats, setStats] = useState({ p: 0, f: 0, i: 0, h: 0 });
  const [mode, setMode] = useState<"merge" | "replace">("merge");
  const [wipe, setWipe] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = async () => {
    const [p, f, i, h] = await Promise.all([getProjects(), getFolders(), getImages(), getHistory()]);
    setStats({ p: p.length, f: f.length, i: i.length, h: h.length });
  };
  useEffect(() => {
    load().catch(() => undefined);
  }, []);

  const exportJson = async () => {
    const json = await createBackup({ lang, theme });
    downloadBlob(new Blob([json], { type: "application/json" }), `qr-studio-backup-${new Date().toISOString().slice(0, 10)}.json`);
    toast(tr("تم إنشاء النسخة الاحتياطية", "Backup created"));
  };

  const importJson = async (f?: File) => {
    if (!f) return;
    try {
      const r = await restoreBackup(await f.text(), mode);
      toast(tr(`تمت الاستعادة: ${r.projects} مشروع، ${r.folders} مجلد`, `Restored: ${r.projects} projects, ${r.folders} folders`));
      await load();
      onChanged();
    } catch {
      toast(tr("ملف النسخة الاحتياطية غير صالح", "Invalid backup file"), "err");
    }
  };

  const items = [
    [tr("المشاريع", "Projects"), stats.p],
    [tr("المجلدات", "Folders"), stats.f],
    [tr("الشعارات", "Logos"), stats.i],
    [tr("سجل المسح", "Scans"), stats.h],
  ] as const;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-2">
        {items.map(([l, n]) => (
          <div key={l} className="rounded-2xl border border-line bg-card2 p-2 text-center">
            <div className="text-xl font-extrabold text-primary">{n}</div>
            <div className="text-[11px] text-muted">{l}</div>
          </div>
        ))}
      </div>
      <Btn variant="primary" className="w-full" onClick={exportJson}>
        <Download size={16} />
        {tr("تصدير نسخة احتياطية (JSON)", "Export backup (JSON)")}
      </Btn>
      <div className="space-y-2 rounded-2xl border border-line bg-card2 p-3">
        <Segmented
          id="restore"
          value={mode}
          onChange={setMode}
          options={[
            { value: "merge", label: tr("دمج مع الحالي", "Merge") },
            { value: "replace", label: tr("استبدال الكل", "Replace all") },
          ]}
        />
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => { importJson(e.target.files?.[0]); e.target.value = ""; }} />
        <Btn className="w-full" onClick={() => fileRef.current?.click()}>
          <Upload size={16} />
          {tr("استعادة من ملف JSON", "Restore from JSON file")}
        </Btn>
      </div>
      <Btn variant="danger" className="w-full" onClick={() => setWipe(true)}>
        <Trash2 size={16} />
        {tr("حذف كل البيانات المحلية", "Delete all local data")}
      </Btn>
      <p className="flex items-center gap-1.5 text-[11px] text-muted">
        <DatabaseBackup size={13} />
        {tr("البيانات محفوظة على جهازك فقط (IndexedDB).", "Data is stored on your device only (IndexedDB).")}
      </p>
      <ConfirmModal
        open={wipe}
        danger
        title={tr("حذف كل البيانات؟", "Delete all data?")}
        message={tr("سيتم حذف المشاريع والمجلدات والشعارات والسجل نهائياً. أنشئ نسخة احتياطية أولاً.", "Projects, folders, logos and history will be permanently deleted. Create a backup first.")}
        confirmLabel={tr("حذف الكل", "Delete all")}
        onClose={() => setWipe(false)}
        onConfirm={async () => {
          await clearAllData();
          await load();
          onChanged();
          toast(tr("تم حذف البيانات", "Data deleted"));
        }}
      />
    </div>
  );
}
