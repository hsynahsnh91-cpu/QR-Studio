import { useEffect, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useApp } from "../context";

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(" ");

/* ------------------------------- buttons ------------------------------- */

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "soft" | "ghost" | "danger";
  size?: "sm" | "md";
};
export function Btn({ variant = "soft", size = "md", className, ...p }: BtnProps) {
  return (
    <button
      {...p}
      className={cx(
        "inline-flex items-center justify-center gap-1.5 rounded-xl font-semibold [&>svg]:shrink-0 transition active:scale-[0.97] disabled:opacity-50 disabled:active:scale-100",
        size === "sm" ? "px-3 py-1.5 text-xs" : "px-4 py-2.5 text-sm",
        variant === "primary" && "bg-primary text-primary-fg shadow-md shadow-primary/25 hover:brightness-110",
        variant === "soft" && "bg-card2 text-fg hover:bg-line/60 border border-line",
        variant === "ghost" && "text-muted hover:bg-card2 hover:text-fg",
        variant === "danger" && "bg-red-500/10 text-red-500 hover:bg-red-500/20 border border-red-500/30",
        className,
      )}
    />
  );
}

export function IconBtn({ className, label, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      {...p}
      aria-label={label}
      title={label}
      className={cx("grid h-9 w-9 shrink-0 place-items-center rounded-xl text-muted transition hover:bg-card2 hover:text-fg active:scale-95 disabled:opacity-40", className)}
    />
  );
}

/* ------------------------------- modal ------------------------------- */

export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  children: ReactNode;
  wide?: boolean;
  footer?: ReactNode;
}) {
  const { tr } = useApp();
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/45 backdrop-blur-[2px] sm:items-center sm:p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            role="dialog"
            aria-modal="true"
            className={cx(
              "flex max-h-[92dvh] w-full flex-col overflow-hidden rounded-t-3xl border border-line bg-card shadow-2xl sm:rounded-3xl",
              wide ? "sm:max-w-2xl" : "sm:max-w-md",
            )}
            initial={{ y: 60, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 60, opacity: 0 }}
            transition={{ type: "spring", damping: 28, stiffness: 320 }}
          >
            <div className="flex shrink-0 items-center justify-between gap-2 px-4 pb-1 pt-3">
              <h2 className="min-w-0 truncate text-base font-bold">{title}</h2>
              <IconBtn label={tr("إغلاق", "Close")} onClick={onClose}>
                <X size={18} />
              </IconBtn>
            </div>
            <div className="thin-scroll min-h-0 flex-1 overflow-y-auto px-4 pb-4 pt-2">{children}</div>
            {footer && <div className="shrink-0 border-t border-line px-4 py-3">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function ConfirmModal({
  open,
  title,
  message,
  danger,
  confirmLabel,
  onConfirm,
  onClose,
}: {
  open: boolean;
  title: string;
  message: string;
  danger?: boolean;
  confirmLabel?: string;
  onConfirm: () => void;
  onClose: () => void;
}) {
  const { tr } = useApp();
  return (
    <Modal open={open} onClose={onClose} title={title}>
      <p className="mb-4 text-sm text-muted">{message}</p>
      <div className="flex justify-end gap-2">
        <Btn onClick={onClose}>{tr("إلغاء", "Cancel")}</Btn>
        <Btn
          variant={danger ? "danger" : "primary"}
          onClick={() => {
            onConfirm();
            onClose();
          }}
        >
          {confirmLabel ?? tr("تأكيد", "Confirm")}
        </Btn>
      </div>
    </Modal>
  );
}

export function PromptModal({
  open,
  title,
  initial,
  onSubmit,
  onClose,
}: {
  open: boolean;
  title: string;
  initial: string;
  onSubmit: (v: string) => void;
  onClose: () => void;
}) {
  const { tr } = useApp();
  const [v, setV] = useState(initial);
  useEffect(() => {
    if (open) setV(initial);
  }, [open, initial]);
  const submit = () => {
    if (!v.trim()) return;
    onSubmit(v.trim());
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} title={title}>
      <input autoFocus className="inp mb-4" value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} />
      <div className="flex justify-end gap-2">
        <Btn onClick={onClose}>{tr("إلغاء", "Cancel")}</Btn>
        <Btn variant="primary" onClick={submit} disabled={!v.trim()}>
          {tr("حفظ", "Save")}
        </Btn>
      </div>
    </Modal>
  );
}

/* --------------------------- form primitives --------------------------- */

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  className,
  id,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: ReactNode }[];
  className?: string;
  id: string;
}) {
  return (
    <div className={cx("flex gap-1 rounded-xl border border-line bg-card2 p-1", className)}>
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cx("relative flex flex-1 items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-xs font-semibold transition-colors", value === o.value ? "text-primary-fg" : "text-muted hover:text-fg")}
        >
          {value === o.value && <motion.span layoutId={`seg-${id}`} className="absolute inset-0 rounded-lg bg-primary" transition={{ type: "spring", damping: 30, stiffness: 400 }} />}
          <span className="relative z-10 flex items-center gap-1">{o.label}</span>
        </button>
      ))}
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className="flex w-full items-center justify-between gap-3 py-1 text-sm">
      <span>{label}</span>
      <span className={cx("relative h-6 w-11 shrink-0 rounded-full transition-colors", checked ? "bg-primary" : "bg-line")}>
        <span className={cx("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all", checked ? "start-[1.4rem]" : "start-0.5")} />
      </span>
    </button>
  );
}

export function Slider({ label, value, min, max, step = 1, onChange, unit = "" }: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; unit?: string }) {
  return (
    <label className="block">
      <div className="mb-1 flex justify-between text-xs text-muted">
        <span>{label}</span>
        <span dir="ltr" className="font-mono">
          {value}
          {unit}
        </span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </label>
  );
}

export function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const [txt, setTxt] = useState(value);
  useEffect(() => setTxt(value), [value]);
  return (
    <div>
      <div className="mb-1 text-xs text-muted">{label}</div>
      <div className="flex items-center gap-2">
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)} aria-label={label} />
        <input
          dir="ltr"
          className="inp font-mono uppercase"
          value={txt}
          maxLength={7}
          onChange={(e) => {
            setTxt(e.target.value);
            if (/^#[0-9a-fA-F]{6}$/.test(e.target.value)) onChange(e.target.value.toLowerCase());
          }}
          onBlur={() => setTxt(value)}
        />
      </div>
    </div>
  );
}

export function SectionTitle({ children }: { children: ReactNode }) {
  return <div className="mb-2 mt-1 text-xs font-bold uppercase tracking-wide text-muted">{children}</div>;
}
