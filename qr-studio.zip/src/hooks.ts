import { useEffect, useMemo, useState } from "react";
import { getType, type BuildResult } from "./lib/qrTypes";
import { makeMatrix, renderSVG, svgDataUrl, type Matrix } from "./lib/qrRender";
import { testReadability, type Readability } from "./lib/scan";
import type { QRStyle, Values } from "./lib/types";

export interface QRState {
  build: BuildResult;
  matrix: Matrix | null;
  /** capacity / render error */
  tooLong: boolean;
  src: string;
  bytes: number;
}

export function useQR(typeId: string, values: Values, style: QRStyle): QRState {
  const build = useMemo(() => getType(typeId).build(values), [typeId, values]);
  const { matrix, tooLong } = useMemo(() => {
    if (!build.ok || !build.data) return { matrix: null, tooLong: false };
    try {
      return { matrix: makeMatrix(build.data, style.ecc), tooLong: false };
    } catch {
      return { matrix: null, tooLong: true };
    }
  }, [build, style.ecc]);
  const src = useMemo(() => (matrix ? svgDataUrl(renderSVG(matrix, style).svg) : ""), [matrix, style]);
  const bytes = useMemo(() => (build.data ? new TextEncoder().encode(build.data).length : 0), [build.data]);
  return { build, matrix, tooLong, src, bytes };
}

export function useReadability(matrix: Matrix | null, style: QRStyle, data: string, nonce = 0) {
  const [state, setState] = useState<Readability | "idle">("idle");
  useEffect(() => {
    if (!matrix) {
      setState("idle");
      return;
    }
    let alive = true;
    setState("idle");
    const t = setTimeout(() => {
      testReadability(matrix, style, data).then((r) => alive && setState(r));
    }, 350);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [matrix, style, data, nonce]);
  return state;
}

/** Dimmed sample QR shown while the real data is incomplete. */
export function useSample(style: QRStyle): string {
  return useMemo(() => svgDataUrl(renderSVG(makeMatrix("https://qr.studio", "M"), style).svg), [style]);
}
