import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Info, TriangleAlert } from "lucide-react";
import type { Bi, Lang, Theme } from "./lib/types";
import { loadSettings, saveSettings } from "./lib/storage";

type ToastKind = "ok" | "err" | "info";
interface Ctx {
  lang: Lang;
  dir: "rtl" | "ltr";
  setLang: (l: Lang) => void;
  theme: Theme;
  dark: boolean;
  setTheme: (t: Theme) => void;
  /** pick a string by current language */
  tr: (ar: string, en: string) => string;
  bi: (b: Bi) => string;
  toast: (msg: string, kind?: ToastKind) => void;
}

const AppCtx = createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => useContext(AppCtx);

export function AppProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState(loadSettings);
  const [sysDark, setSysDark] = useState(() => window.matchMedia("(prefers-color-scheme: dark)").matches);
  const [toasts, setToasts] = useState<{ id: number; msg: string; kind: ToastKind }[]>([]);

  const { lang, theme } = settings;
  const dark = theme === "dark" || (theme === "system" && sysDark);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const h = (e: MediaQueryListEvent) => setSysDark(e.matches);
    mq.addEventListener("change", h);
    return () => mq.removeEventListener("change", h);
  }, []);

  useEffect(() => {
    const el = document.documentElement;
    el.lang = lang;
    el.dir = lang === "ar" ? "rtl" : "ltr";
    el.classList.toggle("dark", dark);
    document.title = lang === "ar" ? "QR Studio — استوديو رموز QR" : "QR Studio";
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", dark ? "#0d0f1c" : "#f4f5fb");
    saveSettings(settings);
  }, [lang, dark, settings]);

  const toast = useCallback((msg: string, kind: ToastKind = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2600);
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      lang,
      dir: lang === "ar" ? "rtl" : "ltr",
      setLang: (l) => setSettings((s) => ({ ...s, lang: l })),
      theme,
      dark,
      setTheme: (t) => setSettings((s) => ({ ...s, theme: t })),
      tr: (ar, en) => (lang === "ar" ? ar : en),
      bi: (b) => (lang === "ar" ? b[0] : b[1]),
      toast,
    }),
    [lang, theme, dark, toast],
  );

  return (
    <AppCtx.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-14 z-[100] flex flex-col items-center gap-2 px-4">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -12, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8 }}
              className="pointer-events-auto flex max-w-sm items-center gap-2 rounded-2xl border border-line bg-card px-4 py-2.5 text-sm font-medium shadow-lg"
            >
              {t.kind === "ok" ? <Check size={16} className="text-accent" /> : t.kind === "err" ? <TriangleAlert size={16} className="text-red-500" /> : <Info size={16} className="text-primary" />}
              <span>{t.msg}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </AppCtx.Provider>
  );
}
