import { useCallback, useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Archive, CheckSquare, Copy, ExternalLink, FolderInput, FolderPlus, FolderX, History, MoreVertical, Pencil, QrCode, Search, Star, Trash2, FolderOpen, Camera, ImageUp, Download, Loader2 } from "lucide-react";
import { useApp } from "../context";
import { ConfirmModal, Btn, IconBtn, Modal, PromptModal, Segmented, Slider, cx } from "../components/ui";
import { LinkPreviewModal } from "../components/ScanResult";
import { dbDelete, dbClear, dbPut, getFolders, getHistory, getProjects } from "../lib/storage";
import { uid, type Folder, type Project, type ScanRecord } from "../lib/types";
import { getType } from "../lib/qrTypes";
import { EXT, FORMATS, copyText, downloadBlob, exportBlob, uniqueName, type ExportFormat } from "../lib/exporter";
import { buildMatrix, zipProjects } from "../lib/projects";
import { analyzeLink, detectContent, type Detected } from "../lib/scan";

type Tab = "projects" | "scans";

interface Props {
  onOpen: (p: Project) => void;
  onCreate: (d: Detected) => void;
  openedId: string | null;
}

export function LibraryView({ onOpen, onCreate, openedId }: Props) {
  const { tr, bi, lang, toast } = useApp();
  const [tab, setTab] = useState<Tab>("projects");
  const [projects, setProjects] = useState<Project[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [history, setHistory] = useState<ScanRecord[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("all"); // all | fav | none | <folderId>
  const [menu, setMenu] = useState<string | null>(null);
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [rename, setRename] = useState<Project | null>(null);
  const [moving, setMoving] = useState<Project | null>(null);
  const [del, setDel] = useState<Project | null>(null);
  const [newFolder, setNewFolder] = useState(false);
  const [renameFolder, setRenameFolder] = useState(false);
  const [delFolder, setDelFolder] = useState(false);
  const [zipOpen, setZipOpen] = useState(false);
  const [clearHist, setClearHist] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [p, f, h] = await Promise.all([getProjects(), getFolders(), getHistory()]);
    setProjects(p.sort((a, b) => b.updatedAt - a.updatedAt));
    setFolders(f.sort((a, b) => a.name.localeCompare(b.name)));
    setHistory(h.sort((a, b) => b.at - a.at));
    setLoaded(true);
  }, []);
  useEffect(() => {
    load().catch(() => setLoaded(true));
  }, [load]);

  const visible = useMemo(() => {
    const s = q.trim().toLowerCase();
    return projects.filter((p) => {
      if (filter === "fav" && !p.favorite) return false;
      if (filter === "none" && p.folderId) return false;
      if (filter !== "all" && filter !== "fav" && filter !== "none" && p.folderId !== filter) return false;
      if (!s) return true;
      return p.name.toLowerCase().includes(s) || bi(getType(p.typeId).label).toLowerCase().includes(s) || Object.values(p.values).some((v) => v.toLowerCase().includes(s));
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projects, q, filter, lang]);

  const update = async (p: Project) => {
    await dbPut("projects", p);
    setProjects((l) => l.map((x) => (x.id === p.id ? p : x)));
  };
  const duplicate = async (p: Project) => {
    const c: Project = { ...p, id: uid(), name: p.name + (lang === "ar" ? " (نسخة)" : " (copy)"), createdAt: Date.now(), updatedAt: Date.now() };
    await dbPut("projects", c);
    setProjects((l) => [c, ...l]);
    toast(tr("تم النسخ", "Duplicated"));
  };
  const remove = async (p: Project) => {
    await dbDelete("projects", p.id);
    setProjects((l) => l.filter((x) => x.id !== p.id));
    setSelected((s) => {
      const n = new Set(s);
      n.delete(p.id);
      return n;
    });
    toast(tr("تم الحذف", "Deleted"));
  };
  const quickExport = async (p: Project, fmt: ExportFormat) => {
    const m = buildMatrix(p.typeId, p.values, p.style);
    if (!m) return toast(tr("بيانات المشروع غير صالحة", "Project data invalid"), "err");
    const blob = await exportBlob(m, p.style, { format: fmt, size: 1024, margin: p.style.margin, transparent: p.style.bgMode === "transparent", dpi: 300 });
    downloadBlob(blob, uniqueName(p.name, EXT[fmt], new Set()));
  };

  const addFolder = async (name: string) => {
    const f: Folder = { id: uid(), name };
    await dbPut("folders", f);
    setFolders((l) => [...l, f].sort((a, b) => a.name.localeCompare(b.name)));
    setFilter(f.id);
  };
  const curFolder = folders.find((f) => f.id === filter);
  const renameCurFolder = async (name: string) => {
    if (!curFolder) return;
    const f = { ...curFolder, name };
    await dbPut("folders", f);
    setFolders((l) => l.map((x) => (x.id === f.id ? f : x)));
  };
  const deleteCurFolder = async () => {
    if (!curFolder) return;
    await dbDelete("folders", curFolder.id);
    const moved = projects.filter((p) => p.folderId === curFolder.id).map((p) => ({ ...p, folderId: null }));
    await Promise.all(moved.map((p) => dbPut("projects", p)));
    setProjects((l) => l.map((p) => (p.folderId === curFolder.id ? { ...p, folderId: null } : p)));
    setFolders((l) => l.filter((f) => f.id !== curFolder.id));
    setFilter("all");
  };

  const toggleSel = (id: string) =>
    setSelected((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const zipTargets = selected.size ? projects.filter((p) => selected.has(p.id)) : visible;
  const fmtDate = (t: number) => new Date(t).toLocaleString(lang === "ar" ? "ar" : "en", { dateStyle: "medium", timeStyle: "short" });

  return (
    <div className="mx-auto flex h-full max-w-6xl flex-col gap-3 p-3" onClick={() => menu && setMenu(null)}>
      <Segmented<Tab>
        id="libtab"
        value={tab}
        onChange={setTab}
        options={[
          { value: "projects", label: <><FolderOpen size={14} />{tr("المشاريع", "Projects")} ({projects.length})</> },
          { value: "scans", label: <><History size={14} />{tr("سجل المسح", "Scan history")} ({history.length})</> },
        ]}
      />

      {tab === "projects" ? (
        <>
          <div className="flex shrink-0 flex-wrap items-center gap-2">
            <div className="relative min-w-[8rem] flex-1">
              <Search size={15} className="pointer-events-none absolute start-3 top-1/2 -translate-y-1/2 text-muted" />
              <input className="inp !ps-9" placeholder={tr("بحث بالاسم أو النوع أو المحتوى", "Search name, type or content")} value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <select className="inp !w-auto max-w-[9rem]" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label={tr("تصفية", "Filter")}>
              <option value="all">{tr("الكل", "All")}</option>
              <option value="fav">★ {tr("المفضلة", "Favorites")}</option>
              <option value="none">{tr("بدون مجلد", "No folder")}</option>
              {folders.map((f) => (
                <option key={f.id} value={f.id}>
                  📁 {f.name}
                </option>
              ))}
            </select>
            <IconBtn label={tr("مجلد جديد", "New folder")} onClick={() => setNewFolder(true)} className="border border-line bg-card2">
              <FolderPlus size={17} />
            </IconBtn>
            {curFolder && (
              <>
                <IconBtn label={tr("إعادة تسمية المجلد", "Rename folder")} onClick={() => setRenameFolder(true)} className="border border-line bg-card2">
                  <Pencil size={16} />
                </IconBtn>
                <IconBtn label={tr("حذف المجلد", "Delete folder")} onClick={() => setDelFolder(true)} className="border border-line bg-card2 !text-red-500">
                  <FolderX size={16} />
                </IconBtn>
              </>
            )}
            <IconBtn
              label={tr("تحديد", "Select")}
              onClick={() => {
                setSelectMode((m) => !m);
                setSelected(new Set());
              }}
              className={cx("border border-line", selectMode ? "!bg-primary !text-primary-fg" : "bg-card2")}
            >
              <CheckSquare size={17} />
            </IconBtn>
            <Btn size="sm" onClick={() => setZipOpen(true)} disabled={!zipTargets.length}>
              <Archive size={15} />
              ZIP ({zipTargets.length})
            </Btn>
          </div>

          <div className="thin-scroll min-h-0 flex-1 overflow-y-auto rounded-3xl border border-line bg-card p-3">
            {!loaded ? (
              <div className="grid h-full place-items-center text-muted">
                <Loader2 className="animate-spin" />
              </div>
            ) : visible.length === 0 ? (
              <div className="grid h-full place-items-center text-center text-sm text-muted">
                <div>
                  <QrCode size={42} className="mx-auto mb-2 opacity-40" />
                  {projects.length === 0 ? tr("لا توجد مشاريع محفوظة بعد. أنشئ رمزاً واضغط «حفظ».", "No saved projects yet. Create a code and tap Save.") : tr("لا نتائج مطابقة", "No matching results")}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
                {visible.map((p) => {
                  const Icon = getType(p.typeId).icon;
                  const sel = selected.has(p.id);
                  return (
                    <div key={p.id} className={cx("relative rounded-2xl border bg-card2 p-2 transition", sel ? "border-primary ring-2 ring-primary/30" : "border-line")}>
                      <button
                        className="block w-full text-start"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (selectMode) toggleSel(p.id);
                          else onOpen(p);
                        }}
                      >
                        <motion.div layoutId={`hero-${p.id}`} className="aspect-square overflow-hidden rounded-xl bg-white ring-1 ring-line">
                          <img src={p.thumb} alt={p.name} className="h-full w-full object-contain" draggable={false} />
                        </motion.div>
                        <div dir="auto" className="mt-2 truncate text-sm font-bold">{p.name}</div>
                        <div className="flex items-center gap-1 text-[11px] text-muted">
                          <Icon size={11} />
                          <span className="truncate">{bi(getType(p.typeId).label)}</span>
                        </div>
                      </button>
                      <div className="absolute end-2.5 top-2.5 flex flex-col gap-1">
                        {selectMode ? (
                          <span className={cx("grid h-6 w-6 place-items-center rounded-md border-2 text-xs", sel ? "border-primary bg-primary text-primary-fg" : "border-line bg-card")}>{sel ? "✓" : ""}</span>
                        ) : (
                          <>
                            <button
                              aria-label={tr("مفضلة", "Favorite")}
                              onClick={(e) => {
                                e.stopPropagation();
                                update({ ...p, favorite: !p.favorite });
                              }}
                              className="grid h-7 w-7 place-items-center rounded-lg bg-card/90 shadow"
                            >
                              <Star size={15} className={cx(p.favorite ? "fill-amber-400 text-amber-400" : "text-muted")} />
                            </button>
                            <button
                              aria-label={tr("المزيد", "More")}
                              onClick={(e) => {
                                e.stopPropagation();
                                setMenu(menu === p.id ? null : p.id);
                              }}
                              className="grid h-7 w-7 place-items-center rounded-lg bg-card/90 text-muted shadow"
                            >
                              <MoreVertical size={15} />
                            </button>
                          </>
                        )}
                      </div>
                      {menu === p.id && (
                        <div onClick={(e) => e.stopPropagation()} className="absolute end-2 top-20 z-20 w-44 overflow-hidden rounded-2xl border border-line bg-card p-1 text-sm shadow-xl">
                          {[
                            { i: Pencil, l: tr("فتح وتعديل", "Open & edit"), f: () => onOpen(p) },
                            { i: Pencil, l: tr("إعادة تسمية", "Rename"), f: () => setRename(p) },
                            { i: Copy, l: tr("نسخ المشروع", "Duplicate"), f: () => duplicate(p) },
                            { i: FolderInput, l: tr("نقل إلى مجلد", "Move to folder"), f: () => setMoving(p) },
                            { i: Download, l: "PNG", f: () => quickExport(p, "png") },
                            { i: Download, l: "SVG", f: () => quickExport(p, "svg") },
                            { i: Trash2, l: tr("حذف", "Delete"), f: () => setDel(p), danger: true },
                          ].map((m, i) => (
                            <button
                              key={i}
                              onClick={() => {
                                setMenu(null);
                                m.f();
                              }}
                              className={cx("flex w-full items-center gap-2 rounded-xl px-2.5 py-2 text-start hover:bg-card2", m.danger && "text-red-500")}
                            >
                              <m.i size={15} />
                              {m.l}
                            </button>
                          ))}
                          <div className="px-2.5 py-1 text-[10px] text-muted">{fmtDate(p.updatedAt)}</div>
                        </div>
                      )}
                      {openedId === p.id && <span className="absolute start-3 top-3 rounded-full bg-primary px-1.5 py-0.5 text-[9px] font-bold text-primary-fg">●</span>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </>
      ) : (
        <>
          <div className="flex shrink-0 justify-end">
            <Btn size="sm" variant="danger" disabled={!history.length} onClick={() => setClearHist(true)}>
              <Trash2 size={14} />
              {tr("مسح السجل", "Clear history")}
            </Btn>
          </div>
          <div className="thin-scroll min-h-0 flex-1 space-y-2 overflow-y-auto rounded-3xl border border-line bg-card p-3">
            {history.length === 0 && (
              <div className="grid h-full place-items-center text-center text-sm text-muted">
                <div>
                  <History size={42} className="mx-auto mb-2 opacity-40" />
                  {tr("لا توجد عمليات مسح بعد", "No scans yet")}
                </div>
              </div>
            )}
            {history.map((h) => {
              const link = analyzeLink(h.text);
              return (
                <div key={h.id} className="flex items-center gap-2 rounded-2xl border border-line bg-card2 p-2.5">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">{h.source === "camera" ? <Camera size={16} /> : <ImageUp size={16} />}</span>
                  <div className="min-w-0 flex-1">
                    <div className="line-clamp-2 break-all text-sm font-medium" dir="auto">
                      {h.text}
                    </div>
                    <div className="text-[11px] text-muted">
                      {bi(detectContent(h.text).label)} · {fmtDate(h.at)}
                    </div>
                  </div>
                  <IconBtn label={tr("نسخ", "Copy")} onClick={() => copyText(h.text).then(() => toast(tr("تم النسخ", "Copied")))}>
                    <Copy size={16} />
                  </IconBtn>
                  {link.isUrl && (
                    <IconBtn label={tr("معاينة وفتح", "Preview & open")} onClick={() => setPreview(h.text)}>
                      <ExternalLink size={16} />
                    </IconBtn>
                  )}
                  <IconBtn label={tr("إنشاء رمز", "Make QR")} onClick={() => onCreate(detectContent(h.text))}>
                    <QrCode size={16} />
                  </IconBtn>
                  <IconBtn
                    label={tr("حذف", "Delete")}
                    className="hover:!text-red-500"
                    onClick={async () => {
                      await dbDelete("history", h.id);
                      setHistory((l) => l.filter((x) => x.id !== h.id));
                    }}
                  >
                    <Trash2 size={16} />
                  </IconBtn>
                </div>
              );
            })}
          </div>
        </>
      )}

      <PromptModal open={newFolder} title={tr("مجلد جديد", "New folder")} initial="" onClose={() => setNewFolder(false)} onSubmit={addFolder} />
      <PromptModal open={renameFolder} title={tr("إعادة تسمية المجلد", "Rename folder")} initial={curFolder?.name ?? ""} onClose={() => setRenameFolder(false)} onSubmit={renameCurFolder} />
      <PromptModal open={!!rename} title={tr("إعادة تسمية", "Rename")} initial={rename?.name ?? ""} onClose={() => setRename(null)} onSubmit={(n) => rename && update({ ...rename, name: n, updatedAt: Date.now() })} />
      <ConfirmModal open={!!del} danger title={tr("حذف المشروع", "Delete project")} message={tr(`سيتم حذف «${del?.name}» نهائياً.`, `"${del?.name}" will be deleted permanently.`)} confirmLabel={tr("حذف", "Delete")} onClose={() => setDel(null)} onConfirm={() => del && remove(del)} />
      <ConfirmModal open={delFolder} danger title={tr("حذف المجلد", "Delete folder")} message={tr("سيُحذف المجلد وتبقى مشاريعه بدون مجلد.", "The folder is deleted; its projects stay (no folder).")} confirmLabel={tr("حذف", "Delete")} onClose={() => setDelFolder(false)} onConfirm={deleteCurFolder} />
      <ConfirmModal
        open={clearHist}
        danger
        title={tr("مسح سجل المسح", "Clear scan history")}
        message={tr("سيتم حذف كل السجل.", "All history will be removed.")}
        onClose={() => setClearHist(false)}
        onConfirm={async () => {
          await dbClear("history");
          setHistory([]);
        }}
      />
      <Modal open={!!moving} onClose={() => setMoving(null)} title={tr("نقل إلى مجلد", "Move to folder")}>
        <div className="space-y-1.5">
          {[{ id: "", name: tr("بدون مجلد", "No folder") }, ...folders].map((f) => (
            <button
              key={f.id}
              onClick={async () => {
                if (moving) await update({ ...moving, folderId: f.id || null, updatedAt: Date.now() });
                setMoving(null);
              }}
              className={cx("w-full rounded-xl border px-3 py-2.5 text-start text-sm font-medium transition", (moving?.folderId ?? "") === f.id ? "border-primary bg-primary/10" : "border-line bg-card2 hover:border-primary/50")}
            >
              {f.id ? "📁 " : ""}
              {f.name}
            </button>
          ))}
        </div>
      </Modal>
      <ZipModal open={zipOpen} onClose={() => setZipOpen(false)} projects={zipTargets} />
      <LinkPreviewModal text={preview} onClose={() => setPreview(null)} />
    </div>
  );
}

function ZipModal({ open, onClose, projects }: { open: boolean; onClose: () => void; projects: Project[] }) {
  const { tr, toast } = useApp();
  const [format, setFormat] = useState<ExportFormat>("png");
  const [size, setSize] = useState(1024);
  const [prog, setProg] = useState<[number, number] | null>(null);

  const run = async () => {
    setProg([0, projects.length]);
    try {
      const { blob, failed } = await zipProjects(projects, format, size, (d, t) => setProg([d, t]));
      downloadBlob(blob, `qr-studio-${new Date().toISOString().slice(0, 10)}.zip`);
      toast(failed ? tr(`تم التصدير (${failed} فشلت)`, `Exported (${failed} failed)`) : tr("تم تصدير ZIP", "ZIP exported"), failed ? "info" : "ok");
      onClose();
    } catch {
      toast(tr("فشل إنشاء ZIP", "ZIP failed"), "err");
    } finally {
      setProg(null);
    }
  };

  return (
    <Modal open={open} onClose={() => !prog && onClose()} title={tr(`تصدير ${projects.length} رمز كـ ZIP`, `Export ${projects.length} codes as ZIP`)}>
      <div className="space-y-3">
        <Segmented<ExportFormat> id="zipfmt" value={format} onChange={setFormat} options={FORMATS.map((f) => ({ value: f, label: f.toUpperCase() }))} />
        {format !== "svg" && <Slider label={tr("الحجم", "Size")} value={size} min={256} max={4096} step={128} unit=" px" onChange={setSize} />}
        {prog && (
          <div>
            <div className="h-2 overflow-hidden rounded-full bg-line">
              <div className="h-full bg-primary transition-all" style={{ width: `${(prog[0] / Math.max(1, prog[1])) * 100}%` }} />
            </div>
            <div className="mt-1 text-center text-xs text-muted" dir="ltr">
              {prog[0]} / {prog[1]}
            </div>
          </div>
        )}
        <Btn variant="primary" className="w-full" onClick={run} disabled={!!prog || !projects.length}>
          <Archive size={16} />
          {prog ? tr("جارٍ التصدير…", "Exporting…") : tr("تنزيل ZIP", "Download ZIP")}
        </Btn>
      </div>
    </Modal>
  );
}
