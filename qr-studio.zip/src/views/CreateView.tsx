import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown, Copy, Download, Eraser, Palette, Save, QrCode } from "lucide-react";
import { useApp } from "../context";
import type { DraftApi } from "../useDraft";
import { getType } from "../lib/qrTypes";
import { useReadability, useSample, type QRState } from "../hooks";
import { styleWarnings } from "../lib/qrRender";
import { copyImage } from "../lib/exporter";
import { FormFields } from "../components/FormFields";
import { QRImage, ReadBadge, Warnings } from "../components/QRParts";
import { TypePicker } from "../components/TypePicker";
import { Btn, IconBtn } from "../components/ui";

interface Props {
  api: DraftApi;
  qr: QRState;
  heroId: string;
  heroHidden: boolean;
  onCustomize: () => void;
  onExport: () => void;
  onSave: () => void;
}

export function CreateView({ api, qr, heroId, heroHidden, onCustomize, onExport, onSave }: Props) {
  const { tr, bi, toast } = useApp();
  const { typeId, values, style } = api;
  const def = getType(typeId);
  const Icon = def.icon;
  const [pickerOpen, setPickerOpen] = useState(false);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [nonce, setNonce] = useState(0);

  const read = useReadability(qr.matrix, style, qr.build.data, nonce);
  const warnings = useMemo(() => styleWarnings(style), [style]);

  const sample = useSample(style);

  useEffect(() => setTouched({}), [typeId]);

  const touchAll = () => setTouched(Object.fromEntries(def.fields.map((f) => [f.key, true])));
  const guard = (fn: () => void) => () => {
    if (!qr.matrix) {
      touchAll();
      toast(qr.tooLong ? tr("البيانات أطول من سعة الرمز", "Data exceeds QR capacity") : tr("أكمل الحقول المطلوبة أولاً", "Fill the required fields first"), "err");
      return;
    }
    fn();
  };

  const copy = guard(async () => {
    try {
      await copyImage(qr.matrix!, style);
      toast(tr("تم نسخ الصورة", "Image copied"));
    } catch {
      toast(tr("المتصفح لا يدعم نسخ الصور", "Browser can't copy images"), "err");
    }
  });

  const firstError = Object.values(qr.build.errors)[0];
  const message = qr.tooLong
    ? tr("البيانات أطول من سعة الرمز", "Data too long for a QR code")
    : firstError && Object.values(touched).some(Boolean)
      ? bi(firstError)
      : tr("أدخل البيانات لتظهر المعاينة", "Enter data to see the preview");

  const clear = () => {
    def.fields.forEach((f) => api.setField(f.key, def.defaults?.[f.key] ?? ""));
    setTouched({});
  };

  return (
    <div className="flex h-full flex-col gap-3 p-3 md:flex-row">
      {/* ------------ preview ------------ */}
      <section className="order-1 shrink-0 rounded-3xl border border-line bg-card p-3 md:order-2 md:w-[340px] lg:w-[380px]">
        <div className="flex h-[clamp(120px,22dvh,190px)] items-center gap-3 md:h-full md:flex-col md:items-stretch">
          <div className="relative aspect-square h-full shrink-0 md:aspect-auto md:min-h-0 md:w-full md:flex-1" style={{ containerType: "size" }}>
            <div className="absolute inset-0 grid place-items-center">
              <div style={{ width: "100cqmin", height: "100cqmin" }} className="relative">
                {!heroHidden && (
                  <QRImage heroId={heroId} src={qr.matrix ? qr.src : sample} dim={!qr.matrix} transparent={style.bgMode === "transparent"} className="h-full w-full" />
                )}
                {!qr.matrix && !heroHidden && (
                  <div className="absolute inset-0 grid place-items-center p-3 text-center">
                    <span className="rounded-xl bg-card/90 px-2.5 py-1.5 text-[11px] font-semibold leading-snug shadow">{message}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex min-w-0 flex-1 flex-col justify-center gap-2 md:flex-none">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              {qr.matrix ? <ReadBadge state={read} onRetest={() => setNonce((n) => n + 1)} /> : <span className="text-xs text-muted">{tr("بانتظار البيانات", "Waiting for data")}</span>}
              {qr.matrix && (
                <span dir="ltr" className="text-[11px] text-muted">
                  v{qr.matrix.version} · {qr.bytes} B
                </span>
              )}
            </div>
            <div className="hidden md:block">
              <Warnings list={warnings} max={2} />
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <Btn size="sm" onClick={onCustomize} className="!px-2 !py-2">
                <Palette size={15} />
                {tr("تخصيص", "Style")}
              </Btn>
              <Btn size="sm" variant="primary" onClick={guard(onExport)} className="!px-2 !py-2">
                <Download size={15} />
                {tr("تصدير", "Export")}
              </Btn>
              <Btn size="sm" onClick={guard(onSave)} className="!px-2 !py-2">
                <Save size={15} />
                {tr("حفظ", "Save")}
              </Btn>
              <Btn size="sm" onClick={copy} className="!px-2 !py-2">
                <Copy size={15} />
                {tr("نسخ", "Copy")}
              </Btn>
            </div>
          </div>
        </div>
      </section>

      {/* ------------ form ------------ */}
      <section className="order-2 flex min-h-0 min-w-0 flex-1 flex-col rounded-3xl border border-line bg-card md:order-1">
        <div className="flex shrink-0 items-center justify-between gap-2 border-b border-line px-3 py-2.5">
          <button onClick={() => setPickerOpen(true)} className="flex min-w-0 items-center gap-2.5 rounded-2xl bg-card2 py-1.5 pe-3 ps-1.5 transition hover:bg-line/60 active:scale-[0.98]">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-primary text-primary-fg">
              {!pickerOpen ? (
                <motion.span layoutId={`type-${typeId}`} className="grid h-8 w-8 place-items-center rounded-xl bg-primary">
                  <Icon size={17} />
                </motion.span>
              ) : (
                <Icon size={17} />
              )}
            </span>
            <span className="truncate text-sm font-bold">{bi(def.label)}</span>
            <ChevronDown size={16} className="shrink-0 text-muted" />
          </button>
          <div className="flex items-center gap-1">
            {api.draft.editingId && (
              <span className="hidden items-center gap-1 rounded-full bg-primary/10 px-2.5 py-1 text-[11px] font-semibold text-primary sm:inline-flex">
                <QrCode size={12} />
                {api.draft.name || tr("تعديل مشروع", "Editing")}
              </span>
            )}
            <IconBtn label={tr("مسح الحقول", "Clear fields")} onClick={clear}>
              <Eraser size={17} />
            </IconBtn>
          </div>
        </div>
        <div className="thin-scroll min-h-0 flex-1 overflow-y-auto p-3">
          <FormFields
            def={def}
            values={values}
            errors={qr.build.errors}
            touched={touched}
            onChange={api.setField}
            onTouch={(k) => setTouched((t) => ({ ...t, [k]: true }))}
          />
        </div>
      </section>

      <TypePicker open={pickerOpen} onClose={() => setPickerOpen(false)} current={typeId} onPick={api.setType} />
    </div>
  );
}
