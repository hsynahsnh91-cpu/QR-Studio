import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, DatabaseBackup, Layers, ShieldCheck, type LucideIcon } from "lucide-react";
import { useApp } from "../context";
import { BatchTool } from "../components/BatchTool";
import { BackupTool } from "../components/BackupTool";
import { PermissionsPanel } from "../components/Permissions";
import { IconBtn } from "../components/ui";
import type { QRStyle } from "../lib/types";

type Tool = "batch" | "backup" | "perms";

export function ToolsView({ style, onDataChanged }: { style: QRStyle; onDataChanged: () => void }) {
  const { tr, dir } = useApp();
  const [tool, setTool] = useState<Tool | null>(null);

  const tools: { id: Tool; icon: LucideIcon; title: string; desc: string }[] = [
    { id: "batch", icon: Layers, title: tr("إنشاء جماعي", "Batch generator"), desc: tr("CSV أو قائمة ← مئات الرموز في ZIP", "CSV or list → hundreds of codes in a ZIP") },
    { id: "backup", icon: DatabaseBackup, title: tr("نسخ احتياطي واستعادة", "Backup & restore"), desc: tr("تصدير واستيراد كل مشاريعك بصيغة JSON", "Export & import all your projects as JSON") },
    { id: "perms", icon: ShieldCheck, title: tr("الأذونات", "Permissions"), desc: tr("الكاميرا والصور والتخزين", "Camera, photos and storage") },
  ];
  const current = tools.find((t) => t.id === tool);
  const Back = dir === "rtl" ? ArrowRight : ArrowLeft;

  return (
    <div className="mx-auto flex h-full max-w-4xl flex-col p-3">
      <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-3xl border border-line bg-card">
        <AnimatePresence mode="popLayout" initial={false}>
          {!current ? (
            <motion.div key="grid" initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} className="thin-scroll min-h-0 flex-1 overflow-y-auto p-3">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {tools.map((t) => (
                  <button key={t.id} onClick={() => setTool(t.id)} className="flex items-center gap-3 rounded-2xl border border-line bg-card2 p-3.5 text-start transition hover:border-primary/60 active:scale-[0.98] sm:flex-col sm:items-start">
                    <motion.span layoutId={`tool-${t.id}`} className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-primary text-primary-fg shadow-md shadow-primary/30">
                      <t.icon size={22} />
                    </motion.span>
                    <span>
                      <span className="block text-sm font-bold">{t.title}</span>
                      <span className="block text-xs text-muted">{t.desc}</span>
                    </span>
                  </button>
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div key={current.id} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 16 }} className="flex min-h-0 flex-1 flex-col">
              <div className="flex shrink-0 items-center gap-2 border-b border-line px-3 py-2.5">
                <IconBtn label={tr("رجوع", "Back")} onClick={() => setTool(null)}>
                  <Back size={18} />
                </IconBtn>
                <motion.span layoutId={`tool-${current.id}`} className="grid h-8 w-8 place-items-center rounded-xl bg-primary text-primary-fg">
                  <current.icon size={17} />
                </motion.span>
                <h2 className="text-sm font-bold">{current.title}</h2>
              </div>
              <div className="thin-scroll min-h-0 flex-1 overflow-y-auto p-3">
                {current.id === "batch" && <BatchTool style={style} />}
                {current.id === "backup" && <BackupTool onChanged={onDataChanged} />}
                {current.id === "perms" && <PermissionsPanel />}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
