import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Camera, CameraOff, FlipHorizontal2, ImageUp, Loader2, ScanLine } from "lucide-react";
import { useApp } from "../context";
import { ScanResultCard } from "../components/ScanResult";
import { Btn, Segmented, cx } from "../components/ui";
import { decodeCanvas, decodeImageFile, type Detected } from "../lib/scan";
import { dbPut } from "../lib/storage";
import { uid } from "../lib/types";

type Mode = "camera" | "image";
type Cam = "idle" | "starting" | "live" | "denied" | "error";

interface BarcodeDetectorLike {
  detect(src: CanvasImageSource): Promise<{ rawValue: string }[]>;
}

export function ScanView({ onCreate }: { onCreate: (d: Detected) => void }) {
  const { tr, toast } = useApp();
  const [mode, setMode] = useState<Mode>("camera");
  const [cam, setCam] = useState<Cam>("idle");
  const [facing, setFacing] = useState<"environment" | "user">("environment");
  const [result, setResult] = useState<{ text: string; snapshot?: string } | null>(null);
  const [imgState, setImgState] = useState<"idle" | "busy" | "none">("idle");
  const [drag, setDrag] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const tokenRef = useRef(0);

  const stop = useCallback(() => {
    tokenRef.current++;
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  const finish = useCallback(
    (text: string, source: "camera" | "image", snapshot?: string) => {
      stop();
      setCam("idle");
      setResult({ text, snapshot });
      navigator.vibrate?.(50);
      dbPut("history", { id: uid(), text, at: Date.now(), source }).catch(() => undefined);
    },
    [stop],
  );

  const start = useCallback(
    async (face: "environment" | "user") => {
      stop();
      if (!navigator.mediaDevices?.getUserMedia) {
        setCam("error");
        return;
      }
      setCam("starting");
      const token = tokenRef.current;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: { ideal: face }, width: { ideal: 1280 }, height: { ideal: 720 } } });
        if (token !== tokenRef.current) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const v = videoRef.current;
        if (!v) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        v.srcObject = stream;
        await v.play();
        if (token !== tokenRef.current) return;
        setCam("live");

        const BD = (window as unknown as { BarcodeDetector?: new (o: { formats: string[] }) => BarcodeDetectorLike }).BarcodeDetector;
        const detector = BD ? new BD({ formats: ["qr_code"] }) : null;
        const cv = (canvasRef.current ??= document.createElement("canvas"));
        let last = 0;
        const loop = async (ts: number) => {
          if (!streamRef.current) return;
          if (ts - last > 120 && v.readyState >= 2 && v.videoWidth) {
            last = ts;
            const scale = Math.min(1, 720 / v.videoWidth);
            cv.width = Math.round(v.videoWidth * scale);
            cv.height = Math.round(v.videoHeight * scale);
            const ctx = cv.getContext("2d", { willReadFrequently: true })!;
            ctx.drawImage(v, 0, 0, cv.width, cv.height);
            let text: string | null = null;
            try {
              if (detector) {
                const r = await detector.detect(cv);
                text = r[0]?.rawValue ?? null;
              }
            } catch {
              /* fall back to jsQR */
            }
            if (text === null) text = decodeCanvas(cv, false);
            if (text) {
              const snap = document.createElement("canvas");
              snap.width = 160;
              snap.height = 160;
              const side = Math.min(cv.width, cv.height);
              snap.getContext("2d")!.drawImage(cv, (cv.width - side) / 2, (cv.height - side) / 2, side, side, 0, 0, 160, 160);
              finish(text, "camera", snap.toDataURL("image/jpeg", 0.7));
              return;
            }
          }
          rafRef.current = requestAnimationFrame(loop);
        };
        rafRef.current = requestAnimationFrame(loop);
      } catch (e) {
        if (token !== tokenRef.current) return;
        const n = (e as DOMException).name;
        setCam(n === "NotAllowedError" || n === "SecurityError" ? "denied" : "error");
      }
    },
    [stop, finish],
  );

  // auto start / stop with mode and result
  useEffect(() => {
    if (mode === "camera" && !result) start(facing);
    else {
      stop();
      setCam("idle");
    }
    return stop;
  }, [mode, result, facing, start, stop]);

  // release camera when tab hidden
  useEffect(() => {
    const h = () => {
      if (document.hidden) {
        stop();
        setCam("idle");
      }
    };
    document.addEventListener("visibilitychange", h);
    return () => document.removeEventListener("visibilitychange", h);
  }, [stop]);

  const handleFile = async (file?: File | null) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) return toast(tr("اختر ملف صورة", "Choose an image file"), "err");
    setImgState("busy");
    try {
      const text = await decodeImageFile(file);
      if (text === null) {
        setImgState("none");
        return;
      }
      setImgState("idle");
      const url = URL.createObjectURL(file);
      finish(text, "image", url);
    } catch {
      setImgState("none");
      toast(tr("تعذّر قراءة الصورة", "Couldn't read the image"), "err");
    }
  };

  const again = () => {
    setResult(null);
    setImgState("idle");
  };

  return (
    <div className="mx-auto flex h-full max-w-3xl flex-col gap-3 p-3">
      <Segmented<Mode>
        id="scanmode"
        value={mode}
        onChange={(m) => {
          setMode(m);
          setResult(null);
          setImgState("idle");
        }}
        options={[
          { value: "camera", label: <><Camera size={14} />{tr("الكاميرا", "Camera")}</> },
          { value: "image", label: <><ImageUp size={14} />{tr("من صورة", "From image")}</> },
        ]}
      />

      <div className="relative min-h-0 flex-1 rounded-3xl border border-line bg-card p-3">
        {result ? (
          <ScanResultCard text={result.text} snapshot={result.snapshot} onAgain={again} onCreate={onCreate} />
        ) : mode === "camera" ? (
          <motion.div layoutId="scan-hero" className="relative h-full w-full overflow-hidden rounded-2xl bg-black">
            <video ref={videoRef} playsInline muted className={cx("h-full w-full object-cover", facing === "user" && "-scale-x-100", cam !== "live" && "opacity-0")} />
            {cam === "live" && (
              <>
                <div className="pointer-events-none absolute inset-0 grid place-items-center">
                  <div className="relative aspect-square w-[62%] max-w-[320px] rounded-3xl border-2 border-white/80 shadow-[0_0_0_999px_rgba(0,0,0,0.38)]">
                    <span className="scanline absolute inset-x-3 h-0.5 rounded bg-primary shadow-[0_0_12px_var(--primary)]" />
                  </div>
                </div>
                <button
                  onClick={() => setFacing((f) => (f === "environment" ? "user" : "environment"))}
                  aria-label={tr("تبديل الكاميرا", "Switch camera")}
                  className="absolute bottom-3 end-3 grid h-11 w-11 place-items-center rounded-full bg-black/55 text-white backdrop-blur active:scale-95"
                >
                  <FlipHorizontal2 size={20} />
                </button>
                <div className="pointer-events-none absolute inset-x-0 bottom-4 text-center text-xs font-medium text-white/90">{tr("وجّه الكاميرا نحو رمز QR", "Point the camera at a QR code")}</div>
              </>
            )}
            {cam !== "live" && (
              <div className="absolute inset-0 grid place-items-center p-6 text-center text-white">
                {cam === "starting" || cam === "idle" ? (
                  <Loader2 className="animate-spin" size={32} />
                ) : (
                  <div className="space-y-3">
                    <CameraOff className="mx-auto" size={36} />
                    <p className="text-sm">
                      {cam === "denied"
                        ? tr("تم رفض إذن الكاميرا. اسمح بالوصول من إعدادات المتصفح أو الجهاز ثم أعد المحاولة.", "Camera permission denied. Allow access in your browser/device settings, then retry.")
                        : tr("تعذّر تشغيل الكاميرا (تحقق من وجودها واستخدام HTTPS).", "Couldn't start the camera (check it exists and HTTPS is used).")}
                    </p>
                    <div className="flex justify-center gap-2">
                      <Btn variant="primary" onClick={() => start(facing)}>
                        {tr("إعادة المحاولة", "Retry")}
                      </Btn>
                      <Btn onClick={() => setMode("image")}>{tr("استخدم صورة", "Use image")}</Btn>
                    </div>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div layoutId="scan-hero" className="h-full w-full">
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { handleFile(e.target.files?.[0]); e.target.value = ""; }} />
            <button
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
              onDragLeave={() => setDrag(false)}
              onDrop={(e) => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files?.[0]); }}
              className={cx("flex h-full w-full flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed p-6 text-center transition", drag ? "border-primary bg-primary/10" : "border-line bg-card2 hover:border-primary/60")}
            >
              {imgState === "busy" ? <Loader2 className="animate-spin text-primary" size={36} /> : <ScanLine className="text-primary" size={40} />}
              <div className="text-base font-bold">{imgState === "busy" ? tr("جارٍ التحليل…", "Analyzing…") : tr("اختر صورة تحتوي رمز QR", "Choose an image with a QR code")}</div>
              <div className="text-xs text-muted">{tr("اضغط للاختيار أو اسحب الصورة هنا", "Tap to choose or drop an image here")}</div>
              {imgState === "none" && <div className="rounded-xl bg-red-500/10 px-3 py-1.5 text-xs font-semibold text-red-500">{tr("لم يتم العثور على رمز QR في الصورة", "No QR code found in this image")}</div>}
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
