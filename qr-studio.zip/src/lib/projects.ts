import { getType } from "./qrTypes";
import { makeMatrix, type Matrix } from "./qrRender";
import { EXT, exportBlob, uniqueName, zipFiles, type ExportFormat } from "./exporter";
import type { Project, QRStyle, Values } from "./types";

export function buildMatrix(typeId: string, values: Values, style: QRStyle): Matrix | null {
  const b = getType(typeId).build(values);
  if (!b.ok) return null;
  try {
    return makeMatrix(b.data, style.ecc);
  } catch {
    return null;
  }
}

const tick = () => new Promise<void>((r) => setTimeout(r, 0));

/** Export many saved projects into one ZIP. Returns the ZIP blob and the number of failures. */
export async function zipProjects(
  projects: Project[],
  format: ExportFormat,
  size: number,
  onProgress?: (done: number, total: number) => void,
): Promise<{ blob: Blob; failed: number }> {
  const used = new Set<string>();
  const files: { name: string; blob: Blob }[] = [];
  let failed = 0;
  for (let i = 0; i < projects.length; i++) {
    const p = projects[i];
    const m = buildMatrix(p.typeId, p.values, p.style);
    if (!m) failed++;
    else {
      try {
        const blob = await exportBlob(m, p.style, { format, size, margin: p.style.margin, transparent: p.style.bgMode === "transparent", dpi: 300 });
        files.push({ name: uniqueName(p.name, EXT[format], used), blob });
      } catch {
        failed++;
      }
    }
    onProgress?.(i + 1, projects.length);
    await tick();
  }
  return { blob: await zipFiles(files), failed };
}
