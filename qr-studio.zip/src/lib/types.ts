export type Lang = "ar" | "en";
export type Theme = "light" | "dark" | "system";
/** [Arabic, English] */
export type Bi = [string, string];

export type DotShape = "square" | "rounded" | "dot" | "diamond" | "classy" | "lines";
export type EyeShape = "square" | "rounded" | "circle" | "leaf";
export type FrameKind = "none" | "border" | "bottom" | "top" | "bubble" | "text";
export type Ecc = "L" | "M" | "Q" | "H";
export type GradientKind = "none" | "linear" | "radial";
export type BgMode = "solid" | "transparent" | "gradient";

export interface LogoStyle {
  src: string;
  /** fraction of the QR side (0.1 – 0.35) */
  size: number;
  /** offsets in % of the QR side (-30..30) */
  x: number;
  y: number;
  shape: "square" | "circle";
  plate: boolean;
  clear: boolean;
}

export interface QRStyle {
  fg: string;
  fg2: string;
  gradient: GradientKind;
  angle: number;
  bg: string;
  bg2: string;
  bgMode: BgMode;
  dot: DotShape;
  eyeFrame: EyeShape;
  eyeBall: EyeShape;
  eyeCustom: boolean;
  eyeFrameColor: string;
  eyeBallColor: string;
  margin: number;
  ecc: Ecc;
  logo: LogoStyle | null;
  frame: FrameKind;
  frameColor: string;
  frameTextColor: string;
  frameText: string;
}

export type Values = Record<string, string>;

export interface Project {
  id: string;
  name: string;
  typeId: string;
  values: Values;
  style: QRStyle;
  favorite: boolean;
  folderId: string | null;
  createdAt: number;
  updatedAt: number;
  thumb: string;
}

export interface Folder {
  id: string;
  name: string;
}

export interface LogoImage {
  id: string;
  name: string;
  src: string;
  createdAt: number;
}

export interface ScanRecord {
  id: string;
  text: string;
  at: number;
  source: "camera" | "image";
}

export type View = "create" | "scan" | "library" | "tools";

export const DEFAULT_STYLE: QRStyle = {
  fg: "#111827",
  fg2: "#6d5efc",
  gradient: "none",
  angle: 45,
  bg: "#ffffff",
  bg2: "#e0e7ff",
  bgMode: "solid",
  dot: "square",
  eyeFrame: "square",
  eyeBall: "square",
  eyeCustom: false,
  eyeFrameColor: "#111827",
  eyeBallColor: "#111827",
  margin: 2,
  ecc: "M",
  logo: null,
  frame: "none",
  frameColor: "#111827",
  frameTextColor: "#ffffff",
  frameText: "Scan Me",
};

export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
