import jsQR from "jsqr";
import type { Bi, Values } from "./types";
import { renderSVG, svgToCanvas, type Matrix } from "./qrRender";
import type { QRStyle } from "./types";

export function decodeCanvas(cv: HTMLCanvasElement, both = true): string | null {
  const ctx = cv.getContext("2d", { willReadFrequently: true })!;
  const img = ctx.getImageData(0, 0, cv.width, cv.height);
  const r = jsQR(img.data, img.width, img.height, { inversionAttempts: both ? "attemptBoth" : "dontInvert" });
  return r ? r.data : null;
}

/** Decode a QR from an image file. Tries several scales for robustness. */
export async function decodeImageFile(file: File): Promise<string | null> {
  const bmp = await loadBitmap(file);
  const tries = [1600, 1000, 600, 2400];
  for (const maxSide of tries) {
    const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    const cv = document.createElement("canvas");
    cv.width = Math.max(1, Math.round(bmp.width * scale));
    cv.height = Math.max(1, Math.round(bmp.height * scale));
    const ctx = cv.getContext("2d", { willReadFrequently: true })!;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, cv.width, cv.height);
    ctx.drawImage(bmp.source, 0, 0, cv.width, cv.height);
    const res = decodeCanvas(cv, true);
    if (res !== null) return res;
  }
  return null;
}

async function loadBitmap(file: File): Promise<{ source: CanvasImageSource; width: number; height: number }> {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    await new Promise<void>((res, rej) => {
      img.onload = () => res();
      img.onerror = () => rej(new Error("bad image"));
      img.src = url;
    });
    return { source: img, width: img.naturalWidth, height: img.naturalHeight };
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
}

export type Readability = "ok" | "differs" | "fail";

/** Renders the QR as an image and tries to decode it – a real scan test. */
export async function testReadability(m: Matrix, st: QRStyle, expected: string): Promise<Readability> {
  try {
    const r = renderSVG(m, st, { transparent: false });
    const cv = await svgToCanvas(r, 560, "#ffffff");
    const out = decodeCanvas(cv, true);
    if (out === null) return "fail";
    return out === expected ? "ok" : "differs";
  } catch {
    return "fail";
  }
}

/* ------------------------------ link safety ------------------------------ */

export interface LinkInfo {
  isUrl: boolean;
  href: string;
  host: string;
  protocol: string;
  level: "safe" | "warn" | "danger";
  warnings: Bi[];
  openable: boolean;
}

const SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "ow.ly", "cutt.ly", "rb.gy", "shorturl.at", "t.ly", "buff.ly", "rebrand.ly"];
const RISKY_TLD = [".zip", ".mov", ".tk", ".top", ".click", ".xyz", ".gq", ".ml", ".cf", ".work", ".country"];

export function analyzeLink(text: string): LinkInfo {
  const t = text.trim();
  const base: LinkInfo = { isUrl: false, href: t, host: "", protocol: "", level: "safe", warnings: [], openable: false };
  if (!t || /\s/.test(t) && !/^[a-z][a-z0-9+.-]*:/i.test(t)) return base;
  let u: URL;
  try {
    u = new URL(/^[a-z][a-z0-9+.-]*:/i.test(t) ? t : /^[\w-]+(\.[\w-]+)+(\/|$)/.test(t) ? "https://" + t : "");
  } catch {
    return base;
  }
  const proto = u.protocol.replace(":", "");
  const out: LinkInfo = { ...base, isUrl: true, href: u.href, host: u.hostname, protocol: proto, warnings: [] };
  const w = out.warnings;
  if (["javascript", "data", "file", "vbscript", "blob"].includes(proto)) {
    w.push([`بروتوكول خطير (${proto}:) — تم حظر الفتح`, `Dangerous protocol (${proto}:) — opening blocked`]);
    out.level = "danger";
    return out;
  }
  if (["tel", "mailto", "sms", "smsto", "geo"].includes(proto)) {
    out.openable = true;
    return out;
  }
  if (proto !== "http" && proto !== "https") {
    return base;
  }
  out.openable = true;
  const h = u.hostname.toLowerCase();
  if (proto === "http") w.push(["اتصال غير مشفّر (HTTP)", "Unencrypted connection (HTTP)"]);
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h) || h.includes(":")) w.push(["العنوان رقم IP وليس اسم نطاق", "Address is an IP, not a domain name"]);
  if (h.includes("xn--")) w.push(["نطاق بحروف مموّهة (Punycode)", "Look-alike domain (punycode)"]);
  if (u.username || u.password) w.push(["الرابط يحتوي بيانات دخول مخفية (@)", "Link contains embedded credentials (@)"]);
  if (SHORTENERS.some((s) => h === s || h.endsWith("." + s))) w.push(["رابط مختصر يخفي الوجهة الحقيقية", "Shortened link hides the real destination"]);
  if (RISKY_TLD.some((s) => h.endsWith(s))) w.push(["امتداد نطاق يُستخدم كثيراً في الاحتيال", "Domain extension often used for scams"]);
  if (h.split(".").length > 4) w.push(["نطاقات فرعية كثيرة", "Many subdomains"]);
  if (t.length > 250) w.push(["رابط طويل جداً", "Very long link"]);
  if (/[^\x00-\x7f]/.test(h)) w.push(["أحرف غير لاتينية في النطاق", "Non-Latin characters in domain"]);
  out.level = w.length === 0 ? "safe" : w.some((x) => /IP|credentials|Look-alike/.test(x[1])) ? "danger" : "warn";
  return out;
}

/* ------------------------- content type detection ------------------------- */

export interface Detected {
  typeId: string;
  values: Values;
  label: Bi;
}

export function detectContent(text: string): Detected {
  const t = text.trim();
  const lower = t.toLowerCase();
  if (lower.startsWith("wifi:")) {
    const get = (k: string) => {
      const m = t.match(new RegExp(`(?:^|;|:)${k}:((?:\\\\.|[^;])*)`));
      return m ? m[1].replace(/\\(.)/g, "$1") : "";
    };
    return { typeId: "wifi", label: ["شبكة Wi‑Fi", "Wi‑Fi network"], values: { ssid: get("S"), password: get("P"), enc: get("T") || "WPA", hidden: get("H") === "true" ? "true" : "" } };
  }
  if (lower.startsWith("tel:")) return { typeId: "phone", label: ["هاتف", "Phone"], values: { phone: t.slice(4) } };
  if (lower.startsWith("mailto:")) {
    const [to, q = ""] = t.slice(7).split("?");
    const p = new URLSearchParams(q);
    return { typeId: "email", label: ["بريد", "Email"], values: { to, subject: p.get("subject") ?? "", body: p.get("body") ?? "" } };
  }
  if (lower.startsWith("smsto:") || lower.startsWith("sms:")) {
    const rest = t.replace(/^sms(to)?:/i, "");
    const [phone, ...msg] = rest.split(/[:?]/);
    return { typeId: "sms", label: ["رسالة SMS", "SMS"], values: { phone, message: msg.join(":").replace(/^body=/, "") } };
  }
  if (lower.startsWith("geo:")) {
    const [lat, lng] = t.slice(4).split("?")[0].split(",");
    return { typeId: "geo", label: ["موقع", "Location"], values: { lat: lat ?? "", lng: lng ?? "" } };
  }
  if (lower.startsWith("begin:vcard")) return { typeId: "custom", label: ["بطاقة vCard", "vCard"], values: { data: t, mode: "raw" } };
  if (lower.startsWith("begin:vcalendar")) return { typeId: "custom", label: ["حدث تقويم", "Calendar event"], values: { data: t, mode: "raw" } };
  if (lower.startsWith("mecard:")) return { typeId: "custom", label: ["MeCard", "MeCard"], values: { data: t, mode: "raw" } };
  const li = analyzeLink(t);
  if (li.isUrl && (li.protocol === "http" || li.protocol === "https")) return { typeId: "url", label: ["رابط", "Link"], values: { url: t } };
  return { typeId: "text", label: ["نص", "Text"], values: { text: t } };
}
