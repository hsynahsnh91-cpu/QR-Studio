import type { Folder, Lang, LogoImage, Project, QRStyle, ScanRecord, Theme, Values } from "./types";
import { DEFAULT_STYLE } from "./types";

/* ------------------------- localStorage (settings) ------------------------- */

export interface Settings {
  lang: Lang;
  theme: Theme;
}
const SETTINGS_KEY = "qrs.settings";
const DRAFT_KEY = "qrs.draft";

export function loadSettings(): Settings {
  try {
    const s = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "null");
    if (s && (s.lang === "ar" || s.lang === "en")) return { lang: s.lang, theme: s.theme ?? "system" };
  } catch {
    /* ignore */
  }
  const ar = (navigator.language || "").toLowerCase().startsWith("ar");
  return { lang: ar ? "ar" : "en", theme: "system" };
}
export const saveSettings = (s: Settings) => {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
};

export interface Draft {
  typeId: string;
  valuesByType: Record<string, Values>;
  style: QRStyle;
  editingId: string | null;
  name: string;
}
export const emptyDraft = (): Draft => ({ typeId: "url", valuesByType: {}, style: { ...DEFAULT_STYLE }, editingId: null, name: "" });

export function loadDraft(): Draft {
  try {
    const d = JSON.parse(localStorage.getItem(DRAFT_KEY) || "null");
    if (d && d.typeId && d.style) return { ...emptyDraft(), ...d, style: { ...DEFAULT_STYLE, ...d.style } };
  } catch {
    /* ignore */
  }
  return emptyDraft();
}
export function saveDraft(d: Draft) {
  try {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(d));
  } catch {
    /* quota – ignore */
  }
}

export const flag = (k: string) => localStorage.getItem("qrs." + k) === "1";
export const setFlag = (k: string, v = true) => {
  try {
    if (v) localStorage.setItem("qrs." + k, "1");
    else localStorage.removeItem("qrs." + k);
  } catch {
    /* ignore */
  }
};

/* ------------------------------ IndexedDB ------------------------------ */

const DB_NAME = "qr-studio";
const STORES = ["projects", "folders", "images", "history"] as const;
export type StoreName = (typeof STORES)[number];

let dbPromise: Promise<IDBDatabase> | null = null;
function openDB(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((res, rej) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        for (const s of STORES) if (!req.result.objectStoreNames.contains(s)) req.result.createObjectStore(s, { keyPath: "id" });
      };
      req.onsuccess = () => res(req.result);
      req.onerror = () => rej(req.error);
    });
  }
  return dbPromise;
}

async function tx<T>(store: StoreName, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDB();
  return new Promise<T>((res, rej) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    t.oncomplete = () => res(req.result);
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error);
  });
}

export const dbAll = <T,>(store: StoreName) => tx<T[]>(store, "readonly", (s) => s.getAll() as IDBRequest<T[]>);
export const dbPut = <T,>(store: StoreName, item: T) => tx(store, "readwrite", (s) => s.put(item));
export const dbDelete = (store: StoreName, id: string) => tx(store, "readwrite", (s) => s.delete(id));
export const dbClear = (store: StoreName) => tx(store, "readwrite", (s) => s.clear());

export async function dbPutMany<T>(store: StoreName, items: T[]) {
  const db = await openDB();
  return new Promise<void>((res, rej) => {
    const t = db.transaction(store, "readwrite");
    const os = t.objectStore(store);
    items.forEach((i) => os.put(i));
    t.oncomplete = () => res();
    t.onerror = () => rej(t.error);
  });
}

export const getProjects = () => dbAll<Project>("projects");
export const getFolders = () => dbAll<Folder>("folders");
export const getImages = () => dbAll<LogoImage>("images");
export const getHistory = () => dbAll<ScanRecord>("history");

/* ------------------------------- backup ------------------------------- */

interface Backup {
  app: "qr-studio";
  version: 1;
  exportedAt: number;
  settings: Settings;
  projects: Project[];
  folders: Folder[];
  images: LogoImage[];
  history: ScanRecord[];
}

export async function createBackup(settings: Settings): Promise<string> {
  const b: Backup = {
    app: "qr-studio",
    version: 1,
    exportedAt: Date.now(),
    settings,
    projects: await getProjects(),
    folders: await getFolders(),
    images: await getImages(),
    history: await getHistory(),
  };
  return JSON.stringify(b, null, 2);
}

export interface RestoreSummary {
  projects: number;
  folders: number;
  images: number;
  history: number;
}

export async function restoreBackup(json: string, mode: "merge" | "replace"): Promise<RestoreSummary> {
  let b: Backup;
  try {
    b = JSON.parse(json);
  } catch {
    throw new Error("invalid-json");
  }
  if (!b || b.app !== "qr-studio" || !Array.isArray(b.projects)) throw new Error("invalid-backup");
  const projects = b.projects.filter((p) => p && p.id && p.typeId && p.style).map((p) => ({ ...p, style: { ...DEFAULT_STYLE, ...p.style }, values: p.values ?? {} }));
  const folders = (b.folders ?? []).filter((f) => f && f.id);
  const images = (b.images ?? []).filter((i) => i && i.id && i.src);
  const history = (b.history ?? []).filter((h) => h && h.id);
  if (mode === "replace") for (const s of STORES) await dbClear(s);
  await dbPutMany("projects", projects);
  await dbPutMany("folders", folders);
  await dbPutMany("images", images);
  await dbPutMany("history", history);
  return { projects: projects.length, folders: folders.length, images: images.length, history: history.length };
}

export async function clearAllData() {
  for (const s of STORES) await dbClear(s);
  try { localStorage.removeItem(DRAFT_KEY); } catch { /* no storage */ }
}

/* ------------------------- image helpers (logos) ------------------------- */

/** Reads an image file and downsizes it so it stays light in storage. */
export function fileToLogo(file: File, max = 320): Promise<string> {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const w = Math.max(1, Math.round(img.naturalWidth * scale));
      const h = Math.max(1, Math.round(img.naturalHeight * scale));
      const cv = document.createElement("canvas");
      cv.width = w;
      cv.height = h;
      cv.getContext("2d")!.drawImage(img, 0, 0, w, h);
      URL.revokeObjectURL(url);
      res(cv.toDataURL("image/png"));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      rej(new Error("bad image"));
    };
    img.src = url;
  });
}
