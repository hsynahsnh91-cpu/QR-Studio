import qrcode from "qrcode-generator";
import type { DotShape, Ecc, EyeShape, QRStyle } from "./types";

// Use UTF-8 for byte mode so Arabic & Unicode are encoded correctly.
qrcode.stringToBytes = (s: string) => Array.from(new TextEncoder().encode(s));

export interface Matrix {
  n: number;
  cells: boolean[][];
  version: number;
}

export function makeMatrix(data: string, ecc: Ecc): Matrix {
  const qr = qrcode(0, ecc);
  qr.addData(data, "Byte");
  qr.make();
  const n = qr.getModuleCount();
  const cells: boolean[][] = [];
  for (let r = 0; r < n; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < n; c++) row.push(qr.isDark(r, c));
    cells.push(row);
  }
  return { n, cells, version: (n - 17) / 4 };
}

const ALIGN: Record<number, number[]> = {
  2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
  11: [6, 30, 54], 12: [6, 32, 58], 13: [6, 34, 62], 14: [6, 26, 46, 66], 15: [6, 26, 48, 70], 16: [6, 26, 50, 74], 17: [6, 30, 54, 78],
  18: [6, 30, 56, 82], 19: [6, 30, 58, 86], 20: [6, 34, 62, 90], 21: [6, 28, 50, 72, 94], 22: [6, 26, 50, 74, 98], 23: [6, 30, 54, 78, 102],
  24: [6, 28, 54, 80, 106], 25: [6, 32, 58, 84, 110], 26: [6, 30, 58, 86, 114], 27: [6, 34, 62, 90, 118], 28: [6, 26, 50, 74, 98, 122],
  29: [6, 30, 54, 78, 102, 126], 30: [6, 26, 52, 78, 104, 130], 31: [6, 30, 56, 82, 108, 134], 32: [6, 34, 60, 86, 112, 138],
  33: [6, 30, 58, 86, 114, 142], 34: [6, 34, 62, 90, 118, 146], 35: [6, 30, 54, 78, 102, 126, 150], 36: [6, 24, 50, 76, 102, 128, 154],
  37: [6, 28, 54, 80, 106, 132, 158], 38: [6, 32, 58, 84, 110, 136, 162], 39: [6, 26, 54, 82, 110, 138, 166], 40: [6, 30, 58, 86, 114, 142, 170],
};

/** Modules belonging to alignment patterns – always drawn square so decoders can lock on. */
function alignmentCells(m: Matrix): Set<number> {
  const out = new Set<number>();
  const pos = ALIGN[m.version];
  if (!pos) return out;
  const last = pos.length - 1;
  pos.forEach((cy, i) =>
    pos.forEach((cx, j) => {
      if ((i === 0 && j === 0) || (i === 0 && j === last) || (i === last && j === 0)) return;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) out.add((cy + dy) * m.n + (cx + dx));
    }),
  );
  return out;
}

const f = (x: number) => Math.round(x * 100) / 100;
const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function arc(r: number, ex: number, ey: number) {
  return r > 0 ? `A${f(r)} ${f(r)} 0 0 1 ${f(ex)} ${f(ey)}` : `L${f(ex)} ${f(ey)}`;
}
/** rounded rect path with per-corner radii (clockwise) */
function rr(x: number, y: number, w: number, h: number, tl: number, tr: number, br: number, bl: number) {
  return (
    `M${f(x + tl)} ${f(y)}H${f(x + w - tr)}${arc(tr, x + w, y + tr)}V${f(y + h - br)}` +
    `${arc(br, x + w - br, y + h)}H${f(x + bl)}${arc(bl, x, y + h - bl)}V${f(y + tl)}${arc(tl, x + tl, y)}Z`
  );
}
const rrAll = (x: number, y: number, w: number, h: number, r: number) => rr(x, y, w, h, r, r, r, r);

function dotPath(shape: DotShape, x: number, y: number, c: number): string {
  switch (shape) {
    case "rounded":
      return rrAll(x, y, c, c, c * 0.34);
    case "dot":
      return rrAll(x + c * 0.04, y + c * 0.04, c * 0.92, c * 0.92, c * 0.46);
    case "diamond":
      return `M${f(x + c / 2)} ${f(y - c * 0.04)}L${f(x + c * 1.04)} ${f(y + c / 2)}L${f(x + c / 2)} ${f(y + c * 1.04)}L${f(x - c * 0.04)} ${f(y + c / 2)}Z`;
    case "classy":
      return rr(x, y, c, c, c * 0.5, 0, c * 0.5, 0);
    case "lines":
      return rrAll(x + c * 0.1, y - c * 0.02, c * 0.8, c * 1.04, c * 0.4);
    default:
      return `M${f(x - 0.12)} ${f(y - 0.12)}h${f(c + 0.24)}v${f(c + 0.24)}h${f(-c - 0.24)}Z`;
  }
}

function eyeShapePath(shape: EyeShape, x: number, y: number, s: number): string {
  switch (shape) {
    case "rounded":
      return rrAll(x, y, s, s, s * 0.28);
    case "circle":
      return rrAll(x, y, s, s, s / 2);
    case "leaf":
      return rr(x, y, s, s, s * 0.42, 0, s * 0.42, 0);
    default:
      return rrAll(x, y, s, s, 0);
  }
}

export interface RenderOpts {
  margin?: number;
  transparent?: boolean;
}
export interface RenderResult {
  svg: string;
  w: number;
  h: number;
}

const S = 1000;

export function renderSVG(m: Matrix, st: QRStyle, o: RenderOpts = {}): RenderResult {
  const margin = o.margin ?? st.margin;
  const total = m.n + margin * 2;
  const c = S / total;
  const px = (i: number) => (i + margin) * c;
  const transparent = o.transparent || st.bgMode === "transparent";

  // logo geometry
  const lg = st.logo;
  const lgSize = lg ? lg.size * S : 0;
  const lgCx = lg ? S / 2 + (lg.x / 100) * S : 0;
  const lgCy = lg ? S / 2 + (lg.y / 100) * S : 0;
  const lgPad = lg && lg.plate ? c * 0.6 : c * 0.3;
  const hideDot = (r: number, col: number) => {
    if (!lg || !lg.clear) return false;
    const x0 = px(col),
      y0 = px(r);
    const half = lgSize / 2 + lgPad;
    return x0 + c > lgCx - half && x0 < lgCx + half && y0 + c > lgCy - half && y0 < lgCy + half;
  };

  const isEye = (r: number, col: number) =>
    (r < 7 && col < 7) || (r < 7 && col >= m.n - 7) || (r >= m.n - 7 && col < 7);

  const align = alignmentCells(m);
  let dots = "";
  for (let r = 0; r < m.n; r++)
    for (let col = 0; col < m.n; col++)
      if (m.cells[r][col] && !isEye(r, col) && !hideDot(r, col)) dots += dotPath(align.has(r * m.n + col) ? "square" : st.dot, px(col), px(r), c);

  const fgFill = st.gradient !== "none" ? "url(#gf)" : st.fg;
  const eyeFrameFill = st.eyeCustom ? st.eyeFrameColor : fgFill;
  const eyeBallFill = st.eyeCustom ? st.eyeBallColor : fgFill;

  let eyes = "";
  for (const [er, ec] of [
    [0, 0],
    [0, m.n - 7],
    [m.n - 7, 0],
  ]) {
    const x = px(ec),
      y = px(er);
    eyes += `<path fill="${eyeFrameFill}" fill-rule="evenodd" d="${eyeShapePath(st.eyeFrame, x, y, 7 * c)}${eyeShapePath(st.eyeFrame, x + c, y + c, 5 * c)}"/>`;
    eyes += `<path fill="${eyeBallFill}" d="${eyeShapePath(st.eyeBall, x + 2 * c, y + 2 * c, 3 * c)}"/>`;
  }

  // defs
  let defs = "";
  if (st.gradient === "linear") {
    const a = (st.angle * Math.PI) / 180;
    const L = (S / 2) * (Math.abs(Math.cos(a)) + Math.abs(Math.sin(a)));
    defs += `<linearGradient id="gf" gradientUnits="userSpaceOnUse" x1="${f(S / 2 - Math.cos(a) * L)}" y1="${f(S / 2 - Math.sin(a) * L)}" x2="${f(S / 2 + Math.cos(a) * L)}" y2="${f(S / 2 + Math.sin(a) * L)}"><stop offset="0" stop-color="${st.fg}"/><stop offset="1" stop-color="${st.fg2}"/></linearGradient>`;
  } else if (st.gradient === "radial") {
    defs += `<radialGradient id="gf" gradientUnits="userSpaceOnUse" cx="${S / 2}" cy="${S / 2}" r="${S * 0.7}"><stop offset="0" stop-color="${st.fg2}"/><stop offset="1" stop-color="${st.fg}"/></radialGradient>`;
  }
  if (st.bgMode === "gradient" && !transparent) {
    defs += `<linearGradient id="gb" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="${S}" y2="${S}"><stop offset="0" stop-color="${st.bg}"/><stop offset="1" stop-color="${st.bg2}"/></linearGradient>`;
  }
  if (lg && lg.shape === "circle") {
    defs += `<clipPath id="lc"><circle cx="${f(lgCx)}" cy="${f(lgCy)}" r="${f(lgSize / 2)}"/></clipPath>`;
  }

  // frame geometry
  const kind = st.frame;
  const pad = kind === "none" || kind === "text" ? 0 : kind === "bubble" ? 60 : 48;
  const banner = kind === "bottom" || kind === "top" || kind === "bubble" || kind === "text" ? 150 : 0;
  const W = S + pad * 2;
  const H = S + pad * 2 + banner;
  const ox = pad;
  const oy = kind === "top" ? pad + banner : pad;
  const innerR = kind === "bubble" ? 70 : kind === "none" || kind === "text" ? 0 : 28;
  const outerR = kind === "bubble" ? 130 : 64;

  const bgFill = st.bgMode === "gradient" ? "url(#gb)" : st.bg;
  let body = "";
  if (!transparent) body += `<rect width="${S}" height="${S}" rx="${innerR}" fill="${bgFill}"/>`;
  body += `<path fill="${fgFill}" d="${dots}"/>${eyes}`;

  if (lg) {
    if (lg.plate) {
      const ph = lgSize / 2 + lgPad;
      const plateColor = transparent ? "#ffffff" : st.bgMode === "gradient" ? st.bg : st.bg;
      body +=
        lg.shape === "circle"
          ? `<circle cx="${f(lgCx)}" cy="${f(lgCy)}" r="${f(ph)}" fill="${plateColor}"/>`
          : `<rect x="${f(lgCx - ph)}" y="${f(lgCy - ph)}" width="${f(ph * 2)}" height="${f(ph * 2)}" rx="${f(ph * 0.18)}" fill="${plateColor}"/>`;
    }
    body += `<image href="${lg.src}" x="${f(lgCx - lgSize / 2)}" y="${f(lgCy - lgSize / 2)}" width="${f(lgSize)}" height="${f(lgSize)}" preserveAspectRatio="xMidYMid slice"${lg.shape === "circle" ? ' clip-path="url(#lc)"' : ""}/>`;
  }

  let frame = "";
  if (kind !== "none" && kind !== "text") {
    frame += `<path fill="${st.frameColor}" fill-rule="evenodd" d="${rrAll(0, 0, W, H, outerR)}${rrAll(ox, oy, S, S, innerR)}"/>`;
  }
  let label = "";
  if (banner && st.frameText.trim()) {
    const text = st.frameText.trim();
    const fs = Math.min(84, (W * 0.84) / Math.max(4, text.length * 0.62));
    const bandTop = kind === "top" ? 0 : pad + S;
    const cy = kind === "text" ? S + banner / 2 + 10 : bandTop + (banner + (kind === "top" ? pad : pad)) / 2;
    const fill = kind === "text" ? st.frameColor : st.frameTextColor;
    label = `<text x="${W / 2}" y="${f(cy + fs * 0.35)}" font-size="${f(fs)}" font-weight="700" text-anchor="middle" fill="${fill}" font-family="Tahoma,'Segoe UI','Noto Sans Arabic',Arial,sans-serif">${esc(text)}</text>`;
  }

  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">` +
    (defs ? `<defs>${defs}</defs>` : "") +
    frame +
    `<g transform="translate(${ox} ${oy})">${body}</g>` +
    label +
    `</svg>`;
  return { svg, w: W, h: H };
}

export const svgDataUrl = (svg: string) => "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);

/** Rasterise an SVG string to a canvas of the given width (height by ratio). */
export async function svgToCanvas(r: RenderResult, width: number, fill?: string): Promise<HTMLCanvasElement> {
  const height = Math.round((width * r.h) / r.w);
  const sized = r.svg.replace(/width="\d+" height="\d+"/, `width="${width}" height="${height}"`);
  const blob = new Blob([sized], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  try {
    const img = new Image();
    img.decoding = "async";
    await new Promise<void>((res, rej) => {
      img.onload = () => res();
      img.onerror = () => rej(new Error("SVG render failed"));
      img.src = url;
    });
    const cv = document.createElement("canvas");
    cv.width = width;
    cv.height = height;
    const ctx = cv.getContext("2d")!;
    if (fill) {
      ctx.fillStyle = fill;
      ctx.fillRect(0, 0, width, height);
    }
    ctx.drawImage(img, 0, 0, width, height);
    return cv;
  } finally {
    URL.revokeObjectURL(url);
  }
}

/* --------------------------- colour helpers --------------------------- */

export function luminance(hex: string): number {
  const h = hex.replace("#", "");
  const v = h.length === 3 ? h.split("").map((x) => x + x).join("") : h;
  const [r, g, b] = [0, 2, 4].map((i) => {
    const c = parseInt(v.slice(i, i + 2), 16) / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrast(a: string, b: string): number {
  const l1 = luminance(a),
    l2 = luminance(b);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

export interface StyleWarning {
  id: string;
  level: "warn" | "error";
  text: [string, string];
}
export function styleWarnings(st: QRStyle): StyleWarning[] {
  const out: StyleWarning[] = [];
  const bg = st.bgMode === "transparent" ? "#ffffff" : st.bg;
  const fgs = st.gradient === "none" ? [st.fg] : [st.fg, st.fg2];
  const minC = Math.min(...fgs.map((x) => contrast(x, bg)));
  if (minC < 2.5) out.push({ id: "c", level: "error", text: ["التباين ضعيف جداً — قد لا يُقرأ الرمز", "Very low contrast — the code may not scan"] });
  else if (minC < 4) out.push({ id: "c", level: "warn", text: ["التباين منخفض — يُفضّل ألواناً أغمق", "Low contrast — use darker colors"] });
  if (fgs.some((x) => luminance(x) > luminance(bg)))
    out.push({ id: "i", level: "warn", text: ["الرمز أفتح من الخلفية (معكوس) وبعض الماسحات لا تقرؤه", "Light-on-dark (inverted): some scanners can't read it"] });
  if (st.bgMode === "transparent") out.push({ id: "t", level: "warn", text: ["الخلفية الشفافة تتطلب سطحاً فاتحاً عند الطباعة", "Transparent background needs a light surface"] });
  if (st.logo) {
    if (st.logo.size > 0.28) out.push({ id: "l", level: "error", text: ["الشعار كبير جداً ويغطي بيانات الرمز", "Logo is too large and covers data"] });
    else if (st.logo.size > 0.2 && st.ecc !== "H") out.push({ id: "l", level: "warn", text: ["شعار كبير: ارفع التصحيح إلى H", "Large logo: raise error correction to H"] });
    if (!st.logo.clear && st.ecc !== "H") out.push({ id: "l2", level: "warn", text: ["الشعار فوق النقاط: استخدم تصحيح H", "Logo over dots: use correction level H"] });
  }
  if (st.margin < 2) out.push({ id: "m", level: "warn", text: ["الهامش أقل من 2 وحدة — قد يضعف القراءة", "Margin under 2 modules may hurt scanning"] });
  return out;
}
