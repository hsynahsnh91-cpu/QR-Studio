import JSZip from "jszip";
import { jsPDF } from "jspdf";
import { makeMatrix, renderSVG, svgToCanvas, type Matrix } from "./qrRender";
import type { QRStyle } from "./types";

export type ExportFormat = "png" | "svg" | "jpeg" | "webp" | "pdf";
export interface ExportOpts {
  format: ExportFormat;
  size: number;
  margin: number;
  transparent: boolean;
  dpi: number;
}

export const FORMATS: ExportFormat[] = ["png", "svg", "jpeg", "webp", "pdf"];
export const EXT: Record<ExportFormat, string> = { png: "png", svg: "svg", jpeg: "jpg", webp: "webp", pdf: "pdf" };
const MIME: Record<ExportFormat, string> = {
  png: "image/png",
  svg: "image/svg+xml",
  jpeg: "image/jpeg",
  webp: "image/webp",
  pdf: "application/pdf",
};
export const supportsAlpha = (f: ExportFormat) => f === "png" || f === "svg" || f === "webp";

const canvasBlob = (cv: HTMLCanvasElement, type: string, q?: number) =>
  new Promise<Blob>((res, rej) => cv.toBlob((b) => (b ? res(b) : rej(new Error("encode failed"))), type, q));

export async function exportBlob(m: Matrix, style: QRStyle, o: ExportOpts): Promise<Blob> {
  const transparent = o.transparent && supportsAlpha(o.format);
  const r = renderSVG(m, style, { margin: o.margin, transparent });
  if (o.format === "svg") return new Blob([r.svg], { type: MIME.svg });
  const size = Math.min(4096, Math.max(64, Math.round(o.size)));
  if (o.format === "pdf") {
    const cv = await svgToCanvas(r, Math.max(size, 1200), "#ffffff");
    const png = cv.toDataURL("image/png");
    const doc = new jsPDF({ unit: "mm", format: "a4" });
    const wMm = Math.min(180, (size / o.dpi) * 25.4);
    const hMm = (wMm * r.h) / r.w;
    doc.addImage(png, "PNG", (210 - wMm) / 2, 30, wMm, hMm, undefined, "FAST");
    return doc.output("blob");
  }
  const needsFill = o.format === "jpeg" || (!transparent && style.bgMode === "transparent");
  const cv = await svgToCanvas(r, size, needsFill ? "#ffffff" : undefined);
  return canvasBlob(cv, MIME[o.format], 0.95);
}

export async function thumbnail(m: Matrix, style: QRStyle): Promise<string> {
  const r = renderSVG(m, style, { transparent: false });
  const cv = await svgToCanvas(r, 192, "#ffffff");
  return cv.toDataURL("image/png");
}

export const safeName = (s: string) =>
  (s.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/\s+/g, " ").trim().slice(0, 80) || "qr").replace(/^\.+/, "_");

export function uniqueName(base: string, ext: string, used: Set<string>) {
  let name = `${safeName(base)}.${ext}`;
  let i = 2;
  while (used.has(name.toLowerCase())) name = `${safeName(base)}_${i++}.${ext}`;
  used.add(name.toLowerCase());
  return name;
}

export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export async function zipFiles(files: { name: string; blob: Blob }[]): Promise<Blob> {
  const zip = new JSZip();
  for (const f of files) zip.file(f.name, f.blob);
  return zip.generateAsync({ type: "blob", compression: "DEFLATE" });
}

export async function copyImage(m: Matrix, style: QRStyle, size = 1024): Promise<void> {
  const blob = await exportBlob(m, style, { format: "png", size, margin: style.margin, transparent: false, dpi: 300 });
  if (!navigator.clipboard || typeof ClipboardItem === "undefined") throw new Error("clipboard unsupported");
  await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
}

export async function copyText(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    if (!ok) throw new Error("copy failed");
  }
}

/** Returns false when the Web Share API with files is unavailable. */
export async function shareBlob(blob: Blob, name: string, title: string): Promise<boolean> {
  const file = new File([blob], name, { type: blob.type });
  const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
  if (!nav.share || !nav.canShare || !nav.canShare({ files: [file] })) return false;
  try {
    await nav.share({ files: [file], title });
  } catch (e) {
    if ((e as DOMException).name === "AbortError") return true;
    throw e;
  }
  return true;
}

export { makeMatrix };
