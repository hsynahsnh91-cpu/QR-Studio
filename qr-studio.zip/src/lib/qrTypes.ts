import {
  AppWindow,
  Barcode,
  BookOpen,
  Braces,
  CalendarDays,
  Contact,
  CreditCard,
  Globe,
  IdCard,
  Link as LinkIcon,
  Mail,
  MapPin,
  MessageCircle,
  MessageSquare,
  Package,
  Phone,
  QrCode,
  Send,
  Share2,
  Ticket,
  Type as TypeIcon,
  Wifi,
  type LucideIcon,
} from "lucide-react";
import type { Bi, Values } from "./types";

export interface FieldOption {
  value: string;
  label: Bi;
}
export interface FieldDef {
  key: string;
  label: Bi;
  kind:
    | "text"
    | "textarea"
    | "select"
    | "datetime"
    | "date"
    | "checkbox"
    | "tel"
    | "email"
    | "url"
    | "password"
    | "number";
  placeholder?: string;
  options?: FieldOption[];
  span?: 1 | 2;
  ltr?: boolean;
  showIf?: (v: Values) => boolean;
  action?: "geo" | "ticketId";
}
export interface BuildResult {
  ok: boolean;
  data: string;
  errors: Record<string, Bi>;
}
export type GroupId = "basic" | "contact" | "place" | "business" | "advanced";
export interface TypeDef {
  id: string;
  icon: LucideIcon;
  group: GroupId;
  label: Bi;
  fields: FieldDef[];
  defaults?: Values;
  build: (v: Values) => BuildResult;
}

export const GROUPS: { id: GroupId; label: Bi }[] = [
  { id: "basic", label: ["أساسي", "Basic"] },
  { id: "contact", label: ["التواصل", "Contact"] },
  { id: "place", label: ["مكان ووقت", "Place & time"] },
  { id: "business", label: ["أعمال ودفع", "Business & pay"] },
  { id: "advanced", label: ["متقدم", "Advanced"] },
];

/* ------------------------------ helpers ------------------------------ */

const M = {
  required: ["هذا الحقل مطلوب", "This field is required"] as Bi,
  url: ["رابط غير صالح", "Invalid URL"] as Bi,
  email: ["بريد إلكتروني غير صالح", "Invalid email"] as Bi,
  phone: ["رقم هاتف غير صالح", "Invalid phone number"] as Bi,
  number: ["قيمة رقمية غير صالحة", "Invalid number"] as Bi,
  date: ["تاريخ غير صالح", "Invalid date"] as Bi,
};

type Errs = Record<string, Bi>;
const val = (v: Values, k: string) => (v[k] ?? "").trim();
const done = (e: Errs, data: string): BuildResult => {
  const ok = Object.keys(e).length === 0;
  return { ok, data: ok ? data : "", errors: e };
};
const need = (e: Errs, v: Values, ...keys: string[]) => {
  for (const k of keys) if (!val(v, k)) e[k] = M.required;
};
const enc = encodeURIComponent;

export const normUrl = (s: string) => {
  const t = s.trim();
  if (!t) return t;
  if (/^[a-z][a-z0-9+.-]*:/i.test(t) && !/^[a-z0-9.-]+:\d+(\/|$)/i.test(t)) return t;
  return "https://" + t.replace(/^\/\//, "");
};
export const isUrl = (s: string) => {
  try {
    const u = new URL(normUrl(s));
    if (/^https?:$/.test(u.protocol)) return u.hostname.includes(".") || u.hostname === "localhost";
    return true;
  } catch {
    return false;
  }
};
const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s);
const phoneDigits = (s: string) => s.replace(/[\s\-().]/g, "");
const isPhone = (s: string) => /^\+?\d{5,16}$/.test(phoneDigits(s));
const isNum = (s: string) => s !== "" && !isNaN(Number(s)) && isFinite(Number(s));
const escWifi = (s: string) => s.replace(/([\\;,:"])/g, "\\$1");
const escMe = (s: string) => s.replace(/([\\;,:])/g, "\\$1");
const escV = (s: string) =>
  s.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/;/g, "\\;").replace(/,/g, "\\,");
const compactDT = (s: string) => s.replace(/[-:]/g, "").slice(0, 15).padEnd(15, "0");

export const gtinValid = (d: string) => {
  if (!/^\d{8}$|^\d{12,14}$/.test(d)) return false;
  const digits = d.split("").map(Number);
  const check = digits.pop()!;
  let sum = 0;
  digits.reverse().forEach((n, i) => (sum += n * (i % 2 === 0 ? 3 : 1)));
  return (10 - (sum % 10)) % 10 === check;
};
const isbn10Valid = (d: string) => {
  if (!/^\d{9}[\dXx]$/.test(d)) return false;
  let sum = 0;
  for (let i = 0; i < 10; i++) {
    const c = d[i].toUpperCase();
    sum += (c === "X" ? 10 : Number(c)) * (10 - i);
  }
  return sum % 11 === 0;
};
const isbn10to13 = (d: string) => {
  const base = "978" + d.slice(0, 9);
  let sum = 0;
  base.split("").forEach((c, i) => (sum += Number(c) * (i % 2 === 0 ? 1 : 3)));
  return base + ((10 - (sum % 10)) % 10);
};
const ibanValid = (s: string) => {
  const i = s.replace(/\s/g, "").toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(i)) return false;
  const r = (i.slice(4) + i.slice(0, 4))
    .split("")
    .map((c) => (/[A-Z]/.test(c) ? String(c.charCodeAt(0) - 55) : c))
    .join("");
  let rem = 0;
  for (const ch of r) rem = (rem * 10 + Number(ch)) % 97;
  return rem === 1;
};
const yymmdd = (iso: string) => iso.replace(/-/g, "").slice(2, 8);

const opt = (value: string, ar: string, en: string): FieldOption => ({ value, label: [ar, en] });

/* ------------------------------ definitions ------------------------------ */

const SOCIAL: Record<string, string> = {
  facebook: "https://facebook.com/",
  instagram: "https://instagram.com/",
  x: "https://x.com/",
  tiktok: "https://tiktok.com/@",
  youtube: "https://youtube.com/@",
  linkedin: "https://linkedin.com/in/",
  snapchat: "https://snapchat.com/add/",
  github: "https://github.com/",
  pinterest: "https://pinterest.com/",
  threads: "https://threads.net/@",
};

export const TYPES: TypeDef[] = [
  {
    id: "url",
    icon: LinkIcon,
    group: "basic",
    label: ["رابط", "URL"],
    fields: [{ key: "url", label: ["الرابط", "Link"], kind: "url", placeholder: "https://example.com", span: 2, ltr: true }],
    build(v) {
      const e: Errs = {};
      if (!val(v, "url")) e.url = M.required;
      else if (!isUrl(val(v, "url"))) e.url = M.url;
      return done(e, normUrl(val(v, "url")));
    },
  },
  {
    id: "text",
    icon: TypeIcon,
    group: "basic",
    label: ["نص", "Text"],
    fields: [{ key: "text", label: ["النص", "Text"], kind: "textarea", span: 2, placeholder: "…" }],
    build(v) {
      const e: Errs = {};
      if (!(v.text ?? "").trim()) e.text = M.required;
      return done(e, v.text ?? "");
    },
  },
  {
    id: "phone",
    icon: Phone,
    group: "basic",
    label: ["هاتف", "Phone"],
    fields: [{ key: "phone", label: ["رقم الهاتف", "Phone number"], kind: "tel", placeholder: "+966500000000", span: 2, ltr: true }],
    build(v) {
      const e: Errs = {};
      if (!val(v, "phone")) e.phone = M.required;
      else if (!isPhone(val(v, "phone"))) e.phone = M.phone;
      return done(e, "tel:" + phoneDigits(val(v, "phone")));
    },
  },
  {
    id: "sms",
    icon: MessageSquare,
    group: "basic",
    label: ["رسالة SMS", "SMS"],
    fields: [
      { key: "phone", label: ["رقم الهاتف", "Phone number"], kind: "tel", ltr: true, span: 2, placeholder: "+966500000000" },
      { key: "message", label: ["الرسالة", "Message"], kind: "textarea", span: 2 },
    ],
    build(v) {
      const e: Errs = {};
      if (!val(v, "phone")) e.phone = M.required;
      else if (!isPhone(val(v, "phone"))) e.phone = M.phone;
      return done(e, `SMSTO:${phoneDigits(val(v, "phone"))}:${v.message ?? ""}`);
    },
  },
  {
    id: "email",
    icon: Mail,
    group: "basic",
    label: ["بريد", "Email"],
    fields: [
      { key: "to", label: ["إلى", "To"], kind: "email", ltr: true, span: 2, placeholder: "name@example.com" },
      { key: "subject", label: ["الموضوع", "Subject"], kind: "text", span: 2 },
      { key: "body", label: ["النص", "Body"], kind: "textarea", span: 2 },
    ],
    build(v) {
      const e: Errs = {};
      if (!val(v, "to")) e.to = M.required;
      else if (!isEmail(val(v, "to"))) e.to = M.email;
      const q: string[] = [];
      if (val(v, "subject")) q.push("subject=" + enc(v.subject));
      if (val(v, "body")) q.push("body=" + enc(v.body));
      return done(e, `mailto:${val(v, "to")}${q.length ? "?" + q.join("&") : ""}`);
    },
  },
  {
    id: "wifi",
    icon: Wifi,
    group: "basic",
    label: ["Wi‑Fi", "Wi‑Fi"],
    defaults: { enc: "WPA" },
    fields: [
      { key: "ssid", label: ["اسم الشبكة", "Network name"], kind: "text", span: 2 },
      {
        key: "enc",
        label: ["التشفير", "Security"],
        kind: "select",
        options: [opt("WPA", "WPA/WPA2/WPA3", "WPA/WPA2/WPA3"), opt("WEP", "WEP", "WEP"), opt("nopass", "بدون كلمة مرور", "None")],
      },
      { key: "hidden", label: ["شبكة مخفية", "Hidden network"], kind: "checkbox" },
      { key: "password", label: ["كلمة المرور", "Password"], kind: "password", span: 2, ltr: true, showIf: (v) => v.enc !== "nopass" },
    ],
    build(v) {
      const e: Errs = {};
      need(e, v, "ssid");
      const enc2 = v.enc || "WPA";
      if (enc2 !== "nopass") {
        if (!v.password) e.password = M.required;
        else if (enc2 === "WPA" && v.password.length < 8) e.password = ["8 أحرف على الأقل", "At least 8 characters"];
      }
      const data = `WIFI:T:${enc2};S:${escWifi(v.ssid ?? "")};${enc2 !== "nopass" ? `P:${escWifi(v.password ?? "")};` : ""}${v.hidden === "true" ? "H:true;" : ""};`;
      return done(e, data);
    },
  },
  {
    id: "vcard",
    icon: Contact,
    group: "contact",
    label: ["بطاقة vCard", "vCard"],
    fields: [
      { key: "first", label: ["الاسم الأول", "First name"], kind: "text" },
      { key: "last", label: ["اسم العائلة", "Last name"], kind: "text" },
      { key: "org", label: ["الشركة", "Company"], kind: "text" },
      { key: "title", label: ["المسمى", "Job title"], kind: "text" },
      { key: "mobile", label: ["الجوال", "Mobile"], kind: "tel", ltr: true },
      { key: "work", label: ["هاتف العمل", "Work phone"], kind: "tel", ltr: true },
      { key: "email", label: ["البريد", "Email"], kind: "email", ltr: true },
      { key: "url", label: ["الموقع", "Website"], kind: "url", ltr: true },
      { key: "street", label: ["الشارع", "Street"], kind: "text" },
      { key: "city", label: ["المدينة", "City"], kind: "text" },
      { key: "country", label: ["الدولة", "Country"], kind: "text" },
      { key: "note", label: ["ملاحظة", "Note"], kind: "text" },
    ],
    build(v) {
      const e: Errs = {};
      if (!val(v, "first") && !val(v, "last")) {
        e.first = M.required;
        e.last = M.required;
      }
      if (val(v, "mobile") && !isPhone(val(v, "mobile"))) e.mobile = M.phone;
      if (val(v, "work") && !isPhone(val(v, "work"))) e.work = M.phone;
      if (val(v, "email") && !isEmail(val(v, "email"))) e.email = M.email;
      if (val(v, "url") && !isUrl(val(v, "url"))) e.url = M.url;
      const L = ["BEGIN:VCARD", "VERSION:3.0", `N:${escV(val(v, "last"))};${escV(val(v, "first"))};;;`, `FN:${escV(`${val(v, "first")} ${val(v, "last")}`.trim())}`];
      if (val(v, "org")) L.push(`ORG:${escV(val(v, "org"))}`);
      if (val(v, "title")) L.push(`TITLE:${escV(val(v, "title"))}`);
      if (val(v, "mobile")) L.push(`TEL;TYPE=CELL:${phoneDigits(val(v, "mobile"))}`);
      if (val(v, "work")) L.push(`TEL;TYPE=WORK,VOICE:${phoneDigits(val(v, "work"))}`);
      if (val(v, "email")) L.push(`EMAIL:${val(v, "email")}`);
      if (val(v, "url")) L.push(`URL:${normUrl(val(v, "url"))}`);
      if (val(v, "street") || val(v, "city") || val(v, "country"))
        L.push(`ADR;TYPE=WORK:;;${escV(val(v, "street"))};${escV(val(v, "city"))};;;${escV(val(v, "country"))}`);
      if (val(v, "note")) L.push(`NOTE:${escV(val(v, "note"))}`);
      L.push("END:VCARD");
      return done(e, L.join("\r\n"));
    },
  },
  {
    id: "mecard",
    icon: IdCard,
    group: "contact",
    label: ["MeCard", "MeCard"],
    fields: [
      { key: "first", label: ["الاسم الأول", "First name"], kind: "text" },
      { key: "last", label: ["اسم العائلة", "Last name"], kind: "text" },
      { key: "phone", label: ["الهاتف", "Phone"], kind: "tel", ltr: true },
      { key: "email", label: ["البريد", "Email"], kind: "email", ltr: true },
      { key: "url", label: ["الموقع", "Website"], kind: "url", ltr: true },
      { key: "adr", label: ["العنوان", "Address"], kind: "text" },
      { key: "note", label: ["ملاحظة", "Note"], kind: "text", span: 2 },
    ],
    build(v) {
      const e: Errs = {};
      if (!val(v, "first") && !val(v, "last")) {
        e.first = M.required;
        e.last = M.required;
      }
      if (val(v, "phone") && !isPhone(val(v, "phone"))) e.phone = M.phone;
      if (val(v, "email") && !isEmail(val(v, "email"))) e.email = M.email;
      if (val(v, "url") && !isUrl(val(v, "url"))) e.url = M.url;
      let d = `MECARD:N:${escMe(val(v, "last"))},${escMe(val(v, "first"))};`;
      if (val(v, "phone")) d += `TEL:${phoneDigits(val(v, "phone"))};`;
      if (val(v, "email")) d += `EMAIL:${escMe(val(v, "email"))};`;
      if (val(v, "url")) d += `URL:${escMe(normUrl(val(v, "url")))};`;
      if (val(v, "adr")) d += `ADR:${escMe(val(v, "adr"))};`;
      if (val(v, "note")) d += `NOTE:${escMe(val(v, "note"))};`;
      return done(e, d + ";");
    },
  },
  {
    id: "whatsapp",
    icon: MessageCircle,
    group: "contact",
    label: ["واتساب", "WhatsApp"],
    fields: [
      { key: "phone", label: ["الرقم بصيغة دولية", "Number (international)"], kind: "tel", ltr: true, span: 2, placeholder: "966500000000" },
      { key: "message", label: ["رسالة جاهزة", "Prefilled message"], kind: "textarea", span: 2 },
    ],
    build(v) {
      const e: Errs = {};
      const d = phoneDigits(val(v, "phone")).replace(/^\+/, "").replace(/^00/, "");
      if (!val(v, "phone")) e.phone = M.required;
      else if (!/^\d{7,15}$/.test(d)) e.phone = M.phone;
      return done(e, `https://wa.me/${d}${val(v, "message") ? "?text=" + enc(v.message) : ""}`);
    },
  },
  {
    id: "telegram",
    icon: Send,
    group: "contact",
    label: ["تيليجرام", "Telegram"],
    defaults: { kind: "user" },
    fields: [
      {
        key: "kind",
        label: ["النوع", "Kind"],
        kind: "select",
        span: 2,
        options: [opt("user", "مستخدم / قناة", "User / channel"), opt("phone", "رقم هاتف", "Phone"), opt("share", "مشاركة نص", "Share text")],
      },
      { key: "user", label: ["اسم المستخدم", "Username"], kind: "text", ltr: true, span: 2, placeholder: "username", showIf: (v) => (v.kind || "user") === "user" },
      { key: "phone", label: ["الهاتف", "Phone"], kind: "tel", ltr: true, span: 2, showIf: (v) => v.kind === "phone" },
      { key: "text", label: ["النص", "Text"], kind: "textarea", span: 2, showIf: (v) => v.kind === "share" },
    ],
    build(v) {
      const e: Errs = {};
      const k = v.kind || "user";
      let d = "";
      if (k === "user") {
        const u = val(v, "user").replace(/^@/, "").replace(/^https?:\/\/t\.me\//i, "");
        if (!u) e.user = M.required;
        else if (!/^[A-Za-z0-9_]{4,32}$/.test(u)) e.user = ["اسم مستخدم غير صالح (4-32 حرفاً)", "Invalid username (4-32 chars)"];
        d = `https://t.me/${u}`;
      } else if (k === "phone") {
        if (!val(v, "phone")) e.phone = M.required;
        else if (!isPhone(val(v, "phone"))) e.phone = M.phone;
        d = `https://t.me/+${phoneDigits(val(v, "phone")).replace(/^\+/, "")}`;
      } else {
        if (!val(v, "text")) e.text = M.required;
        d = `https://t.me/share/url?url=%20&text=${enc(v.text ?? "")}`;
      }
      return done(e, d);
    },
  },
  {
    id: "social",
    icon: Share2,
    group: "contact",
    label: ["تواصل اجتماعي", "Social"],
    defaults: { platform: "instagram" },
    fields: [
      {
        key: "platform",
        label: ["المنصة", "Platform"],
        kind: "select",
        options: [
          opt("instagram", "Instagram", "Instagram"),
          opt("facebook", "Facebook", "Facebook"),
          opt("x", "X (Twitter)", "X (Twitter)"),
          opt("tiktok", "TikTok", "TikTok"),
          opt("youtube", "YouTube", "YouTube"),
          opt("linkedin", "LinkedIn", "LinkedIn"),
          opt("snapchat", "Snapchat", "Snapchat"),
          opt("github", "GitHub", "GitHub"),
          opt("pinterest", "Pinterest", "Pinterest"),
          opt("threads", "Threads", "Threads"),
        ],
      },
      { key: "user", label: ["اسم المستخدم أو الرابط", "Username or link"], kind: "text", ltr: true, placeholder: "@username" },
    ],
    build(v) {
      const e: Errs = {};
      const raw = val(v, "user");
      if (!raw) e.user = M.required;
      let d = "";
      if (raw && /^https?:\/\//i.test(raw)) {
        if (!isUrl(raw)) e.user = M.url;
        d = raw;
      } else if (raw) {
        const u = raw.replace(/^@/, "");
        if (!/^[\w.\-]+$/.test(u)) e.user = ["اسم مستخدم غير صالح", "Invalid username"];
        d = (SOCIAL[v.platform || "instagram"] ?? SOCIAL.instagram) + u;
      }
      return done(e, d);
    },
  },
  {
    id: "geo",
    icon: MapPin,
    group: "place",
    label: ["موقع جغرافي", "Location"],
    fields: [
      { key: "lat", label: ["خط العرض", "Latitude"], kind: "text", ltr: true, placeholder: "24.7136" },
      { key: "lng", label: ["خط الطول", "Longitude"], kind: "text", ltr: true, placeholder: "46.6753" },
      { key: "label", label: ["اسم المكان (اختياري)", "Place name (optional)"], kind: "text", span: 2, action: "geo" },
    ],
    build(v) {
      const e: Errs = {};
      const lat = val(v, "lat"),
        lng = val(v, "lng");
      if (!lat) e.lat = M.required;
      else if (!isNum(lat) || Math.abs(Number(lat)) > 90) e.lat = ["بين -90 و 90", "Between -90 and 90"];
      if (!lng) e.lng = M.required;
      else if (!isNum(lng) || Math.abs(Number(lng)) > 180) e.lng = ["بين -180 و 180", "Between -180 and 180"];
      const q = val(v, "label") ? `?q=${lat},${lng}(${enc(val(v, "label"))})` : "";
      return done(e, `geo:${lat},${lng}${q}`);
    },
  },
  {
    id: "calendar",
    icon: CalendarDays,
    group: "place",
    label: ["تقويم", "Calendar"],
    fields: [
      { key: "title", label: ["العنوان", "Title"], kind: "text", span: 2 },
      { key: "start", label: ["البداية", "Start"], kind: "datetime" },
      { key: "end", label: ["النهاية", "End"], kind: "datetime" },
      { key: "allDay", label: ["طوال اليوم", "All day"], kind: "checkbox" },
      { key: "location", label: ["المكان", "Location"], kind: "text" },
      { key: "desc", label: ["الوصف", "Description"], kind: "textarea", span: 2 },
    ],
    build(v) {
      const e: Errs = {};
      need(e, v, "title", "start");
      const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/;/g, "\\;").replace(/,/g, "\\,");
      const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "BEGIN:VEVENT", `SUMMARY:${esc(val(v, "title"))}`];
      if (val(v, "start")) {
        if (isNaN(Date.parse(val(v, "start")))) e.start = M.date;
        else if (v.allDay === "true") {
          const s = val(v, "start").slice(0, 10);
          const eDate = val(v, "end") ? val(v, "end").slice(0, 10) : s;
          if (eDate < s) e.end = ["النهاية قبل البداية", "End is before start"];
          const next = new Date(eDate + "T00:00:00Z");
          next.setUTCDate(next.getUTCDate() + 1);
          L.push(`DTSTART;VALUE=DATE:${s.replace(/-/g, "")}`, `DTEND;VALUE=DATE:${next.toISOString().slice(0, 10).replace(/-/g, "")}`);
        } else {
          L.push(`DTSTART:${compactDT(val(v, "start")).slice(0, 8)}T${compactDT(val(v, "start")).slice(9, 15) || "000000"}`);
          if (val(v, "end")) {
            if (val(v, "end") < val(v, "start")) e.end = ["النهاية قبل البداية", "End is before start"];
            L.push(`DTEND:${compactDT(val(v, "end")).slice(0, 8)}T${compactDT(val(v, "end")).slice(9, 15) || "000000"}`);
          }
        }
      }
      if (val(v, "location")) L.push(`LOCATION:${esc(val(v, "location"))}`);
      if (val(v, "desc")) L.push(`DESCRIPTION:${esc(val(v, "desc"))}`);
      L.push("END:VEVENT", "END:VCALENDAR");
      return done(e, L.join("\r\n"));
    },
  },
  {
    id: "ticket",
    icon: Ticket,
    group: "place",
    label: ["تذكرة فعالية", "Event ticket"],
    fields: [
      { key: "event", label: ["اسم الفعالية", "Event"], kind: "text", span: 2 },
      { key: "date", label: ["الموعد", "Date"], kind: "datetime" },
      { key: "venue", label: ["المكان", "Venue"], kind: "text" },
      { key: "holder", label: ["اسم الحامل", "Holder"], kind: "text" },
      { key: "seat", label: ["المقعد", "Seat"], kind: "text" },
      { key: "tier", label: ["الفئة", "Type"], kind: "text" },
      { key: "ticketId", label: ["رقم التذكرة", "Ticket ID"], kind: "text", ltr: true, action: "ticketId" },
    ],
    build(v) {
      const e: Errs = {};
      need(e, v, "event", "ticketId");
      const o: Record<string, string> = { t: "ticket" };
      const map: [string, string][] = [["event", "event"], ["date", "date"], ["venue", "venue"], ["holder", "holder"], ["seat", "seat"], ["tier", "type"], ["ticketId", "id"]];
      for (const [k, n] of map) if (val(v, k)) o[n] = val(v, k);
      return done(e, JSON.stringify(o));
    },
  },
  {
    id: "app",
    icon: AppWindow,
    group: "place",
    label: ["رابط تطبيق", "App link"],
    defaults: { store: "play" },
    fields: [
      {
        key: "store",
        label: ["المتجر", "Store"],
        kind: "select",
        options: [opt("play", "Google Play", "Google Play"), opt("apple", "App Store", "App Store"), opt("huawei", "AppGallery", "AppGallery"), opt("custom", "رابط مخصص", "Custom link")],
      },
      { key: "id", label: ["المعرّف أو الرابط", "ID or link"], kind: "text", ltr: true, placeholder: "com.example.app" },
    ],
    build(v) {
      const e: Errs = {};
      const s = v.store || "play";
      const id = val(v, "id");
      let d = "";
      if (!id) e.id = M.required;
      else if (s === "play") {
        if (!/^[a-zA-Z][\w]*(\.[\w]+)+$/.test(id)) e.id = ["اسم الحزمة غير صالح", "Invalid package name"];
        d = `https://play.google.com/store/apps/details?id=${id}`;
      } else if (s === "apple") {
        const n = id.replace(/^id/i, "");
        if (!/^\d{6,12}$/.test(n)) e.id = ["معرّف رقمي مطلوب", "Numeric ID required"];
        d = `https://apps.apple.com/app/id${n}`;
      } else if (s === "huawei") {
        const n = id.replace(/^C/i, "");
        if (!/^\d{5,12}$/.test(n)) e.id = ["معرّف رقمي مطلوب", "Numeric ID required"];
        d = `https://appgallery.huawei.com/app/C${n}`;
      } else {
        if (!isUrl(id)) e.id = M.url;
        d = normUrl(id);
      }
      return done(e, d);
    },
  },
  {
    id: "product",
    icon: Package,
    group: "business",
    label: ["منتج", "Product"],
    fields: [
      { key: "name", label: ["اسم المنتج", "Product name"], kind: "text", span: 2 },
      { key: "brand", label: ["العلامة", "Brand"], kind: "text" },
      { key: "sku", label: ["SKU / الرمز", "SKU"], kind: "text", ltr: true },
      { key: "price", label: ["السعر", "Price"], kind: "number", ltr: true },
      { key: "currency", label: ["العملة", "Currency"], kind: "text", ltr: true, placeholder: "SAR" },
      { key: "url", label: ["رابط المنتج", "Product link"], kind: "url", ltr: true, span: 2 },
      { key: "desc", label: ["الوصف", "Description"], kind: "textarea", span: 2 },
    ],
    build(v) {
      const e: Errs = {};
      need(e, v, "name");
      if (val(v, "price") && (!isNum(val(v, "price")) || Number(val(v, "price")) < 0)) e.price = M.number;
      if (val(v, "url") && !isUrl(val(v, "url"))) e.url = M.url;
      const L = [`Product: ${val(v, "name")}`];
      if (val(v, "brand")) L.push(`Brand: ${val(v, "brand")}`);
      if (val(v, "sku")) L.push(`SKU: ${val(v, "sku")}`);
      if (val(v, "price")) L.push(`Price: ${val(v, "price")} ${val(v, "currency")}`.trim());
      if (val(v, "url")) L.push(`URL: ${normUrl(val(v, "url"))}`);
      if (val(v, "desc")) L.push(val(v, "desc"));
      return done(e, L.join("\n"));
    },
  },
  {
    id: "isbn",
    icon: BookOpen,
    group: "business",
    label: ["ISBN", "ISBN"],
    defaults: { format: "digits" },
    fields: [
      { key: "isbn", label: ["رقم ISBN", "ISBN"], kind: "text", ltr: true, placeholder: "978-3-16-148410-0" },
      { key: "format", label: ["الصيغة", "Format"], kind: "select", options: [opt("digits", "ISBN‑13 أرقام", "ISBN‑13 digits"), opt("urn", "urn:isbn", "urn:isbn")] },
    ],
    build(v) {
      const e: Errs = {};
      const d = val(v, "isbn").replace(/[\s-]/g, "");
      let i13 = "";
      if (!d) e.isbn = M.required;
      else if (d.length === 10 && isbn10Valid(d)) i13 = isbn10to13(d);
      else if (d.length === 13 && gtinValid(d) && /^97[89]/.test(d)) i13 = d;
      else e.isbn = ["ISBN غير صالح (فشل رقم التحقق)", "Invalid ISBN (checksum failed)"];
      return done(e, v.format === "urn" ? `urn:isbn:${i13}` : i13);
    },
  },
  {
    id: "gs1",
    icon: Barcode,
    group: "business",
    label: ["GS1", "GS1"],
    fields: [
      { key: "gtin", label: ["GTIN (01)", "GTIN (01)"], kind: "text", ltr: true, span: 2, placeholder: "09506000134352" },
      { key: "prod", label: ["تاريخ الإنتاج (11)", "Production (11)"], kind: "date" },
      { key: "exp", label: ["الانتهاء (17)", "Expiry (17)"], kind: "date" },
      { key: "lot", label: ["الدفعة (10)", "Batch/Lot (10)"], kind: "text", ltr: true },
      { key: "serial", label: ["التسلسلي (21)", "Serial (21)"], kind: "text", ltr: true },
    ],
    build(v) {
      const e: Errs = {};
      const g = val(v, "gtin").replace(/\s/g, "");
      if (!g) e.gtin = M.required;
      else if (!gtinValid(g)) e.gtin = ["GTIN غير صالح (رقم التحقق)", "Invalid GTIN (check digit)"];
      const GS = "\u001d";
      let d = "01" + g.padStart(14, "0");
      if (val(v, "prod")) d += "11" + yymmdd(val(v, "prod"));
      if (val(v, "exp")) d += "17" + yymmdd(val(v, "exp"));
      if (val(v, "lot")) d += "10" + val(v, "lot") + (val(v, "serial") ? GS : "");
      if (val(v, "serial")) d += "21" + val(v, "serial");
      return done(e, d);
    },
  },
  {
    id: "gs1dl",
    icon: Globe,
    group: "business",
    label: ["GS1 Digital Link", "GS1 Digital Link"],
    defaults: { domain: "id.gs1.org" },
    fields: [
      { key: "gtin", label: ["GTIN", "GTIN"], kind: "text", ltr: true, placeholder: "09506000134352" },
      { key: "domain", label: ["النطاق", "Domain"], kind: "text", ltr: true },
      { key: "lot", label: ["الدفعة (10)", "Batch/Lot (10)"], kind: "text", ltr: true },
      { key: "serial", label: ["التسلسلي (21)", "Serial (21)"], kind: "text", ltr: true },
      { key: "exp", label: ["الانتهاء (17)", "Expiry (17)"], kind: "date", span: 2 },
    ],
    build(v) {
      const e: Errs = {};
      const g = val(v, "gtin").replace(/\s/g, "");
      if (!g) e.gtin = M.required;
      else if (!gtinValid(g)) e.gtin = ["GTIN غير صالح (رقم التحقق)", "Invalid GTIN (check digit)"];
      const dom = val(v, "domain").replace(/^https?:\/\//, "").replace(/\/+$/, "") || "id.gs1.org";
      if (!/^[a-z0-9.-]+\.[a-z]{2,}(:\d+)?(\/[\w.-]+)*$/i.test(dom)) e.domain = M.url;
      let d = `https://${dom}/01/${g.padStart(14, "0")}`;
      if (val(v, "lot")) d += `/10/${enc(val(v, "lot"))}`;
      if (val(v, "serial")) d += `/21/${enc(val(v, "serial"))}`;
      if (val(v, "exp")) d += `?17=${yymmdd(val(v, "exp"))}`;
      return done(e, d);
    },
  },
  {
    id: "payment",
    icon: CreditCard,
    group: "business",
    label: ["دفع", "Payment"],
    defaults: { method: "epc", ppCur: "USD" },
    fields: [
      {
        key: "method",
        label: ["الطريقة", "Method"],
        kind: "select",
        span: 2,
        options: [opt("epc", "SEPA (EPC)", "SEPA (EPC)"), opt("upi", "UPI", "UPI"), opt("paypal", "PayPal.me", "PayPal.me"), opt("bitcoin", "Bitcoin", "Bitcoin")],
      },
      { key: "epcName", label: ["اسم المستفيد", "Beneficiary"], kind: "text", span: 2, showIf: (v) => (v.method || "epc") === "epc" },
      { key: "iban", label: ["IBAN", "IBAN"], kind: "text", ltr: true, span: 2, showIf: (v) => (v.method || "epc") === "epc" },
      { key: "bic", label: ["BIC (اختياري)", "BIC (optional)"], kind: "text", ltr: true, showIf: (v) => (v.method || "epc") === "epc" },
      { key: "epcAmount", label: ["المبلغ (EUR)", "Amount (EUR)"], kind: "number", ltr: true, showIf: (v) => (v.method || "epc") === "epc" },
      { key: "epcRef", label: ["مرجع الدفع", "Reference"], kind: "text", span: 2, showIf: (v) => (v.method || "epc") === "epc" },
      { key: "upiId", label: ["معرّف UPI", "UPI ID"], kind: "text", ltr: true, span: 2, placeholder: "name@bank", showIf: (v) => v.method === "upi" },
      { key: "upiName", label: ["اسم المستفيد", "Payee name"], kind: "text", showIf: (v) => v.method === "upi" },
      { key: "upiAmount", label: ["المبلغ (INR)", "Amount (INR)"], kind: "number", ltr: true, showIf: (v) => v.method === "upi" },
      { key: "upiNote", label: ["ملاحظة", "Note"], kind: "text", span: 2, showIf: (v) => v.method === "upi" },
      { key: "ppUser", label: ["مستخدم PayPal.me", "PayPal.me user"], kind: "text", ltr: true, span: 2, showIf: (v) => v.method === "paypal" },
      { key: "ppAmount", label: ["المبلغ", "Amount"], kind: "number", ltr: true, showIf: (v) => v.method === "paypal" },
      {
        key: "ppCur",
        label: ["العملة", "Currency"],
        kind: "select",
        showIf: (v) => v.method === "paypal",
        options: ["USD", "EUR", "GBP", "SAR", "AED", "EGP"].map((c) => opt(c, c, c)),
      },
      { key: "btcAddr", label: ["عنوان Bitcoin", "Bitcoin address"], kind: "text", ltr: true, span: 2, showIf: (v) => v.method === "bitcoin" },
      { key: "btcAmount", label: ["المبلغ (BTC)", "Amount (BTC)"], kind: "number", ltr: true, showIf: (v) => v.method === "bitcoin" },
      { key: "btcLabel", label: ["التسمية", "Label"], kind: "text", showIf: (v) => v.method === "bitcoin" },
      { key: "btcMsg", label: ["رسالة", "Message"], kind: "text", span: 2, showIf: (v) => v.method === "bitcoin" },
    ],
    build(v) {
      const e: Errs = {};
      const m = v.method || "epc";
      let d = "";
      const amountOk = (k: string) => {
        if (val(v, k) && (!isNum(val(v, k)) || Number(val(v, k)) <= 0)) e[k] = M.number;
      };
      if (m === "epc") {
        need(e, v, "epcName", "iban");
        if (val(v, "epcName").length > 70) e.epcName = ["الحد 70 حرفاً", "Max 70 chars"];
        if (val(v, "iban") && !ibanValid(val(v, "iban"))) e.iban = ["IBAN غير صالح", "Invalid IBAN"];
        if (val(v, "bic") && !/^[A-Za-z]{6}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?$/.test(val(v, "bic"))) e.bic = ["BIC غير صالح", "Invalid BIC"];
        amountOk("epcAmount");
        if (val(v, "epcAmount") && Number(val(v, "epcAmount")) > 999999999.99) e.epcAmount = M.number;
        d = [
          "BCD",
          "002",
          "1",
          "SCT",
          val(v, "bic").toUpperCase(),
          val(v, "epcName"),
          val(v, "iban").replace(/\s/g, "").toUpperCase(),
          val(v, "epcAmount") ? "EUR" + Number(val(v, "epcAmount")).toFixed(2) : "",
          "",
          "",
          val(v, "epcRef").slice(0, 140),
        ].join("\n");
      } else if (m === "upi") {
        need(e, v, "upiId");
        if (val(v, "upiId") && !/^[\w.\-]{2,}@[A-Za-z]{2,}$/.test(val(v, "upiId"))) e.upiId = ["معرّف UPI غير صالح", "Invalid UPI ID"];
        amountOk("upiAmount");
        d = `upi://pay?pa=${enc(val(v, "upiId"))}`;
        if (val(v, "upiName")) d += `&pn=${enc(val(v, "upiName"))}`;
        if (val(v, "upiAmount")) d += `&am=${Number(val(v, "upiAmount")).toFixed(2)}`;
        d += "&cu=INR";
        if (val(v, "upiNote")) d += `&tn=${enc(val(v, "upiNote"))}`;
      } else if (m === "paypal") {
        need(e, v, "ppUser");
        if (val(v, "ppUser") && !/^[A-Za-z0-9.\-_]{1,40}$/.test(val(v, "ppUser").replace(/^@/, ""))) e.ppUser = ["اسم غير صالح", "Invalid name"];
        amountOk("ppAmount");
        d = `https://paypal.me/${val(v, "ppUser").replace(/^@/, "")}`;
        if (val(v, "ppAmount")) d += `/${Number(val(v, "ppAmount"))}${v.ppCur || "USD"}`;
      } else {
        need(e, v, "btcAddr");
        if (val(v, "btcAddr") && !/^(bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(val(v, "btcAddr"))) e.btcAddr = ["عنوان Bitcoin غير صالح", "Invalid Bitcoin address"];
        amountOk("btcAmount");
        const q: string[] = [];
        if (val(v, "btcAmount")) q.push("amount=" + Number(val(v, "btcAmount")));
        if (val(v, "btcLabel")) q.push("label=" + enc(val(v, "btcLabel")));
        if (val(v, "btcMsg")) q.push("message=" + enc(val(v, "btcMsg")));
        d = `bitcoin:${val(v, "btcAddr")}${q.length ? "?" + q.join("&") : ""}`;
      }
      return done(e, d);
    },
  },
  {
    id: "custom",
    icon: Braces,
    group: "advanced",
    label: ["بيانات مخصصة", "Custom data"],
    defaults: { mode: "raw" },
    fields: [
      {
        key: "mode",
        label: ["المعالجة", "Processing"],
        kind: "select",
        span: 2,
        options: [opt("raw", "كما هي", "As is"), opt("json", "JSON (تحقق وضغط)", "JSON (validate & minify)"), opt("base64", "Base64", "Base64")],
      },
      { key: "data", label: ["البيانات", "Data"], kind: "textarea", span: 2 },
    ],
    build(v) {
      const e: Errs = {};
      const raw = v.data ?? "";
      if (!raw.trim()) e.data = M.required;
      let d = raw;
      if (raw.trim() && v.mode === "json") {
        try {
          d = JSON.stringify(JSON.parse(raw));
        } catch {
          e.data = ["JSON غير صالح", "Invalid JSON"];
        }
      } else if (raw.trim() && v.mode === "base64") {
        const bytes = new TextEncoder().encode(raw);
        let s = "";
        bytes.forEach((b) => (s += String.fromCharCode(b)));
        d = btoa(s);
      }
      return done(e, d);
    },
  },
];

export const TYPE_MAP: Record<string, TypeDef> = Object.fromEntries(TYPES.map((t) => [t.id, t]));
export const getType = (id: string): TypeDef => TYPE_MAP[id] ?? TYPES[0];
export const FallbackIcon = QrCode;

export const defaultValues = (id: string): Values => ({ ...(getType(id).defaults ?? {}) });
