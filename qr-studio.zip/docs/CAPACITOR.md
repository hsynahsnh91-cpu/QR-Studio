# QR Studio → Android (Capacitor)

The web app is fully static (`dist/index.html`) and uses no backend, so it wraps directly.

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

`capacitor.config.json` is already included (`webDir: dist`, `androidScheme: https` so camera and
IndexedDB work in a secure context).

## Android permissions (`android/app/src/main/AndroidManifest.xml`)

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
```

In `MainActivity` grant WebView media-capture requests (`WebChromeClient.onPermissionRequest`) —
Capacitor's default bridge already forwards camera requests once `CAMERA` is declared.
